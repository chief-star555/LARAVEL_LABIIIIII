<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Role;
use App\Models\Text;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    use RefreshDatabase;

    private Category $technology;

    protected function setUp(): void
    {
        parent::setUp();

        foreach (['reader', 'journalist', 'admin'] as $role) {
            Role::firstOrCreate(['name' => $role]);
        }

        $this->technology = Category::create(['name' => 'Технологии']);
    }

    public function test_homepage_displays_only_published_articles(): void
    {
        $journalist = $this->createUser('journalist', 'journalist');
        $this->createArticle($journalist, 'Опубликованная новость');
        $this->createArticle($journalist, 'Скрытая новость', false);

        $this->get('/')
            ->assertOk()
            ->assertSee('Опубликованная новость')
            ->assertDontSee('Скрытая новость');
    }

    public function test_registered_user_can_publish_an_article(): void
    {
        $this->post('/register', [
            'login' => 'new_writer',
            'password' => 'strong-password-123',
            'password_confirmation' => 'strong-password-123',
        ])->assertRedirect(route('home'));

        $user = User::where('login', 'new_writer')->firstOrFail();
        $this->assertAuthenticatedAs($user);
        $this->assertSame('journalist', $user->role->name);

        $this->post('/journalist', [
            'heading' => 'Статья нового автора',
            'text' => 'Полный текст статьи, который содержит более двадцати символов.',
            'category_id' => $this->technology->id,
        ])->assertRedirect(route('journalist'));

        $this->assertDatabaseHas('texts', [
            'heading' => 'Статья нового автора',
            'author_id' => $user->id,
            'category_id' => $this->technology->id,
            'is_published' => true,
        ]);
    }

    public function test_reader_cannot_open_journalist_or_admin_sections(): void
    {
        $reader = $this->createUser('reader', 'reader');

        $this->actingAs($reader)
            ->get('/')
            ->assertOk()
            ->assertDontSee('Админ');

        $this->actingAs($reader)
            ->get('/journalist')
            ->assertForbidden();

        $this->actingAs($reader)
            ->get('/admin')
            ->assertForbidden();
    }

    public function test_journalist_cannot_edit_another_users_article(): void
    {
        $author = $this->createUser('author', 'journalist');
        $anotherJournalist = $this->createUser('another_writer', 'journalist');
        $article = $this->createArticle($author, 'Чужая статья');

        $this->actingAs($anotherJournalist)
            ->get(route('journalist.edit', $article))
            ->assertForbidden();
    }

    public function test_admin_can_open_admin_panel_manage_roles_and_block_articles(): void
    {
        $admin = $this->createUser('admin', 'admin');
        $journalist = $this->createUser('writer', 'journalist');
        $article = $this->createArticle($journalist, 'Новость для админки');

        $this->actingAs($admin)
            ->get('/admin')
            ->assertOk()
            ->assertSee('Управление сайтом')
            ->assertSee('Новость для админки');

        $this->get('/')
            ->assertOk()
            ->assertSee('href="'.route('admin.index').'"', false);

        $this->put(route('admin.articles.update', $article), [
            'heading' => 'Обновлённый заголовок новости',
            'text' => 'Изменённый текст публикации для проверки панели администратора.',
            'category_id' => $this->technology->id,
        ])->assertRedirect(route('admin.index'));

        $this->assertDatabaseHas('texts', [
            'id' => $article->id,
            'heading' => 'Обновлённый заголовок новости',
        ]);

        $readerRole = Role::where('name', 'reader')->firstOrFail();
        $this->patch(route('admin.users.update-role', $journalist), [
            'role_id' => $readerRole->id,
        ])->assertRedirect(route('admin.index'));

        $this->assertDatabaseHas('users', [
            'id' => $journalist->id,
            'role_id' => $readerRole->id,
        ]);

        $this->patch(route('admin.articles.toggle-block', $article))
            ->assertRedirect(route('admin.index'));

        $this->assertDatabaseHas('texts', [
            'id' => $article->id,
            'is_published' => false,
        ]);

        $this->delete(route('admin.articles.destroy', $article))
            ->assertRedirect(route('admin.index'));

        $this->assertDatabaseMissing('texts', ['id' => $article->id]);
    }

    private function createUser(string $login, string $roleName): User
    {
        return User::create([
            'login' => $login,
            'password' => 'test-password',
            'role_id' => Role::where('name', $roleName)->firstOrFail()->id,
        ]);
    }

    private function createArticle(User $author, string $heading, bool $published = true): Text
    {
        return Text::create([
            'heading' => $heading,
            'text' => 'Текст публикации для проверки функций сайта.',
            'category_id' => $this->technology->id,
            'author_id' => $author->id,
            'is_published' => $published,
        ]);
    }
}
