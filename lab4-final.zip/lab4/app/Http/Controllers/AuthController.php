<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

class AuthController extends Controller
{
    public function loginForm(): View
    {
        return view('auth.login');
    }

    public function registerForm(): View
    {
        return view('auth.register');
    }

    public function register(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'login' => ['required', 'string', 'min:3', 'max:40', 'alpha_dash', 'unique:users,login'],
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        $user = User::create([
            'login' => $validated['login'],
            'password' => $validated['password'],
            // Новый аккаунт сразу может публиковать статьи, как требуется
            // для этой версии лабораторной. Администратор может изменить роль.
            'role_id' => Role::where('name', 'journalist')->firstOrFail()->id,
        ]);

        Auth::login($user);
        $request->session()->regenerate();

        return redirect()->route('home')->with('success', 'Аккаунт создан. Вы вошли на сайт.');
    }

    public function login(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'login' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        if (! Auth::attempt($credentials)) {
            return back()->withErrors([
                'login' => 'Проверьте логин и пароль.',
            ])->onlyInput('login');
        }

        $request->session()->regenerate();

        return redirect()->intended(route('home'));
    }

    public function logout(Request $request): RedirectResponse
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')->with('success', 'Вы вышли из аккаунта.');
    }
}
