<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Role;
use App\Models\Text;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminController extends Controller
{
    public function index(): View
    {
        return view('admin', [
            'articles' => Text::with(['category', 'author'])->latest()->paginate(10),
            'users' => User::with('role')->orderBy('login')->get(),
            'roles' => Role::orderBy('id')->get(),
            'roleLabels' => $this->roleLabels(),
        ]);
    }

    public function editArticle(Text $article): View
    {
        return view('admin.articles-edit', [
            'article' => $article,
            'categories' => Category::orderBy('name')->get(),
        ]);
    }

    public function updateArticle(Request $request, Text $article): RedirectResponse
    {
        $validated = $request->validate([
            'heading' => ['required', 'string', 'max:180'],
            'text' => ['required', 'string', 'min:20'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
        ]);

        $article->update($validated);

        return redirect()->route('admin.index')->with('success', 'Статья обновлена.');
    }

    public function toggleArticleBlock(Text $article): RedirectResponse
    {
        $article->update(['is_published' => ! $article->is_published]);

        $message = $article->is_published
            ? 'Статья снова опубликована.'
            : 'Статья заблокирована и скрыта с сайта.';

        return redirect()->route('admin.index')->with('success', $message);
    }

    public function deleteArticle(Text $article): RedirectResponse
    {
        $article->delete();

        return redirect()->route('admin.index')->with('success', 'Статья удалена.');
    }

    public function updateUserRole(Request $request, User $user): RedirectResponse
    {
        $validated = $request->validate([
            'role_id' => ['required', 'integer', 'exists:roles,id'],
        ]);

        $user->update($validated);

        return redirect()->route('admin.index')->with('success', 'Роль пользователя изменена.');
    }

    private function roleLabels(): array
    {
        return [
            'reader' => 'Пользователь',
            'journalist' => 'Журналист',
            'admin' => 'Администратор',
        ];
    }
}
