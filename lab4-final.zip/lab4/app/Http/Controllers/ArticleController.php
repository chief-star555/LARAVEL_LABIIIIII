<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Text;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ArticleController extends Controller
{
    public function home(): View
    {
        $articles = Text::query()
            ->join('categories', 'texts.category_id', '=', 'categories.id')
            ->join('users', 'texts.author_id', '=', 'users.id')
            ->where('texts.is_published', true)
            ->select('texts.*', 'categories.name as category_name', 'users.login as author_login')
            ->latest('texts.created_at')
            ->paginate(6)
            ->through(fn (Text $article) => $this->articleCard($article));

        return view('home', ['articles' => $articles]);
    }

    public function category(): View
    {
        $category = Category::where('name', 'Технологии')->firstOrFail();
        $articles = Text::query()
            ->join('categories', 'texts.category_id', '=', 'categories.id')
            ->join('users', 'texts.author_id', '=', 'users.id')
            ->where('texts.category_id', $category->id)
            ->where('texts.is_published', true)
            ->select('texts.*', 'categories.name as category_name', 'users.login as author_login')
            ->latest('texts.created_at')
            ->paginate(6)
            ->through(fn (Text $article) => $this->articleCard($article));

        return view('category', [
            'categoryName' => $category->name,
            'articles' => $articles,
        ]);
    }

    public function create(): View
    {
        return view('journalist', [
            'article' => null,
            'categories' => Category::orderBy('name')->get(),
            'myArticles' => Text::where('author_id', Auth::id())->latest()->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateArticle($request);
        $validated['author_id'] = Auth::id();

        Text::create($validated);

        return redirect()->route('journalist')->with('success', 'Статья сохранена.');
    }

    public function edit(Text $article): View
    {
        abort_unless($article->author_id === Auth::id(), 403);

        return view('journalist', [
            'article' => $article,
            'categories' => Category::orderBy('name')->get(),
            'myArticles' => Text::where('author_id', Auth::id())->latest()->get(),
        ]);
    }

    public function update(Request $request, Text $article): RedirectResponse
    {
        abort_unless($article->author_id === Auth::id(), 403);

        $article->update($this->validateArticle($request));

        return redirect()->route('journalist')->with('success', 'Изменения сохранены.');
    }

    private function validateArticle(Request $request): array
    {
        return $request->validate([
            'heading' => ['required', 'string', 'max:180'],
            'text' => ['required', 'string', 'min:20'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
        ]);
    }

    private function articleCard(Text $article): array
    {
        return [
            'title' => $article->heading,
            'category' => $article->category_name,
            'author' => $article->author_login,
            'date' => Carbon::parse($article->created_at)->format('d.m.Y'),
            'excerpt' => Str::limit($article->text, 180),
        ];
    }
}
