<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ArticleController::class, 'home'])->name('home');
Route::get('/category', [ArticleController::class, 'category'])->name('category');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.store');
    Route::get('/register', [AuthController::class, 'registerForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.store');
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware(['auth', 'role:journalist,admin'])->group(function () {
    Route::get('/journalist', [ArticleController::class, 'create'])->name('journalist');
    Route::post('/journalist', [ArticleController::class, 'store'])->name('journalist.store');
    Route::get('/journalist/{article}/edit', [ArticleController::class, 'edit'])->name('journalist.edit');
    Route::put('/journalist/{article}', [ArticleController::class, 'update'])->name('journalist.update');
});

Route::prefix('admin')
    ->name('admin.')
    ->middleware(['auth', 'role:admin'])
    ->group(function () {
        Route::get('/', [AdminController::class, 'index'])->name('index');
        Route::get('/articles/{article}/edit', [AdminController::class, 'editArticle'])->name('articles.edit');
        Route::put('/articles/{article}', [AdminController::class, 'updateArticle'])->name('articles.update');
        Route::patch('/articles/{article}/block', [AdminController::class, 'toggleArticleBlock'])->name('articles.toggle-block');
        Route::delete('/articles/{article}', [AdminController::class, 'deleteArticle'])->name('articles.destroy');
        Route::patch('/users/{user}/role', [AdminController::class, 'updateUserRole'])->name('users.update-role');
    });
