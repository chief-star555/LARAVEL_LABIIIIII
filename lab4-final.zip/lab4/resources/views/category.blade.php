@extends('layouts.site')

@section('title', $categoryName . ' — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Раздел новостного сайта</p>
        <h1>{{ $categoryName }}</h1>
        <p>Здесь собраны новости выбранной категории.</p>
    </section>

    <section class="news-list">
        @forelse ($articles as $article)
            <article class="news-card">
                <div class="news-card-top">
                    <span class="category-pill">{{ $article['category'] }}</span>
                    <time>{{ $article['date'] }}</time>
                </div>
                <h2>{{ $article['title'] }}</h2>
                <p>{{ $article['excerpt'] }}</p>
                <div class="news-byline">Автор: {{ $article['author'] }}</div>
            </article>
        @empty
            <div class="empty-state">В этой категории пока нет новостей.</div>
        @endforelse
    </section>

    <div class="pagination">{{ $articles->links() }}</div>
@endsection
