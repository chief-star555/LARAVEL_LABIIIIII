@extends('layouts.site')

@section('title', 'Регистрация — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Новый аккаунт</p>
        <h1>Регистрация</h1>
        <p>Для регистрации нужны только логин и пароль.</p>
    </section>

    <form class="form-panel auth-panel" method="POST" action="{{ route('register.store') }}">
        @csrf

        <label class="form-field">
            <span>Логин</span>
            <input type="text" name="login" value="{{ old('login') }}" autocomplete="username" required autofocus>
            @error('login') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <label class="form-field">
            <span>Пароль</span>
            <input type="password" name="password" autocomplete="new-password" required>
            @error('password') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <label class="form-field">
            <span>Повторите пароль</span>
            <input type="password" name="password_confirmation" autocomplete="new-password" required>
        </label>

        <button class="button" type="submit">Создать аккаунт</button>
        <p class="form-note">Уже зарегистрированы? <a class="text-link" href="{{ route('login') }}">Войти</a></p>
    </form>
@endsection
