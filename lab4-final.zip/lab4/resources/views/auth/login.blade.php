@extends('layouts.site')

@section('title', 'Вход — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Личный кабинет</p>
        <h1>Войти</h1>
        <p>Введите логин и пароль, чтобы продолжить.</p>
    </section>

    <form class="form-panel auth-panel" method="POST" action="{{ route('login.store') }}">
        @csrf

        <label class="form-field">
            <span>Логин</span>
            <input type="text" name="login" value="{{ old('login') }}" autocomplete="username" required autofocus>
            @error('login') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <label class="form-field">
            <span>Пароль</span>
            <input type="password" name="password" autocomplete="current-password" required>
            @error('password') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <button class="button" type="submit">Войти</button>
        <p class="form-note">Нет аккаунта? <a class="text-link" href="{{ route('register') }}">Зарегистрироваться</a></p>
    </form>
@endsection
