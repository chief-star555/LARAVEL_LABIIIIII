@extends('layouts.site')

@section('title', 'Редактирование статьи — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Администрирование</p>
        <h1>Редактировать статью</h1>
        <p>Изменения сразу сохраняются в базе данных.</p>
    </section>

    <form class="form-panel" method="POST" action="{{ route('admin.articles.update', $article) }}">
        @csrf
        @method('PUT')

        <label class="form-field">
            <span>Заголовок</span>
            <input type="text" name="heading" value="{{ old('heading', $article->heading) }}" required>
            @error('heading') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <label class="form-field">
            <span>Категория</span>
            <select name="category_id" required>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}" @selected(old('category_id', $article->category_id) == $category->id)>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>
            @error('category_id') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <label class="form-field">
            <span>Текст статьи</span>
            <textarea name="text" rows="10" required>{{ old('text', $article->text) }}</textarea>
            @error('text') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <button class="button" type="submit">Сохранить изменения</button>
        <a class="text-link cancel-link" href="{{ route('admin.index') }}">Вернуться в админку</a>
    </form>
@endsection
