<footer class="site-footer">
    <div class="footer-inner">
        <span>ПростоНовости — учебный новостной сайт</span>
        <span>Лабораторная работа по Laravel</span>
    </div>
</footer>
