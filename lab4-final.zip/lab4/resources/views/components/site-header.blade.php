<header class="site-header">
    <div class="header-inner">
        <a class="brand" href="{{ route('home') }}">
            <span class="brand-mark">П</span>
            <span>ПростоНовости</span>
        </a>

        <nav class="main-nav" aria-label="Основная навигация">
            <a href="{{ route('home') }}">Главная</a>
            <a href="{{ route('category') }}">Технологии</a>
            @auth
                @if (in_array(auth()->user()->role?->name, ['journalist', 'admin'], true))
                    <a href="{{ route('journalist') }}">Журналист</a>
                @endif
                @if (auth()->user()->role?->name === 'admin')
                    <a href="{{ route('admin.index') }}">Админ</a>
                @endif
                <span class="user-badge">{{ auth()->user()->login }}</span>
                <form class="logout-form" method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="nav-button" type="submit">Выйти</button>
                </form>
            @else
                <a href="{{ route('login') }}">Войти</a>
                <a href="{{ route('register') }}">Регистрация</a>
            @endauth
        </nav>
    </div>
</header>
