@extends('layouts.site')

@section('title', 'Админка — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Раздел администратора</p>
        <h1>Управление сайтом</h1>
        <p>Здесь можно редактировать и блокировать статьи, а также менять роли пользователей.</p>
    </section>

    <section class="admin-block">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Публикации</p>
                <h2>Статьи</h2>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Заголовок и автор</th>
                        <th>Категория</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($articles as $article)
                        <tr>
                            <td>
                                <strong>{{ $article->heading }}</strong>
                                <small>Автор: {{ $article->author->login }}</small>
                            </td>
                            <td>{{ $article->category->name }}</td>
                            <td>
                                @if ($article->is_published)
                                    <span class="status status-live">Опубликована</span>
                                @else
                                    <span class="status status-blocked">Заблокирована</span>
                                @endif
                            </td>
                            <td>
                                <div class="table-actions">
                                    <a class="text-link" href="{{ route('admin.articles.edit', $article) }}">Изменить</a>
                                    <form method="POST" action="{{ route('admin.articles.toggle-block', $article) }}">
                                        @csrf
                                        @method('PATCH')
                                        <button class="button button-small button-muted" type="submit">
                                            {{ $article->is_published ? 'Заблокировать' : 'Опубликовать' }}
                                        </button>
                                    </form>
                                    <form method="POST" action="{{ route('admin.articles.destroy', $article) }}" onsubmit="return confirm('Удалить эту статью?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="button button-small button-danger" type="submit">Удалить</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4">Статей пока нет.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="pagination">{{ $articles->links() }}</div>
    </section>

    <section class="admin-block">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Аккаунты</p>
                <h2>Роли пользователей</h2>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Логин</th>
                        <th>Текущая роль</th>
                        <th>Изменить роль</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user)
                        <tr>
                            <td>{{ $user->login }}</td>
                            <td>{{ $roleLabels[$user->role->name] ?? $user->role->name }}</td>
                            <td>
                                <form class="role-form-inline" method="POST" action="{{ route('admin.users.update-role', $user) }}">
                                    @csrf
                                    @method('PATCH')
                                    <select name="role_id" aria-label="Новая роль для {{ $user->login }}">
                                        @foreach ($roles as $role)
                                            <option value="{{ $role->id }}" @selected($user->role_id === $role->id)>
                                                {{ $roleLabels[$role->name] ?? $role->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <button class="button button-small" type="submit">Сохранить</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </section>
@endsection
