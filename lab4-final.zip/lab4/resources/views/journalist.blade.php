@extends('layouts.site')

@section('title', 'Новая статья — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Раздел журналиста</p>
        <h1>Написать новость</h1>
        <p>Заполните три поля, чтобы подготовить статью.</p>
    </section>

    <form class="form-panel" method="POST" action="{{ $article ? route('journalist.update', $article) : route('journalist.store') }}">
        @csrf
        @if ($article)
            @method('PUT')
        @endif

        <label class="form-field">
            <span>Заголовок</span>
            <input type="text" name="heading" value="{{ old('heading', $article?->heading) }}" placeholder="Например: Учёные открыли новую планету" required>
            @error('heading') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <label class="form-field">
            <span>Категория</span>
            <select name="category_id" required>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}" @selected(old('category_id', $article?->category_id) == $category->id)>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>
            @error('category_id') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <label class="form-field">
            <span>Текст статьи</span>
            <textarea name="text" rows="8" placeholder="Расскажите, что произошло..." required>{{ old('text', $article?->text) }}</textarea>
            @error('text') <span class="field-error">{{ $message }}</span> @enderror
        </label>

        <button class="button" type="submit">{{ $article ? 'Сохранить изменения' : 'Опубликовать статью' }}</button>
        @if ($article)
            <a class="text-link cancel-link" href="{{ route('journalist') }}">Отменить редактирование</a>
        @endif
    </form>

    <section class="news-section">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Ваши публикации</p>
                <h2>Мои статьи</h2>
            </div>
        </div>

        <div class="news-list">
            @forelse ($myArticles as $myArticle)
                <article class="news-card">
                    <div class="news-card-top">
                        <span class="category-pill">Статья</span>
                        <a class="text-link" href="{{ route('journalist.edit', $myArticle) }}">Редактировать</a>
                    </div>
                    <h3>{{ $myArticle->heading }}</h3>
                </article>
            @empty
                <div class="empty-state">Вы ещё не написали статей.</div>
            @endforelse
        </div>
    </section>
@endsection
