@extends('layouts.site')

@section('title', 'Главная — ПростоНовости')

@section('content')
    <section class="welcome-panel">
        <p class="eyebrow">Новости науки и технологий</p>
        <h1>Главное — простыми словами</h1>
        <p class="welcome-copy">Коротко рассказываем об открытиях, технологиях и событиях.</p>
    </section>

    <section class="news-section">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Свежие публикации</p>
                <h2>Последние новости</h2>
            </div>
            <a class="text-link" href="{{ route('category') }}">Все новости о технологиях →</a>
        </div>

        <div class="news-list">
            @foreach ($articles as $article)
                <article class="news-card">
                    <div class="news-card-top">
                        <span class="category-pill">{{ $article['category'] }}</span>
                        <time>{{ $article['date'] }}</time>
                    </div>
                    <h3>{{ $article['title'] }}</h3>
                    <p>{{ $article['excerpt'] }}</p>
                    <div class="news-byline">Автор: {{ $article['author'] }}</div>
                </article>
            @endforeach
        </div>

        <div class="pagination">{{ $articles->links() }}</div>
    </section>
@endsection
