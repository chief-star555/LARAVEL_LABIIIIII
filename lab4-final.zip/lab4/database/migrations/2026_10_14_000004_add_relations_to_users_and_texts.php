<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        $readerRoleId = DB::table('roles')->where('name', 'reader')->value('id');

        Schema::table('users', function (Blueprint $table) use ($readerRoleId) {
            $table->unsignedBigInteger('role_id')->default($readerRoleId)->index();
        });

        foreach (DB::table('roles')->get() as $role) {
            DB::table('users')->where('role', $role->name)->update(['role_id' => $role->id]);
        }

        Schema::table('users', function (Blueprint $table) {
            $table->foreign('role_id')->references('id')->on('roles')->restrictOnDelete();
            $table->dropColumn('role');
        });

        Schema::table('texts', function (Blueprint $table) {
            $table->foreign('category_id')->references('id')->on('categories')->restrictOnDelete();
            $table->foreign('author_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('texts', function (Blueprint $table) {
            $table->dropForeign(['category_id']);
            $table->dropForeign(['author_id']);
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['role_id']);
            $table->string('role')->default('reader');
        });

        foreach (DB::table('roles')->get() as $role) {
            DB::table('users')->where('role_id', $role->id)->update(['role' => $role->name]);
        }

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('role_id');
        });

        Schema::dropIfExists('roles');
    }
};
