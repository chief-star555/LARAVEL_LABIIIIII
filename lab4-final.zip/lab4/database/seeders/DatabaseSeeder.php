<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Role;
use App\Models\Text;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $roles = collect(['reader', 'journalist', 'admin'])
            ->mapWithKeys(fn (string $name) => [$name => Role::firstOrCreate(['name' => $name])->id]);

        $technology = Category::firstOrCreate(['name' => 'Технологии']);
        $science = Category::firstOrCreate(['name' => 'Наука']);
        $space = Category::firstOrCreate(['name' => 'Космос']);

        $reader = User::updateOrCreate(
            ['login' => 'reader'],
            ['password' => 'news12345', 'role_id' => $roles['reader']]
        );
        $journalist = User::updateOrCreate(
            ['login' => 'journalist'],
            ['password' => 'news12345', 'role_id' => $roles['journalist']]
        );
        User::updateOrCreate(
            ['login' => 'admin'],
            ['password' => 'news12345', 'role_id' => $roles['admin']]
        );

        $examples = [
            [
                'heading' => 'Новый спутник поможет изучать климат',
                'text' => 'Аппарат будет собирать данные об облаках и температуре поверхности Земли.',
                'category_id' => $space->id,
                'author_id' => $journalist->id,
            ],
            [
                'heading' => 'В школах тестируют цифровые лаборатории',
                'text' => 'Ученики смогут проводить простые опыты и сразу видеть результаты измерений.',
                'category_id' => $technology->id,
                'author_id' => $journalist->id,
            ],
            [
                'heading' => 'Учёные создали новый материал для батарей',
                'text' => 'Новый материал может увеличить срок службы аккумуляторов и упростить их переработку.',
                'category_id' => $science->id,
                'author_id' => $reader->id,
            ],
        ];

        foreach ($examples as $example) {
            Text::updateOrCreate(
                ['heading' => $example['heading']],
                $example + ['is_published' => true]
            );
        }
    }
}
