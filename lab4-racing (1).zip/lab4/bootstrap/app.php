<?php

/*
|--------------------------------------------------------------------------
| НАСТРОЙКА ПРИЛОЖЕНИЯ (bootstrap/app.php)
|--------------------------------------------------------------------------
| В Laravel 11+ нет старого app/Http/Kernel.php — middleware регистрируются здесь.
|
| Путь каждого запроса:
|   браузер → public/index.php → ГЛОБАЛЬНЫЕ middleware (для всех запросов)
|          → группа 'web' (сессия, CSRF, cookies)
|          → middleware маршрута ('auth', 'guest', 'role:admin')
|          → контроллер → Blade-шаблон → ответ идёт обратно через те же middleware.
*/

use App\Http\Middleware\PartitionSessionCookies;
use App\Http\Middleware\PreviewAuthBridge;
use App\Http\Middleware\PreviewCsrf;
use App\Http\Middleware\RoleMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',        // маршруты сайта
        commands: __DIR__.'/../routes/console.php', // artisan-команды
        health: '/up',                             // служебная проверка "сервер жив"
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Сайт может работать за обратным прокси (preview-среда, хостинг).
        // Доверяем заголовкам X-Forwarded-*, чтобы Laravel знал настоящий адрес и https.
        // На реальном сервере в .env вместо * указывают IP своего прокси.
        $middleware->trustProxies(at: env('TRUSTED_PROXIES', '*'));

        // Куда middleware 'auth' отправляет гостя. Относительный путь — чтобы
        // редирект не уводил на чужой хост (например, http://localhost).
        $middleware->redirectGuestsTo('/login');

        // ГЛОБАЛЬНЫЕ middleware (append = выполняются для каждого запроса):
        // 1) PartitionSessionCookies — помечает cookie сессии как Partitioned (CHIPS),
        //    если сайт открыт внутри iframe по HTTPS. Иначе браузер её блокирует.
        $middleware->append(PartitionSessionCookies::class);
        // 2) PreviewAuthBridge — запасной вход для preview, когда cookies заблокированы
        //    полностью. По умолчанию ВЫКЛЮЧЕН (PREVIEW_AUTH_BRIDGE=false) и работает
        //    только при APP_ENV=local. На обычном сервере ничего не делает.
        $middleware->append(PreviewAuthBridge::class);

        // Заменяем стандартную CSRF-проверку на наследника PreviewCsrf.
        // Для обычного сайта она работает ТОЧНО так же, как стандартная Laravel.
        $middleware->replaceInGroup('web', PreventRequestForgery::class, PreviewCsrf::class);

        // Псевдоним: в маршрутах пишем 'role:admin' вместо полного имени класса.
        // Всё, что после двоеточия, передаётся в handle() как параметр ($roles).
        $middleware->alias([
            'role' => RoleMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // Если запрос пришёл из JS (fetch с заголовком Accept: application/json),
        // ошибки (401, 422, 404) возвращаются в JSON, а не HTML-страницей —
        // так игра может показать понятное сообщение.
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
