<?php

return [
    // Временный "мост" авторизации для предпросмотра во встроенном окне (iframe), где браузер
    // блокирует cookie сессии. Работает ТОЛЬКО если PREVIEW_AUTH_BRIDGE=true И APP_ENV=local.
    // В обычном запуске и на реальном сервере выключен — авторизация идёт стандартной сессией.
    'enabled' => env('PREVIEW_AUTH_BRIDGE', false),
    // где хранить токены моста
    'cache_store' => env('PREVIEW_AUTH_CACHE_STORE', 'file'),
    // срок жизни токена входа (минуты)
    'lifetime_minutes' => (int) env('PREVIEW_AUTH_LIFETIME', 720),
];
