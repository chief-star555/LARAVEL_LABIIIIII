<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Car — машина (таблица `cars`). Три машины создаёт CarSeeder.
 *
 * Характеристики передаются в JS-игру и влияют на физику:
 *   top_speed    — максимальная скорость (пикселей/сек, на экране показана как км/ч);
 *   acceleration — насколько быстро разгоняется;
 *   handling     — множитель скорости поворота (1.08 — резче, 0.96 — тяжелее).
 * color_hex / accent_hex / body_style — внешний вид на Canvas и в витрине.
 */
#[Fillable(['slug', 'name', 'brand', 'color_name', 'color_hex', 'accent_hex', 'body_style', 'description', 'top_speed', 'acceleration', 'handling'])]
class Car extends Model
{
    protected function casts(): array
    {
        return ['top_speed' => 'integer', 'acceleration' => 'integer', 'handling' => 'float'];
    }

    /** Игроки, у которых эта машина сейчас выбрана в гараже. */
    public function drivers(): HasMany
    {
        return $this->hasMany(User::class, 'current_car_id');
    }

    /** Все заезды на этой машине. */
    public function raceResults(): HasMany
    {
        return $this->hasMany(RaceResult::class);
    }
}
