<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Http\Request;

/**
 * UserActivityLog — журнал действий пользователей (таблица `user_activity_logs`).
 *
 * Пишется ОДНОЙ строкой из любого места: UserActivityLog::record('auth.login', $user);
 *
 * Какие события пишутся (код → где):
 *   auth.registered          — AuthController::register   регистрация (+ стартовая машина)
 *   auth.login               — AuthController::login      успешный вход
 *   auth.login_failed        — AuthController::login      неверный логин/пароль (user_id = null, логин в metadata)
 *   auth.logout              — AuthController::logout     выход
 *   garage.car_selected      — GarageController::selectCar выбор машины
 *   game.enter               — GameController::show       открыл страницу трассы
 *   race.started             — GameController::start      старт заезда (race_token, машина)
 *   race.finished            — GameController::finish     финиш (время, очки, концовка, HP, круги)
 *   personal_record.updated  — GameController::finish     новый личный рекорд
 *   admin.role_changed       — AdminController::updateUserRole смена роли (кому, было → стало)
 *
 * Каждая запись хранит: кто (user_id), трасса (track_id, если есть), код события,
 * подробности (metadata — JSON), IP-адрес, браузер (user_agent) и время.
 * ПАРОЛИ В ЖУРНАЛ НЕ ПИШУТСЯ НИКОГДА.
 *
 * Почему своя таблица, а не storage/logs/laravel.log: из БД события удобно
 * фильтровать, связывать с пользователем/трассой и показывать в админ-панели.
 */
#[Fillable(['user_id', 'track_id', 'event', 'metadata', 'ip_address', 'user_agent', 'created_at'])]
class UserActivityLog extends Model
{
    // В таблице только created_at (запись журнала не редактируется, updated_at не нужен).
    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'metadata' => 'array',     // PHP-массив ↔ JSON в БД автоматически
            'created_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function track(): BelongsTo
    {
        return $this->belongsTo(Track::class);
    }

    /**
     * Записать событие в журнал.
     *
     * @param  string  $event  код события, например 'race.finished'
     * @param  User|null  $user  кто совершил (null — гость, например неудачный вход)
     * @param  array  $metadata  любые подробности (сохранятся как JSON)
     * @param  Track|null  $track  трасса, если событие связано с ней
     */
    public static function record(string $event, ?User $user = null, array $metadata = [], ?Track $track = null): self
    {
        /** @var Request|null $request */
        $request = app()->bound('request') ? request() : null; // IP и браузер берём из текущего HTTP-запроса

        return static::create([
            'user_id' => $user?->getKey(),
            'track_id' => $track?->getKey(),
            'event' => $event,
            'metadata' => $metadata ?: null,
            'ip_address' => $request?->ip(),
            'user_agent' => $request?->userAgent(),
            'created_at' => now(),
        ]);
    }
}
