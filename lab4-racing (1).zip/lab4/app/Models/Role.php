<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Role — роль пользователя (таблица `roles`): 'player' (игрок) или 'admin' (администратор).
 *
 * Роль вынесена в отдельную таблицу (а не строка в users) — это нормализация БД:
 * новые роли добавляются строкой в таблице, а внешний ключ users.role_id не даст
 * назначить несуществующую роль. Проверку роли делает RoleMiddleware.
 */
#[Fillable(['name'])]
class Role extends Model
{
    /** Все пользователи с этой ролью (roles.id ← users.role_id). */
    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }
}
