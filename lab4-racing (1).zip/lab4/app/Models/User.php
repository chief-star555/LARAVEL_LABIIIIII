<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

/**
 * User — пользователь (таблица `users`).
 *
 * Наследуется от Authenticatable — поэтому с ним работают Auth::attempt(), Auth::login(),
 * $request->user(), @auth в шаблонах (настройка: config/auth.php, guard 'web', provider eloquent).
 *
 * Вход по полю `login` (не email) — Auth::attempt(['login' => ..., 'password' => ...])
 * ищет пользователя по всем полям, кроме password, а пароль сверяет с хэшем.
 *
 * Связи:
 *   role()         — belongsTo Role      (users.role_id → roles.id)       игрок или админ
 *   currentCar()   — belongsTo Car       (users.current_car_id → cars.id) машина из гаража
 *   raceResults()  — hasMany RaceResult  все заезды игрока
 *   activityLogs() — hasMany UserActivityLog  все события игрока в журнале
 */
#[Fillable(['login', 'password', 'role_id', 'current_car_id'])] // Mass assignment: только эти поля можно заполнять через create()/update()
#[Hidden(['password', 'remember_token'])] // никогда не попадут в JSON/toArray()
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }

    public function raceResults(): HasMany
    {
        return $this->hasMany(RaceResult::class);
    }

    public function currentCar(): BelongsTo
    {
        return $this->belongsTo(Car::class, 'current_car_id');
    }

    public function activityLogs(): HasMany
    {
        return $this->hasMany(UserActivityLog::class);
    }

    protected function casts(): array
    {
        // 'hashed' — при записи пароль АВТОМАТИЧЕСКИ хэшируется bcrypt.
        // Поэтому в контроллере пишем 'password' => $data['password'] без Hash::make().
        return ['password' => 'hashed'];
    }
}
