<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * RaceResult — результат ОДНОГО заезда (таблица `race_results`).
 *
 * Сохраняется КАЖДЫЙ заезд (включая аварии) — для истории в гараже.
 * is_personal_best = true стоит только у ЛУЧШЕГО успешного заезда игрока
 * на конкретной трассе и конкретной машине (тройка user + track + car).
 * Лидерборд показывает только записи с этим флагом.
 *
 * ending_type: gold | normal | secret (успешные), crash | timeout (неуспешные).
 */
#[Fillable(['user_id', 'track_id', 'car_id', 'finish_time', 'score', 'ending_type', 'bonus_count', 'remaining_hp', 'is_personal_best', 'completed_at'])]
class RaceResult extends Model
{
    protected function casts(): array
    {
        return [
            'finish_time' => 'decimal:2',   // время в секундах с 2 знаками (38.45)
            'score' => 'integer',
            'bonus_count' => 'integer',
            'remaining_hp' => 'integer',
            'is_personal_best' => 'boolean', // в БД 0/1, в PHP true/false
            'completed_at' => 'datetime',    // объект Carbon (можно ->format('d.m.Y'))
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function track(): BelongsTo
    {
        return $this->belongsTo(Track::class);
    }

    public function car(): BelongsTo
    {
        return $this->belongsTo(Car::class);
    }
}
