<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Track — трасса (таблица `tracks`). Трассы создаёт TrackSeeder.
 *
 * Трасса хранится как СЕТКА символов (поле grid, JSON-массив строк 16×12):
 *   '#' — стена/трава (нельзя ехать)    '.' — асфальт
 *   'F' — финишная линия                'S' — старт (клетка сразу после финиша)
 *   'B' — бонусная канистра (+очки, собрать все → секретная концовка)
 * Пример строки: "#..B...F.S....#"
 *
 * tile_size — размер клетки в пикселях на Canvas; target_time — время "золотого" финиша;
 * max_time — лимит (после него тайм-аут); start_direction — куда смотрит машина на старте.
 */
#[Fillable(['slug', 'name', 'description', 'difficulty', 'grid', 'tile_size', 'start_direction', 'target_time', 'max_time'])]
class Track extends Model
{
    protected function casts(): array
    {
        return ['grid' => 'array']; // JSON в БД ↔ PHP-массив строк
    }

    public function raceResults(): HasMany
    {
        return $this->hasMany(RaceResult::class);
    }

    /** Сколько канистр на трассе (считаем символы 'B'). Используется в валидации финиша. */
    public function bonusCount(): int
    {
        return collect($this->grid)->sum(fn (string $row) => substr_count($row, 'B'));
    }

    /** Кругов до финиша. Одно место в коде — и для сервера, и для JS (передаётся в шаблон). */
    public function lapsRequired(): int
    {
        return 2;
    }

    /**
     * Упорядоченный маршрут по центру трассы: от S по кругу до F.
     * Алгоритм — "идём по коридору": из текущей клетки шагаем в соседнюю дорожную клетку,
     * которая не является предыдущей и ещё не посещалась. Трасса — одна петля без развилок,
     * поэтому такой шаг всегда однозначен. Если петля не замкнулась — пустой массив.
     *
     * Нужен для: превью трассы (SVG на главной) и подсчёта прогресса круга в игре
     * (круг засчитывается, только если машина прошла маршрут по порядку — срезать нельзя).
     */
    public function circuitCells(): array
    {
        $grid = $this->grid;
        $start = $finish = null;

        // 1. Находим клетки S и F.
        foreach ($grid as $y => $row) {
            foreach (str_split($row) as $x => $cell) {
                if ($cell === 'S') {
                    $start = ['x' => $x, 'y' => $y];
                }
                if ($cell === 'F') {
                    $finish = ['x' => $x, 'y' => $y];
                }
            }
        }
        if (! $start || ! $finish) {
            return [];
        }

        $key = fn (array $p) => $p['x'].':'.$p['y'];
        $previous = $finish; // стартуем "спиной" к финишу — значит, первый шаг не назад
        $current = $start;
        $path = [$start];
        $seen = [$key($start) => true];
        $limit = count($grid) * strlen($grid[0]); // защита от бесконечного цикла

        // 2. Шагаем по трассе, пока не вернёмся к F.
        for ($steps = 0; $steps < $limit; $steps++) {
            if ($current === $finish) {
                return $path;
            }

            $next = null;
            foreach ([[1, 0], [-1, 0], [0, 1], [0, -1]] as [$dx, $dy]) { // вправо, влево, вниз, вверх
                $x = $current['x'] + $dx;
                $y = $current['y'] + $dy;
                // за пределами карты или стена — пропускаем
                if ($y < 0 || $y >= count($grid) || $x < 0 || $x >= strlen($grid[$y]) || $grid[$y][$x] === '#') {
                    continue;
                }
                $candidate = ['x' => $x, 'y' => $y];
                if ($candidate === $previous) {
                    continue; // назад не едем
                }
                if (isset($seen[$key($candidate)]) && $candidate !== $finish) {
                    continue; // уже были здесь
                }
                $next = $candidate;
                break;
            }

            if (! $next) {
                return []; // тупик — трасса нарисована неправильно
            }
            $previous = $current;
            $current = $next;
            $path[] = $current;
            $seen[$key($current)] = true;
        }

        return [];
    }

    /** SVG-путь (M x y L x y ... Z) для мини-карты трассы на главной странице. */
    public function previewPath(): string
    {
        $path = $this->circuitCells();
        if (count($path) < 4) {
            return '';
        }
        $coordinates = array_map(fn (array $point) => (10 + $point['x'] * 20).' '.(6 + $point['y'] * 12), $path);

        return 'M'.implode(' L', $coordinates).' Z';
    }
}
