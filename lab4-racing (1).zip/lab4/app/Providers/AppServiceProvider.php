<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;

/**
 * AppServiceProvider — место для глобальной настройки приложения при запуске.
 */
class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // ЗАЩИТА ОТ ПОДБОРА ПАРОЛЯ (brute force).
        // Лимитер 'auth' подключён к POST /login и POST /register (routes/web.php: ->middleware('throttle:auth')).
        // Не больше 10 попыток в минуту на пару "логин + IP". 11-я попытка → ответ 429 (errors/429.blade.php).
        // Ключ включает логин, чтобы один человек не блокировал вход всем остальным с того же IP.
        RateLimiter::for('auth', function (Request $request) {
            return Limit::perMinute(10)->by(Str::lower((string) $request->input('login')).'|'.$request->ip());
        });
    }
}
