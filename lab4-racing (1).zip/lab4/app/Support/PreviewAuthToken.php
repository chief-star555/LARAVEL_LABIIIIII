<?php

namespace App\Support;

use App\Models\User;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

/**
 * PreviewAuthToken — временный токен входа для локального preview без cookies.
 *
 * ЗАЧЕМ: обычный вход Laravel хранит "кто вошёл" в сессии, а id сессии — в cookie.
 * Если сайт открыт во встроенном окне, где браузер полностью блокирует cookies,
 * сессия теряется после каждого перехода. Тогда (и только тогда) включается
 * этот запасной механизм: после входа выдаётся случайный токен, который
 * передаётся в адресе (?preview_auth=...) и по нему определяется пользователь.
 *
 * БЕЗОПАСНОСТЬ:
 *  - выключен по умолчанию (PREVIEW_AUTH_BRIDGE=false в .env);
 *  - работает только при APP_ENV=local — на боевом сервере не включится никогда;
 *  - токен = 64 случайных символа (Str::random), подобрать нереально;
 *  - в кэше хранится не сам токен, а его SHA-256 хэш (как пароли хранят хэшем);
 *  - срок жизни ограничен (12 часов), при выходе токен удаляется (revoke).
 *
 * Обычная Laravel-сессия при этом не меняется и работает как всегда.
 */
class PreviewAuthToken
{
    /** Механизм включён? Нужно ОБА условия: флаг в .env и локальное окружение. */
    public static function enabled(): bool
    {
        return (bool) config('preview_auth.enabled') && app()->environment('local');
    }

    /** Где храним токены — кэш Laravel (по умолчанию файловый). */
    private static function store()
    {
        return Cache::store(config('preview_auth.cache_store', 'file'));
    }

    /** Ключ в кэше: хэш токена, а не сам токен (утечка кэша не раскроет токены). */
    private static function key(string $token): string
    {
        return 'preview-auth:'.hash('sha256', $token);
    }

    /** Выдать новый токен пользователю после успешного входа/регистрации. */
    public static function issue(User $user): ?string
    {
        if (! self::enabled()) {
            return null; // в обычном режиме токены не выдаются вообще
        }

        $token = Str::random(64);
        $lifetime = now()->addMinutes((int) config('preview_auth.lifetime_minutes', 720));
        self::store()->put(self::key($token), (int) $user->id, $lifetime);

        return $token;
    }

    /** По токену найти пользователя (или null, если токен неверный/просрочен/отозван). */
    public static function resolve(?string $token): ?User
    {
        if (! self::enabled() || ! $token || strlen($token) < 40) {
            return null;
        }

        $id = self::store()->get(self::key($token));

        return $id ? User::find((int) $id) : null;
    }

    /** Отозвать токен (при выходе) — после этого он больше не работает. */
    public static function revoke(?string $token): void
    {
        if (self::enabled() && $token) {
            self::store()->forget(self::key($token));
        }
    }

    /** Одноразовый CSRF-токен для формы входа/регистрации (живёт 45 минут). */
    public static function issueGuestCsrf(): string
    {
        $token = Str::random(64);
        self::store()->put('preview-guest-csrf:'.hash('sha256', $token), true, now()->addMinutes(45));

        return $token;
    }

    /** Проверить одноразовый токен формы. После проверки он удаляется — повторно не сработает. */
    public static function validGuestCsrf(?string $token): bool
    {
        if (! self::enabled() || ! $token || strlen($token) < 40) {
            return false;
        }

        $key = 'preview-guest-csrf:'.hash('sha256', $token);
        $valid = (bool) self::store()->get($key);
        if ($valid) {
            self::store()->forget($key);
        }

        return $valid;
    }

    /** Добавить ?preview_auth=ТОКЕН к адресу, сохранив остальные параметры. */
    public static function withToken(string $url, string $token): string
    {
        $parts = parse_url($url);
        if ($parts === false) {
            return $url;
        }

        $query = [];
        parse_str($parts['query'] ?? '', $query);
        $query['preview_auth'] = $token;

        $result = isset($parts['scheme'])
            ? $parts['scheme'].'://'.($parts['user'] ?? '').(isset($parts['pass']) ? ':'.$parts['pass'] : '').(isset($parts['user']) ? '@' : '').($parts['host'] ?? '').(isset($parts['port']) ? ':'.$parts['port'] : '')
            : '';
        $result .= ($parts['path'] ?? '/').'?'.http_build_query($query);
        if (isset($parts['fragment'])) {
            $result .= '#'.$parts['fragment'];
        }

        return $result;
    }

    /**
     * Безопасный адрес для редиректа после входа: только путь НАШЕГО сайта.
     * Защита от "open redirect": ссылка вида ?preview_intended=//evil.com
     * превратится в "/", и пользователя не уведут на чужой сайт.
     */
    public static function safeDestination(string $url): string
    {
        $parts = parse_url($url);
        if ($parts === false) {
            return '/';
        }

        $path = $parts['path'] ?? '/';
        if (! str_starts_with($path, '/') || str_starts_with($path, '//')) {
            $path = '/';
        }

        $query = [];
        parse_str($parts['query'] ?? '', $query);
        unset($query['preview_auth']); // токен в адрес назначения не переносим

        return $path.($query ? '?'.http_build_query($query) : '');
    }
}
