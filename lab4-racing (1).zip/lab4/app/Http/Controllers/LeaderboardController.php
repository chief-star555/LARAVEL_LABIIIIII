<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\RaceResult;
use App\Models\Track;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * LeaderboardController — публичная таблица рекордов (GET /leaderboard).
 *
 * Показывает топ-10 ЛИЧНЫХ РЕКОРДОВ (is_personal_best = true), а не все заезды:
 * иначе один игрок мог бы занять всю таблицу своими попытками.
 * Фильтры приходят в адресе: /leaderboard?track_id=2&car_id=3 (GET-форма).
 */
class LeaderboardController extends Controller
{
    public function index(Request $request): View
    {
        $tracks = Track::orderBy('name')->get();
        $cars = Car::orderBy('id')->get();

        // Мусорные значения фильтра (?track_id=abc, несуществующий id) не вызывают ошибку,
        // а просто означают "Все" — страница всегда открывается.
        $trackId = $this->filterId($request->query('track_id'), $tracks->modelKeys());
        $carId = $this->filterId($request->query('car_id'), $cars->modelKeys());

        $results = RaceResult::with(['user:id,login', 'track:id,name', 'car:id,name,color_name']) // жадная загрузка: без N+1 запросов
            ->where('is_personal_best', true)
            ->when($trackId, fn ($q) => $q->where('track_id', $trackId)) // when() — условие добавляется, только если фильтр выбран
            ->when($carId, fn ($q) => $q->where('car_id', $carId))
            ->orderBy('finish_time')   // 1) быстрее — выше
            ->orderByDesc('score')     // 2) при равном времени — больше очков
            ->orderBy('id')            // 3) при полном равенстве — кто раньше поставил
            ->limit(10)
            ->get();

        return view('leaderboard.index', [
            'tracks' => $tracks,
            'cars' => $cars,
            'results' => $results,
            'selectedTrackId' => $trackId,
            'selectedCarId' => $carId,
        ]);
    }

    /** Вернуть id, только если это целое число из списка существующих; иначе null ("все"). */
    private function filterId(mixed $value, array $allowed): ?int
    {
        if (! is_scalar($value) || ! ctype_digit((string) $value)) {
            return null;
        }

        $id = (int) $value;

        return in_array($id, array_map('intval', $allowed), true) ? $id : null;
    }
}
