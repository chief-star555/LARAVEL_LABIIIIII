<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\Role;
use App\Models\User;
use App\Models\UserActivityLog;
use App\Support\PreviewAuthToken;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

/**
 * AuthController — регистрация, вход и выход.
 *
 * Маршруты (routes/web.php):
 *   GET  /login    → loginForm()     (middleware 'guest')
 *   POST /login    → login()         (middleware 'guest')
 *   GET  /register → registerForm()  (middleware 'guest')
 *   POST /register → register()      (middleware 'guest')
 *   POST /logout   → logout()        (middleware 'auth')
 *
 * Как Laravel "помнит" вошедшего пользователя:
 *   Auth::login()/Auth::attempt() кладут id пользователя в СЕССИЮ.
 *   Сессия хранится в таблице `sessions` (SESSION_DRIVER=database),
 *   а браузер получает cookie с id сессии. На каждом запросе Laravel по cookie
 *   находит сессию → user_id → пользователя. Поэтому $request->user() и
 *
 *   @auth в шаблонах знают, кто вошёл.
 *
 * Пароли: в БД хранится только bcrypt-хэш. Хэширование делает cast
 * 'password' => 'hashed' в модели User — поэтому здесь пароль передаётся как есть.
 *
 * Все ветки с PreviewAuthToken относятся к запасному preview-режиму без cookies
 * и в обычном запуске не срабатывают (PreviewAuthToken::enabled() === false).
 */
class AuthController extends Controller
{
    /** Показать форму входа: resources/views/auth/login.blade.php */
    public function loginForm(): View
    {
        return view('auth.login');
    }

    /** Показать форму регистрации: resources/views/auth/register.blade.php */
    public function registerForm(): View
    {
        return view('auth.register');
    }

    /**
     * Регистрация нового игрока.
     * Шаги: валидация → создание пользователя → вход → новая сессия → запись в журнал → редирект.
     */
    public function register(Request $request): RedirectResponse
    {
        // 1. ВАЛИДАЦИЯ (проверка данных формы на сервере — клиенту доверять нельзя).
        $validator = Validator::make($request->all(), [
            // required — обязательно; min/max — длина; alpha_dash — буквы/цифры/-/_ без пробелов;
            // unique:users,login — такого логина ещё нет в таблице users.
            'login' => ['required', 'string', 'min:3', 'max:40', 'alpha_dash', 'unique:users,login'],
            // confirmed — должно совпасть с полем password_confirmation; Password::min(8) — минимум 8 символов.
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        if ($validator->fails()) {
            if (PreviewAuthToken::enabled()) {
                return $this->previewAuthError($request, '/register', 'registration');
            }

            // Возврат на форму: ошибки попадут в $errors (вывод в layouts/site и @error у полей),
            // withInput() — чтобы введённый логин не пришлось набирать заново (old('login')).
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $data = $validator->validated(); // только проверенные поля (защита от лишних полей в запросе)

        // 2. СОЗДАНИЕ ПОЛЬЗОВАТЕЛЯ. Новичок всегда получает роль player (не admin!)
        //    и стартовую машину — красный Mercedes.
        $defaultCar = Car::where('slug', 'mercedes-red')->firstOrFail();
        $user = User::create([
            'login' => $data['login'],
            'password' => $data['password'], // будет захэширован автоматически (cast 'hashed' в User)
            'role_id' => Role::where('name', 'player')->firstOrFail()->id,
            'current_car_id' => $defaultCar->id,
        ]);

        // 3. ВХОД сразу после регистрации + новый id сессии.
        //    regenerate() защищает от "фиксации сессии" (session fixation):
        //    злоумышленник не сможет заранее подсунуть свой id сессии.
        Auth::login($user);
        $request->session()->regenerate();

        // 4. ЖУРНАЛ: событие в таблицу user_activity_logs (видно в админке).
        UserActivityLog::record('auth.registered', $user, ['car_id' => $defaultCar->id, 'car_name' => $defaultCar->name]);

        // 5. РЕДИРЕКТ на главную (или туда, куда хотел попасть) с flash-сообщением.
        //    ->with('success', ...) кладёт сообщение в сессию на ОДИН следующий запрос.
        $destination = PreviewAuthToken::safeDestination((string) $request->input('preview_intended', '/'));
        if ($token = PreviewAuthToken::issue($user)) {
            $destination = PreviewAuthToken::withToken($destination, $token);
        }

        return redirect($destination)->with('success', 'Аккаунт создан. Добро пожаловать на трассу!');
    }

    /**
     * Вход.
     * Шаги: валидация → Auth::attempt (проверка логина и хэша пароля) → новая сессия → журнал → редирект.
     */
    public function login(Request $request): RedirectResponse
    {
        $validator = Validator::make($request->all(), [
            'login' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        if ($validator->fails()) {
            if (PreviewAuthToken::enabled()) {
                return $this->previewAuthError($request, '/login', 'credentials');
            }

            return redirect()->back()->withErrors($validator)->withInput();
        }

        $credentials = $validator->validated();

        // Auth::attempt: ищет пользователя по login и сравнивает пароль с bcrypt-хэшем
        // (Hash::check). Сам пароль нигде не расшифровывается — хэш необратим.
        if (! Auth::attempt($credentials)) {
            // Неудачную попытку тоже логируем (без пароля!) — админ увидит подбор паролей.
            UserActivityLog::record('auth.login_failed', null, ['login' => $credentials['login']]);

            if (PreviewAuthToken::enabled()) {
                return $this->previewAuthError($request, '/login', 'credentials');
            }

            // Общее сообщение "логин и пароль" — не подсказываем, что именно неверно
            // (иначе можно перебором узнать существующие логины).
            // onlyInput('login') — вернуть в форму логин, но НЕ пароль.
            return back()->withErrors(['login' => 'Проверьте логин и пароль.'])->onlyInput('login');
        }

        // Успех: новый id сессии (защита от session fixation) и запись в журнал.
        $request->session()->regenerate();
        UserActivityLog::record('auth.login', $request->user());

        // url.intended — адрес, куда гость пытался попасть до входа (его сохраняет middleware 'auth').
        // Пример: гость открыл /game/2 → его отправили на /login → после входа вернём на /game/2.
        $intended = (string) $request->session()->pull('url.intended', (string) $request->input('preview_intended', '/'));
        $destination = PreviewAuthToken::safeDestination($intended); // только пути нашего сайта (защита от open redirect)
        if ($token = PreviewAuthToken::issue($request->user())) {
            $destination = PreviewAuthToken::withToken($destination, $token);
        }

        return redirect()->to($destination)->with('success', 'Вход выполнен. Трасса готова к заезду.');
    }

    /**
     * Выход. Только POST + CSRF (см. routes/web.php — почему не GET).
     */
    public function logout(Request $request): RedirectResponse
    {
        // Логируем ДО выхода, пока ещё знаем, кто это.
        UserActivityLog::record('auth.logout', $request->user());
        $bridgeToken = $request->attributes->get('preview_auth_token');

        Auth::logout();                          // забыть пользователя
        $request->session()->invalidate();       // уничтожить сессию целиком
        $request->session()->regenerateToken();  // выдать новый CSRF-токен
        PreviewAuthToken::revoke($bridgeToken);  // (preview-режим) отозвать временный токен

        return redirect('/')->with('success', 'Вы вышли из аккаунта.');
    }

    /** Preview-режим без cookies: ошибку нельзя положить в сессию, поэтому передаём её в адресе. */
    private function previewAuthError(Request $request, string $path, string $error): RedirectResponse
    {
        $query = ['preview_error' => $error];
        $intended = (string) $request->input('preview_intended', '');
        if ($intended !== '') {
            $query['preview_intended'] = PreviewAuthToken::safeDestination($intended);
        }

        return redirect()->to($path.'?'.http_build_query($query));
    }
}
