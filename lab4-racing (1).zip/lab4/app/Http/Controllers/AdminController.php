<?php

namespace App\Http\Controllers;

use App\Models\RaceResult;
use App\Models\Role;
use App\Models\Track;
use App\Models\User;
use App\Models\UserActivityLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * AdminController — панель администратора.
 *
 * Защита: в routes/web.php группа /admin закрыта middleware ['auth', 'role:admin'].
 * Поэтому сюда физически не попадёт ни гость (→ /login), ни обычный игрок (→ 403).
 * В самом контроллере повторно роль проверять не нужно — это задача middleware.
 */
class AdminController extends Controller
{
    /** GET /admin — статистика, список игроков с ролями и последние события журнала. */
    public function index(): View
    {
        $users = User::with('role')->orderBy('login')->get(); // with('role') — "жадная загрузка": роли одним запросом, без N+1

        return view('admin', [
            'users' => $users,
            'usersLabel' => $this->pluralForm($users->count(), 'аккаунт', 'аккаунта', 'аккаунтов'),
            'roles' => Role::orderBy('id')->get(),
            'roleLabels' => ['player' => 'Игрок', 'admin' => 'Администратор'],
            'stats' => [
                'users' => User::count(),
                'races' => RaceResult::count(),
                'tracks' => Track::count(),
                'records' => RaceResult::where('is_personal_best', true)->count(),
            ],
            // 12 последних событий из таблицы user_activity_logs + логин и трасса (тоже жадной загрузкой).
            'activityLogs' => UserActivityLog::with(['user:id,login', 'track:id,name'])
                ->latest('created_at')
                ->limit(12)
                ->get(),
        ]);
    }

    /**
     * PATCH /admin/users/{user}/role — сменить роль игрока.
     * {user} — Route Model Binding: Laravel сам нашёл пользователя по id (нет такого → 404).
     * В форме: @method('PATCH') — HTML-формы умеют только GET/POST, Laravel подменяет метод.
     */
    public function updateUserRole(Request $request, User $user): RedirectResponse
    {
        // exists:roles,id — можно выбрать только роль, которая есть в таблице roles.
        $data = $request->validate(['role_id' => ['required', 'integer', 'exists:roles,id']]);

        // Защита от "выстрела себе в ногу": админ не может снять админку сам с себя,
        // иначе в системе может не остаться ни одного администратора.
        abort_if($request->user()->is($user) && (int) $data['role_id'] !== (int) $user->role_id, 422, 'Нельзя изменить собственную роль.');

        $oldRole = $user->role?->name;
        $user->update($data);
        $newRole = $user->fresh('role')->role?->name;

        // Журнал аудита: кто (админ), кому и какую роль поменял.
        if ($oldRole !== $newRole) {
            UserActivityLog::record('admin.role_changed', $request->user(), [
                'target_user_id' => $user->id,
                'target_login' => $user->login,
                'old_role' => $oldRole,
                'new_role' => $newRole,
            ]);
        }

        return redirect('/admin')->with('success', 'Роль игрока изменена.');
    }

    /** Русское склонение: 1 аккаунт, 2 аккаунта, 5 аккаунтов, 11 аккаунтов, 21 аккаунт. */
    private function pluralForm(int $count, string $one, string $few, string $many): string
    {
        $lastTwo = $count % 100;
        if ($lastTwo >= 11 && $lastTwo <= 14) {
            return $many;
        }

        return match ($count % 10) {
            1 => $one,
            2, 3, 4 => $few,
            default => $many,
        };
    }
}
