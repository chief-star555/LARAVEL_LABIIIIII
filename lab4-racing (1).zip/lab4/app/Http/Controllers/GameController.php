<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\RaceResult;
use App\Models\Track;
use App\Models\UserActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

/**
 * GameController — главная страница, страница игры и сохранение результата заезда.
 *
 * Сама игра (физика, отрисовка, управление) работает в БРАУЗЕРЕ на Canvas + JavaScript
 * (resources/views/game/show.blade.php). Сервер отвечает за то, чему нельзя доверить
 * браузер: кто играет, когда реально начался заезд, честность времени, запись в БД.
 *
 * Схема заезда:
 *   1. GET  /game/{track}        → show():   страница с canvas, запись game.enter
 *   2. POST /game/{track}/start  → start():  сервер запоминает ВРЕМЯ СТАРТА, выдаёт race_token (UUID)
 *   3. ...игрок едет 2 круга в браузере...
 *   4. POST /game/{track}/finish → finish(): проверка токена/времени/кругов → запись в race_results
 *
 * Почему нужен race_token: без него можно было бы отправить POST /finish
 * с любым временем, вообще не играя. Токен одноразовый и привязан к трассе.
 */
class GameController extends Controller
{
    /** Главная страница: все трассы и машины для витрины. */
    public function tracks(): View
    {
        return view('home', [
            'tracks' => Track::orderBy('id')->get(),
            'cars' => Car::orderBy('id')->get(),
        ]);
    }

    /**
     * Страница игры. Track $track — Route Model Binding (Laravel сам нашёл трассу по id из URL).
     * Маршрут под middleware 'auth', поэтому $request->user() здесь гарантированно есть.
     */
    public function show(Request $request, Track $track): View
    {
        $user = $request->user();
        // Машина, выбранная в гараже; если вдруг не выбрана — Mercedes по умолчанию.
        $car = $user->currentCar ?? Car::where('slug', 'mercedes-red')->firstOrFail();

        UserActivityLog::record('game.enter', $user, ['track' => $track->name, 'car_id' => $car->id, 'car_name' => $car->name], $track);

        // Личный рекорд именно на ЭТОЙ трассе и на ЭТОЙ машине (рекорды раздельные по машинам).
        $personalBest = $user->raceResults()
            ->where('track_id', $track->id)
            ->where('car_id', $car->id)
            ->where('is_personal_best', true)
            ->first();

        return view('game.show', ['track' => $track, 'car' => $car, 'personalBest' => $personalBest]);
    }

    /**
     * Старт заезда (вызывается из JS через fetch после отсчёта 3-2-1).
     * Сервер запоминает момент старта — дальше время считается по часам СЕРВЕРА.
     */
    public function start(Request $request, Track $track): JsonResponse
    {
        $user = $request->user();
        $car = $user->currentCar ?? Car::where('slug', 'mercedes-red')->firstOrFail();

        $token = (string) Str::uuid(); // уникальный id заезда
        // "Снимок" заезда: трасса, машина, точное время старта, игрок.
        // Машина фиксируется здесь: если игрок сменит машину в гараже во время заезда,
        // результат всё равно запишется на ту, на которой он стартовал.
        $run = ['track_id' => $track->id, 'car_id' => $car->id, 'started_at' => microtime(true), 'user_id' => $user->id];

        if ($request->attributes->get('preview_auth_user')) {
            // Preview без cookies: сессии нет — храним снимок в кэше (90 минут).
            Cache::store(config('preview_auth.cache_store', 'file'))->put($this->previewRaceKey($token), $run, now()->addMinutes(90));
        } else {
            // Обычный режим: снимок хранится в СЕССИИ пользователя — подделать его из браузера нельзя.
            $request->session()->put("race_runs.{$token}", $run);
        }

        UserActivityLog::record('race.started', $user, ['race_token' => $token, 'car_id' => $car->id, 'car_name' => $car->name, 'car_slug' => $car->slug], $track);

        return response()->json(['race_token' => $token, 'car_id' => $car->id]);
    }

    /**
     * Финиш заезда: проверить данные от браузера и сохранить результат.
     * Ответ — JSON (игра показывает окно результата).
     * Любая ошибка — статус 422 с сообщением (JSON, т.к. запрос с Accept: application/json).
     */
    public function finish(Request $request, Track $track): JsonResponse
    {
        $totalBonuses = $track->bonusCount();

        // 1. ВАЛИДАЦИЯ: каждое число в разумных пределах этой трассы.
        $data = $request->validate([
            'race_token' => ['required', 'uuid'],
            'finish_time' => ['required', 'numeric', 'min:0.1', 'max:'.($track->max_time + 10)],
            'score' => ['required', 'integer', 'min:0', 'max:200000'],
            'ending_type' => ['required', 'in:gold,normal,crash,timeout,secret'], // только известные концовки
            'bonus_count' => ['required', 'integer', 'min:0', 'max:'.$totalBonuses], // не больше, чем канистр на трассе
            'remaining_hp' => ['required', 'integer', 'min:0', 'max:100'],
            'laps_completed' => ['required', 'integer', 'min:0', 'max:'.$track->lapsRequired()],
        ]);

        // 2. ПРАВИЛО ДВУХ КРУГОВ: финиш засчитывается только после 2 кругов
        //    (авария и тайм-аут — можно раньше, это не "успешный" финиш).
        if ($data['laps_completed'] < $track->lapsRequired() && ! in_array($data['ending_type'], ['crash', 'timeout'], true)) {
            abort(422, 'Для финиша нужно проехать два круга.');
        }

        // 3. ПОИСК СНИМКА СТАРТА по race_token.
        $sessionKey = 'race_runs.'.$data['race_token'];
        $bridgeRunKey = $request->attributes->get('preview_auth_user') ? $this->previewRaceKey($data['race_token']) : null;
        $run = $bridgeRunKey
            ? Cache::store(config('preview_auth.cache_store', 'file'))->get($bridgeRunKey)
            : $request->session()->get($sessionKey);

        // Нет снимка (не стартовал / уже финишировал / чужая трасса) → отказ.
        abort_unless(
            $run
            && (int) $run['track_id'] === (int) $track->id
            && (! $bridgeRunKey || (int) ($run['user_id'] ?? 0) === (int) $request->user()->id),
            422,
            'Заезд не найден или уже завершён.'
        );

        // 4. АНТИЧИТ ПО ВРЕМЕНИ. $serverElapsed — сколько реально прошло по часам сервера.
        $serverElapsed = max(0, microtime(true) - (float) $run['started_at']);
        // Браузер не может заявить время БОЛЬШЕ реального (+5 с на задержки сети)...
        abort_if((float) $data['finish_time'] > $serverElapsed + 5, 422, 'Время заезда не совпадает с серверным.');
        // ...и МЕНЬШЕ реального: если браузер прислал "10 сек", а прошло 40 — запишем ~40
        // (0.75 с — запас на сетевую задержку). Итог не больше лимита трассы.
        $finishTime = min((float) $track->max_time, max((float) $data['finish_time'], $serverElapsed - .75));

        // 5. КОНЦОВКУ ОПРЕДЕЛЯЕТ СЕРВЕР (ending_type от клиента — только подсказка).
        $ending = $this->endingType($data, $track, $finishTime, $serverElapsed, $totalBonuses);
        $validFinish = in_array($ending, ['gold', 'normal', 'secret'], true); // авария/тайм-аут не могут быть рекордом
        $user = $request->user();

        // Машина берётся из серверного снимка старта, а НЕ из данных браузера.
        $car = Car::findOrFail((int) ($run['car_id'] ?? $user->current_car_id));

        // 6. ЗАПИСЬ В БД В ТРАНЗАКЦИИ: либо сохраняется всё (результат + рекорд + журнал), либо ничего.
        $result = DB::transaction(function () use ($user, $track, $car, $data, $finishTime, $ending, $validFinish, $request, $sessionKey, $bridgeRunKey) {
            // Текущий рекорд игрока на этой трассе и машине.
            // lockForUpdate() — блокировка строки: два одновременных финиша не создадут два рекорда.
            $best = RaceResult::where('user_id', $user->id)
                ->where('track_id', $track->id)
                ->where('car_id', $car->id)
                ->where('is_personal_best', true)
                ->lockForUpdate()
                ->first();

            // Новый рекорд, если финиш успешный и рекорда ещё нет или новое время меньше.
            $isBest = $validFinish && (! $best || $finishTime < (float) $best->finish_time);
            if ($isBest && $best) {
                $best->update(['is_personal_best' => false]); // старый рекорд снимаем — флаг всегда у одной записи
            }

            // Каждый заезд сохраняется (история в гараже), флаг is_personal_best — только у лучшего.
            $result = RaceResult::create([
                'user_id' => $user->id,
                'track_id' => $track->id,
                'car_id' => $car->id,
                'finish_time' => round($finishTime, 2),
                'score' => $data['score'],
                'ending_type' => $ending,
                'bonus_count' => $data['bonus_count'],
                'remaining_hp' => $data['remaining_hp'],
                'is_personal_best' => $isBest,
                'completed_at' => now(),
            ]);

            // Подробности заезда в журнал (metadata хранится как JSON).
            $metadata = [
                'result_id' => $result->id,
                'car_id' => $car->id,
                'car_name' => $car->name,
                'car_slug' => $car->slug,
                'finish_time' => round($finishTime, 2),
                'score' => (int) $data['score'],
                'ending_type' => $ending,
                'bonus_count' => (int) $data['bonus_count'],
                'remaining_hp' => (int) $data['remaining_hp'],
                'laps_completed' => (int) $data['laps_completed'],
                'is_personal_best' => $isBest,
            ];
            UserActivityLog::record('race.finished', $user, $metadata, $track);
            if ($isBest) {
                UserActivityLog::record('personal_record.updated', $user, $metadata, $track);
            }

            // Токен одноразовый: удаляем снимок, повторно этот же заезд отправить нельзя.
            if ($bridgeRunKey) {
                Cache::store(config('preview_auth.cache_store', 'file'))->forget($bridgeRunKey);
            } else {
                $request->session()->forget($sessionKey);
            }

            return $result;
        });

        return response()->json([
            'result_id' => $result->id,
            'finish_time' => (float) $result->finish_time,
            'score' => $result->score,
            'ending_type' => $result->ending_type,
            'is_personal_best' => $result->is_personal_best,
            'car_id' => $car->id,
            'car_name' => $car->name,
        ]);
    }

    /** Ключ кэша для снимка заезда в preview-режиме (хэш, а не сам токен). */
    private function previewRaceKey(string $raceToken): string
    {
        return 'preview-auth-race:'.hash('sha256', $raceToken);
    }

    /**
     * Концовка заезда. Порядок проверок важен (приоритет сверху вниз):
     *   crash   — прочность 0 (машина разбита);
     *   timeout — вышел лимит времени трассы (max_time);
     *   secret  — собраны ВСЕ канистры;
     *   gold    — быстрее бонусного времени (target_time);
     *   normal  — просто доехал.
     */
    private function endingType(array $data, Track $track, float $finishTime, float $serverElapsed, int $totalBonuses): string
    {
        if ((int) $data['remaining_hp'] <= 0) {
            return 'crash';
        }
        if ($serverElapsed >= $track->max_time || $finishTime >= $track->max_time) {
            return 'timeout';
        }
        if ($totalBonuses > 0 && (int) $data['bonus_count'] >= $totalBonuses) {
            return 'secret';
        }

        return $finishTime <= $track->target_time ? 'gold' : 'normal';
    }
}
