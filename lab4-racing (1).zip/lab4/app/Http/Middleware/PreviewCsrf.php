<?php

namespace App\Http\Middleware;

use App\Support\PreviewAuthToken;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;

/**
 * PreviewCsrf — защита от CSRF (подделки межсайтовых запросов).
 *
 * Что такое CSRF: злой сайт может незаметно отправить форму на наш сайт от имени
 * вошедшего пользователя (браузер сам приложит его cookie). Защита: в каждую
 * форму вставляется секретный токен @csrf, которого злой сайт не знает.
 * Для fetch-запросов из игры токен берётся из <meta name="csrf-token"> и
 * отправляется заголовком X-CSRF-TOKEN. Нет токена или он неверный → ошибка 419.
 *
 * Этот класс НАСЛЕДУЕТ стандартную защиту Laravel (PreventRequestForgery)
 * и заменяет её в группе 'web' (см. bootstrap/app.php).
 *
 * В обычном режиме (PREVIEW_AUTH_BRIDGE=false — по умолчанию) условие ниже
 * не выполняется, и вызывается parent::tokensMatch() — то есть работает
 * 100% стандартная проверка Laravel.
 *
 * Только в локальном preview без cookies (где токен сессии хранить негде)
 * CSRF подтверждается иначе: секретным preview-токеном вошедшего пользователя
 * или одноразовым токеном формы входа/регистрации.
 */
class PreviewCsrf extends PreventRequestForgery
{
    protected function tokensMatch($request)
    {
        if (PreviewAuthToken::enabled()) {
            // Пользователь подтверждён секретным токеном (64 случайных символа) — злой сайт его не знает.
            if ($request->attributes->get('preview_auth_user')) {
                return true;
            }

            // Форма входа/регистрации: одноразовый токен, выданный при открытии формы.
            if (in_array($request->path(), ['login', 'register'], true)
                && $request->isMethod('POST')
                && PreviewAuthToken::validGuestCsrf($request->input('preview_guest_csrf'))) {
                return true;
            }
        }

        // Обычная проверка Laravel: токен из формы/заголовка == токен из сессии.
        return parent::tokensMatch($request);
    }
}
