<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * PartitionSessionCookies — помощник для работы сайта внутри iframe.
 *
 * Проблема: если сайт открыт внутри чужой страницы (iframe, например в preview),
 * современные браузеры считают его cookies "сторонними" и могут их блокировать.
 * Без cookie сессии Laravel "забывает", что пользователь вошёл.
 *
 * Решение: атрибут Partitioned (технология CHIPS) — браузер хранит cookie
 * отдельно для этой пары "внешний сайт + наш сайт" и не блокирует её.
 *
 * Работает ТОЛЬКО если в .env включено:
 *   SESSION_PARTITIONED_COOKIE=true, SESSION_SAME_SITE=none и HTTPS.
 * В обычном локальном запуске (по умолчанию) — просто пропускает ответ без изменений.
 */
class PartitionSessionCookies
{
    public function handle(Request $request, Closure $next): Response
    {
        // Сначала даём приложению сформировать ответ — нас интересуют его cookies.
        $response = $next($request);

        $enabled = config('session.partitioned')
            && config('session.same_site') === 'none'
            && (config('session.secure') || $request->isSecure()); // Partitioned требует Secure (HTTPS)

        if (! $enabled) {
            return $response;
        }

        // Помечаем только cookie сессии и XSRF-TOKEN — остальные не трогаем.
        foreach ($response->headers->getCookies() as $cookie) {
            if (in_array($cookie->getName(), [config('session.cookie'), 'XSRF-TOKEN'], true)) {
                $response->headers->setCookie($cookie->withPartitioned());
            }
        }

        return $response;
    }
}
