<?php

namespace App\Http\Middleware;

use App\Support\PreviewAuthToken;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * PreviewAuthBridge — "мост" входа для локального preview, где браузер блокирует cookies.
 *
 * ВАЖНО ДЛЯ ЗАЩИТЫ ПРОЕКТА: в обычном режиме этот middleware НИЧЕГО не делает
 * (первая же строка handle() пропускает запрос дальше). Он включается только
 * при PREVIEW_AUTH_BRIDGE=true и APP_ENV=local. Основной вход — стандартная
 * Laravel-сессия (Auth::attempt + cookie).
 *
 * Если включён, на каждый запрос:
 *  1) ДО контроллера: читает ?preview_auth=ТОКЕН, находит пользователя и
 *     "логинит" его только на этот запрос (Auth::setUser — без сессии);
 *  2) ПОСЛЕ контроллера: дописывает токен во все внутренние ссылки, формы
 *     и редиректы ответа, чтобы при следующем переходе пользователь остался
 *     вошедшим.
 *
 * Пример бага, который здесь исправлен: фильтр лидерборда — это GET-форма.
 * При отправке GET-формы браузер ЗАМЕНЯЕТ параметры в action на поля формы,
 * поэтому ?preview_auth из action терялся и пользователя "выкидывало".
 * Теперь в GET-формы добавляется скрытое поле <input name="preview_auth">.
 */
class PreviewAuthBridge
{
    public function handle(Request $request, Closure $next): Response
    {
        // Обычный режим: мост выключен — сразу передаём запрос дальше.
        if (! PreviewAuthToken::enabled()) {
            return $next($request);
        }

        // ---------- 1. До контроллера: определить пользователя по токену ----------
        $token = (string) ($request->query('preview_auth') ?? $request->header('X-Preview-Auth', ''));
        $user = PreviewAuthToken::resolve($token);
        if ($user) {
            Auth::setUser($user); // пользователь считается вошедшим только в рамках этого запроса
            $request->attributes->set('preview_auth_user', $user);   // пометка для PreviewCsrf и GameController
            $request->attributes->set('preview_auth_token', $token); // нужен AuthController::logout для отзыва
        }

        // На страницах входа/регистрации выдаём одноразовый CSRF-токен для формы.
        if ($request->isMethod('GET') && in_array($request->path(), ['login', 'register'], true)) {
            $request->attributes->set('preview_guest_csrf', PreviewAuthToken::issueGuestCsrf());
        }

        $response = $next($request); // ← здесь отрабатывают остальные middleware и контроллер

        // ---------- 2. После контроллера: редиректы ----------
        if ($response->headers->has('Location')) {
            $location = $response->headers->get('Location');
            $parts = parse_url($location);

            // Трогаем только редиректы на НАШ сайт (на чужие адреса токен не отдаём).
            if ($parts !== false && (! isset($parts['host']) || strcasecmp($parts['host'], $request->getHost()) === 0)) {
                // Делаем адрес относительным ("/garage"), чтобы не увести на другой хост.
                $relative = ($parts['path'] ?? '/')
                    .(isset($parts['query']) ? '?'.$parts['query'] : '')
                    .(isset($parts['fragment']) ? '#'.$parts['fragment'] : '');
                if (! str_starts_with($relative, '/') || str_starts_with($relative, '//')) {
                    $relative = '/';
                }

                // Гостя отправили на /login (middleware 'auth') — запоминаем, куда он хотел попасть,
                // чтобы после входа вернуть его туда (аналог стандартного url.intended из сессии).
                if (! $user && ($parts['path'] ?? '') === '/login' && ! in_array($request->path(), ['login', 'register'], true)) {
                    $target = $request->getPathInfo();
                    $targetQuery = $request->query();
                    unset($targetQuery['preview_auth']);
                    if ($targetQuery) {
                        $target .= '?'.http_build_query($targetQuery);
                    }
                    $query = [];
                    parse_str($parts['query'] ?? '', $query);
                    $query['preview_intended'] = PreviewAuthToken::safeDestination($target);
                    $relative = '/login?'.http_build_query($query);
                }

                // Вошедший пользователь — токен едет дальше в адресе редиректа.
                // (Повторная проверка resolve() — после выхода токен уже отозван и не добавится.)
                if ($user && PreviewAuthToken::resolve($token)) {
                    $relative = PreviewAuthToken::withToken($relative, $token);
                }

                $response->headers->set('Location', $relative);
            }
        }

        // ---------- 3. После контроллера: HTML-страница ----------
        if ($user) {
            $isHtml = str_starts_with(strtolower($response->headers->get('Content-Type', '')), 'text/html');
            if ($isHtml && is_string($response->getContent())) {
                $response->setContent($this->carryToken($response->getContent(), $token));
            }
            // Страницу с токеном нельзя кэшировать и нельзя передавать в Referer другим сайтам.
            $response->headers->set('Cache-Control', 'no-store, private');
            $response->headers->set('Referrer-Policy', 'no-referrer');
        }

        return $response;
    }

    /**
     * Дописать токен во все ВНУТРЕННИЕ ссылки/формы HTML-страницы.
     * Внешние ссылки (http://..., //...) не трогаются — токен не уходит на чужие сайты.
     */
    private function carryToken(string $html, string $token): string
    {
        // а) <a href="/..."> и <form action="/..."> → добавить ?preview_auth=ТОКЕН
        $html = preg_replace_callback('/<(a|form)\b[^>]*>/i', function ($match) use ($token) {
            $tag = $match[0];
            $attr = strtolower($match[1]) === 'a' ? 'href' : 'action';

            return preg_replace_callback('/\b('.preg_quote($attr, '/').')=("|\')([^"\']*)\2/i', function ($a) use ($token) {
                $value = html_entity_decode($a[3], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                if (! str_starts_with($value, '/') || str_starts_with($value, '//') || str_contains($value, 'preview_auth=')) {
                    return $a[0]; // внешняя ссылка или токен уже есть
                }
                $url = htmlspecialchars(PreviewAuthToken::withToken($value, $token), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

                return $a[1].'='.$a[2].$url.$a[2];
            }, $tag);
        }, $html) ?? $html;

        // б) GET-формы (фильтр лидерборда): браузер выбрасывает параметры из action,
        //    поэтому токен передаём скрытым полем внутри формы. POST-формы не трогаем —
        //    у них параметры из action сохраняются.
        $html = preg_replace_callback('/<form\b[^>]*>/i', function ($match) use ($token) {
            $tag = $match[0];
            if (preg_match('/\bmethod\s*=\s*("|\')?\s*post\b/i', $tag)) {
                return $tag;
            }

            return $tag.'<input type="hidden" name="preview_auth" value="'.htmlspecialchars($token, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').'">';
        }, $html) ?? $html;

        // в) data-start-url / data-finish-url — адреса, на которые игра шлёт fetch-запросы.
        return preg_replace_callback('/\b(data-[a-z0-9_-]*url)=("|\')([^"\']*)\2/i', function ($a) use ($token) {
            $value = html_entity_decode($a[3], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (! str_starts_with($value, '/') || str_contains($value, 'preview_auth=')) {
                return $a[0];
            }

            return $a[1].'='.$a[2].htmlspecialchars(PreviewAuthToken::withToken($value, $token), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').$a[2];
        }, $html) ?? $html;
    }
}
