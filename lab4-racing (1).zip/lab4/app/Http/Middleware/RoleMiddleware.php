<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * RoleMiddleware — проверка РОЛИ пользователя (авторизация).
 *
 * Аутентификация  = "КТО ты?"   → это делает стандартный middleware 'auth'.
 * Авторизация     = "ЧТО тебе можно?" → это делает этот класс.
 *
 * Подключение: псевдоним 'role' в bootstrap/app.php.
 * Использование в routes/web.php: ->middleware(['auth', 'role:admin'])
 *   - сначала 'auth' убеждается, что пользователь вошёл (иначе редирект на /login);
 *   - потом 'role:admin' проверяет, что его роль = admin (иначе 403 Forbidden).
 *
 * Можно передать несколько ролей: 'role:admin,moderator' → $roles = ['admin', 'moderator'].
 */
class RoleMiddleware
{
    /**
     * @param  Closure  $next  "передать запрос дальше" (следующему middleware или контроллеру)
     * @param  string  ...$roles  разрешённые роли из строки 'role:admin'
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user(); // текущий вошедший пользователь (или null)

        // $user->role — связь belongsTo с таблицей roles (см. User::role()).
        // ?-> (nullsafe) — если роли вдруг нет, получим null, а не ошибку.
        // in_array(..., true) — строгое сравнение (тип + значение).
        if (! $user || ! in_array($user->role?->name, $roles, true)) {
            // 403 = "я знаю, кто ты, но сюда тебе нельзя". Показывается resources/views/errors/403.blade.php
            abort(403, 'У вас нет доступа к этому разделу.');
        }

        return $next($request); // проверка пройдена — пускаем дальше к контроллеру
    }
}
