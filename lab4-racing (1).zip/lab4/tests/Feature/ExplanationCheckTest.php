<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use App\Models\UserActivityLog;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Проверки поведения, которое описано в IMPLEMENTATION_RU.md
 * (чтобы каждое утверждение документа было подтверждено тестом).
 */
class ExplanationCheckTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutVite();
        $this->seed();
    }

    public function test_registration_errors_are_shown_in_russian(): void
    {
        $this->from('/register')->post('/register', ['login' => 'a b', 'password' => '123', 'password_confirmation' => '1'])
            ->assertRedirect('/register')
            ->assertSessionHasErrors(['login', 'password']);

        $errors = session('errors')->all();
        $this->assertContains('Поле «логин» может содержать только буквы, цифры, дефис и подчёркивание (без пробелов).', $errors);
        $this->assertContains('Поле «пароль» не совпадает с подтверждением.', $errors);
        foreach ($errors as $message) {
            $this->assertStringNotContainsString('validation.', $message);
        }
    }

    public function test_duplicate_login_is_rejected_with_a_russian_message(): void
    {
        $this->from('/register')->post('/register', ['login' => 'pilot', 'password' => 'racing12345', 'password_confirmation' => 'racing12345'])
            ->assertSessionHasErrors(['login' => 'Такой логин уже занят.']);
        $this->assertSame(1, User::where('login', 'pilot')->count());
    }

    public function test_password_is_stored_only_as_a_hash(): void
    {
        $this->post('/register', ['login' => 'newpilot', 'password' => 'secret-pass-1', 'password_confirmation' => 'secret-pass-1']);
        $hash = User::where('login', 'newpilot')->value('password');
        $this->assertNotSame('secret-pass-1', $hash);
        $this->assertStringStartsWith('$2y$', $hash);
        $this->assertSame('player', User::where('login', 'newpilot')->first()->role->name);
    }

    public function test_failed_login_is_logged_without_the_password(): void
    {
        $this->from('/login')->post('/login', ['login' => 'pilot', 'password' => 'wrong-password'])
            ->assertRedirect('/login')
            ->assertSessionHasErrors('login');
        $this->assertGuest();

        $log = UserActivityLog::where('event', 'auth.login_failed')->latest('id')->first();
        $this->assertNotNull($log);
        $this->assertNull($log->user_id);
        $this->assertSame(['login' => 'pilot'], $log->metadata);
        $this->assertStringNotContainsString('wrong-password', json_encode($log->getAttributes()));
    }

    public function test_login_and_logout_are_logged_and_session_is_invalidated(): void
    {
        $this->post('/login', ['login' => 'pilot', 'password' => 'racing12345'])->assertRedirect('/');
        $this->assertAuthenticated();
        $this->post('/logout')->assertRedirect('/');
        $this->assertGuest();
        $user = User::where('login', 'pilot')->first();
        $this->assertSame(['auth.login', 'auth.logout'], UserActivityLog::where('user_id', $user->id)->orderBy('id')->pluck('event')->all());
    }

    public function test_csrf_token_is_required_for_post_forms(): void
    {
        // В тестах Laravel CSRF по умолчанию отключён — включаем реальную проверку обратно.
        $this->app->instance('env', 'production');
        $this->withMiddleware();
        $response = $this->call('POST', '/login', ['login' => 'pilot', 'password' => 'racing12345']);
        $this->assertSame(419, $response->getStatusCode());
        $this->assertGuest();
    }

    public function test_guest_is_redirected_to_login_and_player_gets_403_on_admin(): void
    {
        $this->get('/garage')->assertRedirect('/login');
        $this->get('/admin')->assertRedirect('/login');
        $this->actingAs(User::where('login', 'pilot')->first())->get('/admin')->assertForbidden();
    }

    public function test_logged_in_user_cannot_open_login_form(): void
    {
        $this->actingAs(User::where('login', 'pilot')->first())->get('/login')->assertRedirect();
    }

    public function test_admin_role_change_is_logged_and_self_demotion_is_blocked(): void
    {
        $admin = User::where('login', 'admin')->first();
        $pilot = User::where('login', 'pilot')->first();
        $adminRole = Role::where('name', 'admin')->first();
        $playerRole = Role::where('name', 'player')->first();

        $this->actingAs($admin)->patch("/admin/users/{$pilot->id}/role", ['role_id' => $adminRole->id])->assertRedirect('/admin');
        $this->assertSame('admin', $pilot->fresh()->role->name);

        $log = UserActivityLog::where('event', 'admin.role_changed')->first();
        $this->assertSame($admin->id, $log->user_id);
        $this->assertSame(['target_user_id' => $pilot->id, 'target_login' => 'pilot', 'old_role' => 'player', 'new_role' => 'admin'], $log->metadata);

        $this->actingAs($admin)->patch("/admin/users/{$admin->id}/role", ['role_id' => $playerRole->id])->assertStatus(422);
        $this->assertSame('admin', $admin->fresh()->role->name);

        $this->actingAs($admin)->get('/admin')->assertOk()->assertSee('Смена роли')->assertSee('2 аккаунта');
    }

    public function test_activity_log_keeps_history_when_user_is_deleted(): void
    {
        $this->post('/login', ['login' => 'pilot', 'password' => 'racing12345']);
        $user = User::where('login', 'pilot')->first();
        $logId = UserActivityLog::where('user_id', $user->id)->value('id');
        $this->post('/logout');
        $user->delete();
        $this->assertNull(UserActivityLog::find($logId)->user_id);
    }

    public function test_login_is_rate_limited_against_password_guessing(): void
    {
        for ($i = 0; $i < 10; $i++) {
            $this->post('/login', ['login' => 'pilot', 'password' => 'wrong-'.$i])->assertRedirect();
        }
        $this->post('/login', ['login' => 'pilot', 'password' => 'racing12345'])
            ->assertStatus(429)
            ->assertSee('Слишком много');
        $this->assertGuest();

        // Другой логин с того же IP не заблокирован.
        $this->post('/login', ['login' => 'admin', 'password' => 'racing12345'])->assertRedirect('/');
        $this->assertAuthenticated();
    }
}
