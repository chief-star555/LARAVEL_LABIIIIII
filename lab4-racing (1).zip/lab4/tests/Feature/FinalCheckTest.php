<?php

namespace Tests\Feature;

use App\Models\Car;
use App\Models\RaceResult;
use App\Models\Track;
use App\Models\User;
use App\Support\PreviewAuthToken;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FinalCheckTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutVite();
        $this->seed();
    }

    private function enablePreviewBridge(): void
    {
        config(['preview_auth.enabled' => true, 'preview_auth.cache_store' => 'array']);
        $this->app->detectEnvironment(fn () => 'local');
    }

    public function test_leaderboard_filter_form_keeps_the_preview_session_token(): void
    {
        $this->enablePreviewBridge();
        $player = User::where('login', 'pilot')->firstOrFail();
        $token = PreviewAuthToken::issue($player);
        $this->assertNotNull($token);
        $html = $this->get('/leaderboard?preview_auth='.$token)->assertOk()->assertSee('pilot')->getContent();
        // GET forms drop the action query string, so the token must be a hidden field inside the filter form.
        $this->assertMatchesRegularExpression('/<form class="filter-form"[^>]*><input type="hidden" name="preview_auth" value="'.preg_quote($token, '/').'">/', $html);
        // POST forms (logout) keep the token in the action and do not get a duplicate field.
        $this->assertDoesNotMatchRegularExpression('/<form class="logout-form"[^>]*><input type="hidden" name="preview_auth"/', $html);
        $track = Track::where('slug', 'maze')->first() ?? Track::orderByDesc('id')->firstOrFail();
        $car = Car::orderByDesc('id')->firstOrFail();
        $this->get('/leaderboard?preview_auth='.$token.'&track_id='.$track->id)->assertOk()->assertSee('class="user-badge">pilot', false)->assertSee('Выйти');
        $this->get('/leaderboard?preview_auth='.$token.'&track_id='.$track->id.'&car_id='.$car->id)->assertOk()->assertSee('class="user-badge">pilot', false);
    }

    public function test_leaderboard_ignores_malformed_filters_instead_of_redirecting(): void
    {
        $player = User::where('login', 'pilot')->firstOrFail();
        $this->actingAs($player);
        foreach (['track_id=abc', 'track_id=999999', 'car_id=-1', 'track_id[]=1', 'track_id=1&car_id=zz'] as $query) {
            $this->get('/leaderboard?'.$query)->assertOk()->assertSee('Кто быстрее?');
        }
        $this->assertAuthenticatedAs($player);
    }

    public function test_leaderboard_filters_records_by_track_and_car(): void
    {
        $player = User::where('login', 'pilot')->firstOrFail();
        $ring = Track::where('slug', 'ring')->firstOrFail();
        $snake = Track::where('slug', 'snake')->firstOrFail();
        $mercedes = Car::where('slug', 'mercedes-red')->firstOrFail();
        $bugatti = Car::where('slug', 'bugatti-blue')->firstOrFail();
        RaceResult::create(['user_id' => $player->id, 'track_id' => $ring->id, 'car_id' => $mercedes->id, 'finish_time' => 33.33, 'score' => 9000, 'ending_type' => 'gold', 'bonus_count' => 0, 'remaining_hp' => 90, 'is_personal_best' => true, 'completed_at' => now()]);
        RaceResult::create(['user_id' => $player->id, 'track_id' => $snake->id, 'car_id' => $bugatti->id, 'finish_time' => 55.55, 'score' => 8000, 'ending_type' => 'normal', 'bonus_count' => 0, 'remaining_hp' => 70, 'is_personal_best' => true, 'completed_at' => now()]);
        $this->get('/leaderboard?track_id='.$ring->id)->assertOk()->assertSee('33.33')->assertDontSee('55.55');
        $this->get('/leaderboard?car_id='.$bugatti->id)->assertOk()->assertSee('55.55')->assertDontSee('33.33');
        $this->get('/leaderboard?track_id='.$ring->id.'&car_id='.$bugatti->id)->assertOk()->assertSee('Рекордов пока нет');
        $this->get('/leaderboard?track_id='.$ring->id)->assertSee('<option value="'.$ring->id.'" selected', false);
    }

    public function test_game_hud_shows_speed_in_sidebar_and_on_the_canvas(): void
    {
        $player = User::where('login', 'pilot')->firstOrFail();
        $track = Track::where('slug', 'ring')->firstOrFail();
        $html = $this->actingAs($player)->get(route('game.show', $track))->assertOk()->assertSee('id="speed-value"', false)->assertSee('id="canvas-speed"', false)->assertSee('Максимум', false)->getContent();
        // The speed card sits right below the car card, above the timer, so it stays on screen during a race.
        $this->assertLessThan(strpos($html, 'id="timer"'), strpos($html, 'id="speed-card"'));
        $this->assertStringContainsString("el('canvas-speed').textContent=String(speed)", $html);
    }

    public function test_lap_counter_tracks_progress_along_the_route(): void
    {
        $player = User::where('login', 'pilot')->firstOrFail();
        foreach (Track::all() as $track) {
            $this->actingAs($player)->get(route('game.show', $track))->assertOk()->assertSee('function trackRouteProgress()', false)->assertSee('lapProgress>=L-3', false)->assertSee('resetRouteProgress();', false);
        }
    }

    public function test_finish_rejects_times_faster_than_the_server_clock_and_guests(): void
    {
        $track = Track::where('slug', 'ring')->firstOrFail();
        $this->postJson(route('game.start', $track))->assertUnauthorized();
        $player = User::where('login', 'pilot')->firstOrFail();
        $this->actingAs($player);
        $token = $this->postJson(route('game.start', $track))->assertOk()->json('race_token');
        $this->postJson(route('game.finish', $track), ['race_token' => $token, 'finish_time' => 60, 'score' => 9000, 'ending_type' => 'gold', 'bonus_count' => 0, 'remaining_hp' => 90, 'laps_completed' => 2])->assertStatus(422);
        $this->postJson(route('game.finish', $track), ['race_token' => 'not-a-uuid', 'finish_time' => 1, 'score' => 1, 'ending_type' => 'gold', 'bonus_count' => 0, 'remaining_hp' => 90, 'laps_completed' => 2])->assertStatus(422);
        $this->assertSame(0, RaceResult::count());
    }

    public function test_slower_run_does_not_replace_the_personal_best(): void
    {
        $track = Track::where('slug', 'ring')->firstOrFail();
        $player = User::where('login', 'pilot')->firstOrFail();
        $this->actingAs($player);
        $first = $this->postJson(route('game.start', $track))->json('race_token');
        $this->postJson(route('game.finish', $track), ['race_token' => $first, 'finish_time' => 0.1, 'score' => 9000, 'ending_type' => 'gold', 'bonus_count' => 0, 'remaining_hp' => 90, 'laps_completed' => 2])->assertOk()->assertJson(['is_personal_best' => true]);
        $second = $this->postJson(route('game.start', $track))->json('race_token');
        $this->travel(3)->seconds();
        $this->postJson(route('game.finish', $track), ['race_token' => $second, 'finish_time' => 2.5, 'score' => 8000, 'ending_type' => 'gold', 'bonus_count' => 0, 'remaining_hp' => 90, 'laps_completed' => 2])->assertOk()->assertJson(['is_personal_best' => false]);
        $this->assertSame(1, RaceResult::where('user_id', $player->id)->where('is_personal_best', true)->count());
    }

    public function test_admin_cannot_change_own_role_but_can_promote_a_player(): void
    {
        $admin = User::where('login', 'admin')->firstOrFail();
        $player = User::where('login', 'pilot')->firstOrFail();
        $playerRole = $player->role_id;
        $this->actingAs($admin)->patch(route('admin.users.update-role', $admin), ['role_id' => $playerRole])->assertStatus(422);
        $this->actingAs($admin)->patch(route('admin.users.update-role', $player), ['role_id' => $admin->role_id])->assertRedirect('/admin');
        $this->assertSame((int) $admin->role_id, (int) $player->fresh()->role_id);
    }

    public function test_logout_revokes_the_preview_token(): void
    {
        $this->enablePreviewBridge();
        $player = User::where('login', 'pilot')->firstOrFail();
        $token = PreviewAuthToken::issue($player);
        $this->post('/logout?preview_auth='.$token)->assertRedirect('/');
        $this->assertNull(PreviewAuthToken::resolve($token));
    }
}
