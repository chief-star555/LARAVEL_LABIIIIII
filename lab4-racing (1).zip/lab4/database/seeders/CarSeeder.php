<?php

namespace Database\Seeders;

use App\Models\Car;
use App\Models\RaceResult;
use App\Models\User;
use Illuminate\Database\Seeder;

/**
 * Три машины игры. slug — постоянный текстовый ключ (код ищет 'mercedes-red' как машину по умолчанию).
 * Характеристики: Mercedes — сбалансированный, Lamborghini — лучший руль, Bugatti — максимальная скорость.
 */
class CarSeeder extends Seeder
{
    public function run(): void
    {
        $cars = [
            ['slug' => 'mercedes-red', 'name' => 'Mercedes-AMG GT', 'brand' => 'Mercedes-Benz', 'color_name' => 'Красный', 'color_hex' => '#e6463d', 'accent_hex' => '#ffad80', 'body_style' => 'sedan', 'description' => 'Уверенный седан с предсказуемым управлением.', 'top_speed' => 178, 'acceleration' => 150, 'handling' => 1.00],
            ['slug' => 'lamborghini-yellow', 'name' => 'Lamborghini Huracán', 'brand' => 'Lamborghini', 'color_name' => 'Жёлтый', 'color_hex' => '#f4c52e', 'accent_hex' => '#fff0a1', 'body_style' => 'supercar', 'description' => 'Лёгкий суперкар с резким разгоном и отзывчивым рулём.', 'top_speed' => 198, 'acceleration' => 170, 'handling' => 1.08],
            ['slug' => 'bugatti-blue', 'name' => 'Bugatti Chiron', 'brand' => 'Bugatti', 'color_name' => 'Синий', 'color_hex' => '#2f79d4', 'accent_hex' => '#9bd6ff', 'body_style' => 'hypercar', 'description' => 'Мощный гиперкар с высокой максимальной скоростью.', 'top_speed' => 215, 'acceleration' => 182, 'handling' => 0.96],
        ];
        foreach ($cars as $car) {
            Car::updateOrCreate(['slug' => $car['slug']], $car);
        }

        $defaultCarId = Car::where('slug', 'mercedes-red')->value('id');
        // Старые аккаунты и результаты (до появления машин) получают Mercedes, чтобы ничего не потерялось.
        User::whereNull('current_car_id')->update(['current_car_id' => $defaultCarId]);
        RaceResult::whereNull('car_id')->update(['car_id' => $defaultCarId]);
    }
}
