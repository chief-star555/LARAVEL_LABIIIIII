<?php

namespace Database\Seeders;

use App\Models\Track;
use Illuminate\Database\Seeder;

/**
 * Три трассы. Карта строится не вручную, а функцией $makeLoop из ключевых точек (поворотов):
 * между соседними точками рисуется прямая линия дороги на сетке 16×12, остальное — стены '#'.
 * Первая клетка петли — финиш F, вторая — старт S. $objects ставит канистры 'B' в нужные клетки.
 * Так трасса гарантированно замкнутая и без развилок.
 */
class TrackSeeder extends Seeder
{
    public function run(): void
    {
        // Точки должны идти строго по горизонтали или вертикали (без диагоналей).
        $makeLoop = function (array $waypoints, array $objects = []): array {
            $points = [];
            for ($i = 0; $i < count($waypoints) - 1; $i++) {
                [$x,$y] = $waypoints[$i];
                [$endX,$endY] = $waypoints[$i + 1];
                $dx = $endX <=> $x;
                $dy = $endY <=> $y;
                if ($dx !== 0 && $dy !== 0) {
                    throw new \InvalidArgumentException('Track waypoints must be axis aligned.');
                }
                while ($x !== $endX || $y !== $endY) {
                    if (! $points) {
                        $points[] = [$x, $y];
                    }
                    $x += $dx;
                    $y += $dy;
                    $points[] = [$x, $y];
                }
            }
            if (count($points) > 1 && $points[count($points) - 1] === $points[0]) {
                array_pop($points);
            }
            $grid = array_fill(0, 12, array_fill(0, 16, '#'));
            foreach ($points as $index => [$x,$y]) {
                $cell = $index === 0 ? 'F' : ($index === 1 ? 'S' : '.');
                $cell = $objects["$x:$y"] ?? $cell;
                if ($index < 2) {
                    $cell = $index === 0 ? 'F' : 'S'; // F и S нельзя перекрыть канистрой
                }
                $grid[$y][$x] = $cell;
            }

            return array_map(fn (array $row) => implode('', $row), $grid);
        };
        $tracks = [
            ['slug' => 'ring', 'name' => 'Кольцо', 'description' => 'Широкий прямоугольный автодром с длинными прямыми и плавными поворотами. Два круга — канистры по пути.', 'difficulty' => 'Лёгкая', 'grid' => $makeLoop([[4, 2], [12, 2], [12, 9], [3, 9], [3, 2], [4, 2]], ['8:2' => 'B', '8:9' => 'B']), 'tile_size' => 40, 'start_direction' => 'right', 'target_time' => 82, 'max_time' => 155],
            ['slug' => 'snake', 'name' => 'Змейка', 'description' => 'Закрытая ломаная петля с несколькими шпильками и сменой ритма. Два круга потребуют точного управления.', 'difficulty' => 'Средняя', 'grid' => $makeLoop([[4, 2], [12, 2], [12, 7], [9, 7], [9, 10], [4, 10], [4, 5], [2, 5], [2, 2], [4, 2]], ['9:2' => 'B', '5:10' => 'B']), 'tile_size' => 40, 'start_direction' => 'right', 'target_time' => 105, 'max_time' => 190],
            ['slug' => 'maze', 'name' => 'Лабиринт', 'description' => 'Техническая асимметричная петля с узкими связками, резкими поворотами и несколькими длинными участками. Два круга до финиша.', 'difficulty' => 'Сложная', 'grid' => $makeLoop([[7, 2], [12, 2], [12, 4], [10, 4], [10, 6], [13, 6], [13, 10], [3, 10], [3, 7], [6, 7], [6, 5], [2, 5], [2, 2], [7, 2]], ['9:2' => 'B', '4:10' => 'B']), 'tile_size' => 40, 'start_direction' => 'right', 'target_time' => 130, 'max_time' => 230],
        ];
        foreach ($tracks as $track) {
            Track::updateOrCreate(['slug' => $track['slug']], $track);
        }
    }
}
