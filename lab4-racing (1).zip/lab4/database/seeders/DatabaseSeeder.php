<?php

namespace Database\Seeders;

use App\Models\Car;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;

/**
 * Главный сидер: `php artisan migrate:fresh --seed` заполняет БД стартовыми данными.
 * Порядок важен: роли → машины → пользователи → трассы.
 * updateOrCreate/firstOrCreate — сидер можно запускать повторно, дублей не будет.
 */
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $player = Role::firstOrCreate(['name' => 'player']);
        $admin = Role::firstOrCreate(['name' => 'admin']);
        $this->call(CarSeeder::class);
        // Демо-аккаунты для проверки (пароль хэшируется автоматически cast'ом 'hashed').
        // pilot — обычный игрок, admin — администратор. Перед публикацией сменить пароли!
        User::updateOrCreate(['login' => 'pilot'], ['password' => 'racing12345', 'role_id' => $player->id]);
        User::updateOrCreate(['login' => 'admin'], ['password' => 'racing12345', 'role_id' => $admin->id]);
        // Всем без машины — стартовый Mercedes.
        $defaultCarId = Car::where('slug', 'mercedes-red')->value('id');
        User::whereNull('current_car_id')->update(['current_car_id' => $defaultCarId]);
        $this->call(TrackSeeder::class);
    }
}
