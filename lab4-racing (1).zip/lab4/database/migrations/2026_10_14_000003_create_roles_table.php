<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/*
 | Таблица roles — справочник ролей. Сразу заполняется двумя ролями: player и admin.
 | Заполнение прямо в миграции — потому что без ролей приложение не работает
 | (регистрация ищет роль player).
*/
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique(); // 'player' / 'admin'
            $table->timestamps();
        });
        $now = now();
        DB::table('roles')->insert([
            ['name' => 'player', 'created_at' => $now, 'updated_at' => $now], ['name' => 'admin', 'created_at' => $now, 'updated_at' => $now],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};
