<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/*
 | Перевод users.role (строка) → users.role_id (внешний ключ на roles.id).
 | Шаги: 1) добавить role_id; 2) перенести данные (admin → id админа, остальные → player);
 | 3) повесить внешний ключ и удалить старую колонку role. Данные при этом не теряются.
 |
 | restrictOnDelete: роль НЕЛЬЗЯ удалить, пока к ней привязан хоть один пользователь
 | (иначе у пользователей была бы "висячая" ссылка).
*/
return new class extends Migration
{
    public function up(): void
    {
        $playerId = DB::table('roles')->where('name', 'player')->value('id');
        $adminId = DB::table('roles')->where('name', 'admin')->value('id');
        Schema::table('users', function (Blueprint $table) {
            $table->unsignedBigInteger('role_id')->nullable()->index();
        });
        DB::table('users')->where('role', 'admin')->update(['role_id' => $adminId]);
        DB::table('users')->where('role', '!=', 'admin')->update(['role_id' => $playerId]);
        DB::table('users')->whereNull('role_id')->update(['role_id' => $playerId]);
        Schema::table('users', function (Blueprint $table) {
            // FOREIGN KEY users.role_id → roles.id
            $table->foreign('role_id')->references('id')->on('roles')->restrictOnDelete();
            $table->dropColumn('role');
        });
    }

    // Откат: возвращаем строковую колонку role и данные в неё.
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role')->default('player');
        });
        $adminId = DB::table('roles')->where('name', 'admin')->value('id');
        DB::table('users')->where('role_id', $adminId)->update(['role' => 'admin']);
        DB::table('users')->where('role_id', '!=', $adminId)->update(['role' => 'player']);
        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['role_id']);
            $table->dropColumn('role_id');
        });
    }
};
