<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | users.current_car_id — машина, выбранная в гараже.
 | nullOnDelete: если машину удалят, у игрока просто станет null (код подставит Mercedes),
 | а сам пользователь не пострадает.
*/
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('current_car_id')->nullable()->constrained('cars')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('current_car_id');
        });
    }
};
