<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | Таблица tracks — трассы. Карта хранится в grid (JSON-массив строк, см. app/Models/Track.php).
 | Заполняет TrackSeeder.
*/
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tracks', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('name');
            $table->text('description');
            $table->string('difficulty', 20);
            $table->json('grid');                                    // карта: ['####...', '#F.S..#', ...]
            $table->unsignedSmallInteger('tile_size')->default(40);
            $table->string('start_direction', 10)->default('up');
            $table->unsignedSmallInteger('target_time');             // секунд на "золотой" финиш
            $table->unsignedSmallInteger('max_time');                // лимит, после — тайм-аут
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tracks');
    }
};
