<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | Миграция = описание структуры таблицы кодом. `php artisan migrate` выполняет up(),
 | `php artisan migrate:rollback` — down() (откат). Порядок задаёт дата в имени файла.
 |
 | Таблица users — пользователи. Вход по ЛОГИНУ (без email — по заданию).
 | Колонка role здесь временная: следующая миграция (2026_10_14_000004) переносит её
 | в отдельную таблицу roles и удаляет.
*/
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();                          // BIGINT автоинкремент, первичный ключ
            $table->string('login')->unique();     // UNIQUE: два одинаковых логина невозможны даже на уровне БД
            $table->string('password');            // только bcrypt-хэш (~60 символов), не сам пароль
            $table->string('role')->default('player');
            $table->timestamps();                  // created_at, updated_at
        });

        // Стандартная таблица Laravel для сброса пароля (ключ — login). В проекте не используется.
        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('login')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });
        // СЕССИИ (SESSION_DRIVER=database): здесь Laravel хранит, кто вошёл.
        // Браузер хранит только id сессии в cookie; payload — зашифрованные данные сессии
        // (id пользователя, CSRF-токен, flash-сообщения, снимки заездов race_runs).
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sessions');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('users');
    }
};
