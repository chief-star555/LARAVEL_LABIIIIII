<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | Таблица user_activity_logs — журнал действий (что пишется — см. app/Models/UserActivityLog.php).
 |
 | user_id и track_id NULLABLE + nullOnDelete:
 |   - null нужен для событий гостя (auth.login_failed — пользователь не вошёл);
 |   - при удалении пользователя журнал НЕ удаляется, а ссылка обнуляется — история аудита сохраняется.
 | Индексы: по event (фильтр по типу события) и (user_id, created_at) (лента событий игрока по времени).
*/
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_activity_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('track_id')->nullable()->constrained()->nullOnDelete();
            $table->string('event', 60)->index();
            $table->json('metadata')->nullable();          // подробности события в JSON
            $table->string('ip_address', 45)->nullable();   // 45 символов — хватает и для IPv6
            $table->text('user_agent')->nullable();
            $table->timestamp('created_at')->useCurrent(); // только время создания: журнал не редактируется
            $table->index(['user_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_activity_logs');
    }
};
