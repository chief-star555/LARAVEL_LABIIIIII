<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | race_results.car_id — на какой машине проехан заезд. Рекорды и лидерборд — раздельные по машинам.
 | nullable — для старых результатов, созданных до появления машин (CarSeeder проставит им Mercedes).
 | Индексы повторяют старые, но с car_id — под фильтр лидерборда и поиск рекорда на конкретной машине.
*/
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('race_results', function (Blueprint $table) {
            $table->foreignId('car_id')->nullable()->constrained('cars')->nullOnDelete();
            $table->index(['track_id', 'car_id', 'is_personal_best', 'finish_time'], 'race_results_car_lb_idx');
            $table->index(['user_id', 'track_id', 'car_id', 'is_personal_best'], 'race_results_car_best_idx');
        });
    }

    public function down(): void
    {
        Schema::table('race_results', function (Blueprint $table) {
            $table->dropIndex('race_results_car_lb_idx');
            $table->dropIndex('race_results_car_best_idx');
            $table->dropConstrainedForeignId('car_id');
        });
    }
};
