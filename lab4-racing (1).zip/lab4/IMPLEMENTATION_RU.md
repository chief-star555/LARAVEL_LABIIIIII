# «Пит-стоп» — полное объяснение проекта для защиты

> Laravel 13 · PHP 8.3+ · Blade · SQLite/PostgreSQL · Canvas + Vanilla JS · Vite
> Демо-аккаунты: **pilot / racing12345** (игрок), **admin / racing12345** (администратор)

Документ построен так, чтобы по нему можно было отвечать на вопросы преподавателя: что где лежит, что за что отвечает и **почему сделано именно так**. Поясняющие комментарии на русском есть и в самом коде, поэтому на защите можно открыть нужный файл и показать.

---

## Оглавление

1. [Что это за проект — за 30 секунд](#1-что-это-за-проект--за-30-секунд)
2. [Архитектура: MVC и путь запроса](#2-архитектура-mvc-и-путь-запроса)
3. [Карта файлов: кто за что отвечает](#3-карта-файлов-кто-за-что-отвечает)
4. [Маршруты и уровни доступа](#4-маршруты-и-уровни-доступа)
5. [Middleware — цепочка проверок](#5-middleware--цепочка-проверок)
6. [Регистрация — пошагово](#6-регистрация--пошагово)
7. [Вход и выход — пошагово](#7-вход-и-выход--пошагово)
8. [Сессии, cookie и CSRF](#8-сессии-cookie-и-csrf)
9. [База данных: таблицы, связи, ключи, индексы](#9-база-данных-таблицы-связи-ключи-индексы)
10. [Модели Eloquent](#10-модели-eloquent)
11. [Журнал действий: что логируется](#11-журнал-действий-что-логируется)
12. [Игра: как устроен заезд](#12-игра-как-устроен-заезд)
13. [Сохранение результата и античит](#13-сохранение-результата-и-античит)
14. [Личный рекорд и лидерборд](#14-личный-рекорд-и-лидерборд)
15. [Гараж и админ-панель](#15-гараж-и-админ-панель)
16. [Безопасность — сводная таблица](#16-безопасность--сводная-таблица)
17. [Preview-мост (зачем PreviewAuth*)](#17-preview-мост-зачем-previewauth)
18. [Тесты](#18-тесты)
19. [Запуск проекта](#19-запуск-проекта)
20. [Вопросы преподавателя и ответы](#20-вопросы-преподавателя-и-ответы)
21. [Шпаргалка по Laravel-терминам](#21-шпаргалка-по-laravel-терминам)

---

## 1. Что это за проект — за 30 секунд

Сайт аркадных гонок с видом сверху. Пользователь:

1. **регистрируется** или **входит** (логин и пароль);
2. выбирает **машину** в гараже (Mercedes, Lamborghini, Bugatti — у каждой своя скорость, разгон и управляемость);
3. выбирает **трассу** («Кольцо», «Змейка», «Лабиринт») и проезжает **2 круга**;
4. результат **сохраняется в БД**, лучший становится **личным рекордом** и попадает в **лидерборд**;
5. **администратор** видит статистику, меняет роли и читает **журнал действий** всех пользователей.

**Как разделена работа:**

| Где | Что делает |
|---|---|
| **Браузер** (JS + Canvas) | Физика, отрисовка, управление, подсчёт кругов |
| **Сервер** (Laravel) | Авторизация, роли, время старта, проверка честности результата, запись в БД, журнал, лидерборд |

**Главный принцип:** браузеру не доверяем. Всё, что можно подделать (время, машину, концовку), сервер перепроверяет.

---

## 2. Архитектура: MVC и путь запроса

Проект построен по **MVC** (Model — View — Controller):

| Слой | Где | Пример |
|---|---|---|
| **Model** — данные и связи | `app/Models` | `User`, `RaceResult`, `UserActivityLog` |
| **View** — HTML-шаблоны | `resources/views` (Blade) | `auth/login.blade.php`, `game/show.blade.php` |
| **Controller** — логика запроса | `app/Http/Controllers` | `AuthController::login()` |
| **Middleware** — проверки до контроллера | `app/Http/Middleware` + встроенные | `auth`, `guest`, `role:admin`, CSRF |
| **Routes** — URL → контроллер | `routes/web.php` | `POST /login → AuthController@login` |

### Путь одного запроса — пример `POST /login`

```
Браузер
  │  POST /login  (login, password, _token)
  ▼
public/index.php  ── точка входа, загружает bootstrap/app.php
  ▼
Глобальные middleware: TrustProxies, проверка размера POST, …,
                       PartitionSessionCookies, PreviewAuthBridge (наши)
  ▼
Группа 'web': EncryptCookies → StartSession → ShareErrorsFromSession → PreviewCsrf (CSRF)
  ▼
Middleware маршрута: guest (только для гостей), throttle:auth (≤ 10 попыток в минуту)
  ▼
AuthController@login  ── валидация, Auth::attempt, журнал
  ▼
redirect('/') + flash «Вход выполнен»  ── ответ идёт обратно через те же middleware
                                          (сессия сохраняется в таблицу sessions, cookie уходит браузеру)
```

> **Если спросят «где Kernel.php?»** В Laravel 11+ его нет. Middleware регистрируются в `bootstrap/app.php` через `->withMiddleware(...)`.

---

## 3. Карта файлов: кто за что отвечает

```
app/
├── Http/
│   ├── Controllers/
│   │   ├── AuthController.php        регистрация, вход, выход
│   │   ├── GameController.php        главная, страница игры, старт и финиш заезда (античит)
│   │   ├── GarageController.php      «Мой гараж»: статистика, выбор машины, достижения
│   │   ├── LeaderboardController.php топ-10 личных рекордов с фильтрами
│   │   └── AdminController.php       админ-панель: статистика, роли, журнал
│   └── Middleware/
│       ├── RoleMiddleware.php          проверка роли (role:admin) → 403
│       ├── PreviewCsrf.php             CSRF-защита (наследник стандартной Laravel)
│       ├── PartitionSessionCookies.php cookie для встроенного окна предпросмотра
│       └── PreviewAuthBridge.php       запасной вход без cookie (только preview, см. §17)
├── Models/          User, Role, Car, Track, RaceResult, UserActivityLog
├── Providers/AppServiceProvider.php  лимит попыток входа (защита от подбора пароля)
└── Support/PreviewAuthToken.php      токены preview-моста

bootstrap/app.php        регистрация middleware, алиас 'role', JSON-ошибки
routes/web.php           все 14 маршрутов и уровни доступа
config/auth.php          guard 'web' (сессия) + provider 'users' (Eloquent User)
config/preview_auth.php  настройки preview-моста (по умолчанию выключен)
lang/ru/validation.php   русские тексты ошибок валидации

database/
├── migrations/          структура БД (11 файлов, по порядку дат)
└── seeders/             роли, 3 машины, 3 трассы, демо-аккаунты

resources/
├── views/
│   ├── layouts/site.blade.php    общий макет (csrf-token, flash, ошибки)
│   ├── components/               шапка, подвал, рисунок машины
│   ├── auth/                     формы входа и регистрации
│   ├── game/show.blade.php       Canvas-игра (весь JS игры здесь)
│   ├── leaderboard/, garage/, admin.blade.php, home.blade.php
│   └── errors/                   свои страницы 403, 404, 419, 429, 500
└── css/app.css                   стили (собирает Vite → public/build)

tests/Feature/           42 автотеста
```

---

## 4. Маршруты и уровни доступа

Файл: `routes/web.php`. Команда для показа: `php artisan route:list --except-vendor`.

| Метод | URL | Контроллер | Доступ |
|---|---|---|---|
| GET | `/` | GameController@tracks | все |
| GET | `/leaderboard` | LeaderboardController@index | все |
| GET | `/login` | AuthController@loginForm | **guest** |
| POST | `/login` | AuthController@login | **guest** + throttle |
| GET | `/register` | AuthController@registerForm | **guest** |
| POST | `/register` | AuthController@register | **guest** + throttle |
| POST | `/logout` | AuthController@logout | **auth** |
| GET | `/garage` | GarageController@show | **auth** |
| POST | `/garage/car` | GarageController@selectCar | **auth** |
| GET | `/game/{track}` | GameController@show | **auth** |
| POST | `/game/{track}/start` | GameController@start | **auth** |
| POST | `/game/{track}/finish` | GameController@finish | **auth** |
| GET | `/admin` | AdminController@index | **auth + role:admin** |
| PATCH | `/admin/users/{user}/role` | AdminController@updateUserRole | **auth + role:admin** |

**Четыре уровня доступа:**

| Уровень | Что происходит, если условие не выполнено |
|---|---|
| Публичный | — |
| `guest` | Вошедшего пользователя перенаправит на `/` (регистрироваться повторно незачем) |
| `auth` | Гостя перенаправит на `/login`, а после входа вернёт туда, куда он шёл (`url.intended`) |
| `role:admin` | Не-админ получит **403** |

**`{track}` и `{user}`** — это *Route Model Binding*: Laravel сам достаёт из БД запись по id из URL. Если записи нет — **404**.

**Почему выход через POST, а не ссылку GET?** На GET-ссылку можно сослаться с чужого сайта (`<img src="/logout">`), и пользователя разлогинит без его ведома. POST требует CSRF-токен.

**Почему PATCH для роли?** PATCH означает частичное изменение ресурса: меняем одно поле. HTML-формы умеют только GET и POST, поэтому в форме стоит `@method('PATCH')` — скрытое поле `_method`, по которому Laravel подменяет метод.

---

## 5. Middleware — цепочка проверок

*Middleware* — это «фильтр» между запросом и контроллером. Он может пропустить запрос дальше (`$next($request)`), перенаправить его или прервать с ошибкой.

### Встроенные (Laravel)

| Middleware | Что делает |
|---|---|
| `EncryptCookies` | Шифрует cookie, чтобы их нельзя было подделать |
| `StartSession` | Загружает сессию по cookie (в ней хранится, кто вошёл) |
| `ShareErrorsFromSession` | Передаёт `$errors` в шаблоны |
| `auth` | Пускает только вошедших, гостя — на `/login` (настроено `redirectGuestsTo('/login')`) |
| `guest` | Пускает только гостей |
| `throttle:auth` | Ограничивает число попыток (лимитер описан в `AppServiceProvider`) |
| `TrustProxies` | Правильный IP и протокол за прокси (нужно для журнала и ссылок) |

### Наши (`app/Http/Middleware`)

**`RoleMiddleware`** — проверка роли. Регистрируется в `bootstrap/app.php` под коротким именем `'role'`:

```php
// routes/web.php
->middleware(['auth', 'role:admin'])

// RoleMiddleware::handle($request, $next, string ...$roles)
if (! $user || ! in_array($user->role?->name, $roles, true)) {
    abort(403, 'У вас нет доступа к этому разделу.');
}
return $next($request);
```

- `...$roles` — можно передать несколько ролей: `role:admin,moderator`.
- Роль берётся **из БД** (`$user->role->name`), а не из формы и не из cookie, поэтому подделать её нельзя.
- Кнопка «Админ» в шапке скрыта для игроков, но это только удобство. **Реальная защита — middleware**: если набрать `/admin` вручную, придёт 403.

**`PreviewCsrf`** — наследник стандартного `PreventRequestForgery` (CSRF-защита). В обычном режиме вызывает родительскую проверку: токен из формы должен совпасть с токеном в сессии. Дополнительные ветки работают только в preview-режиме (§17).

**`PartitionSessionCookies`** и **`PreviewAuthBridge`** — техническая поддержка встроенного окна предпросмотра (§17). На обычную работу сайта не влияют.

---

## 6. Регистрация — пошагово

**Файлы:** `resources/views/auth/register.blade.php` → `POST /register` → `AuthController::register()`

### Форма

```html
<form method="POST" action="/register">
    @csrf                                   <!-- скрытое поле _token -->
    <input name="login" value="{{ old('login') }}" autocomplete="username">
    <input type="password" name="password" autocomplete="new-password">
    <input type="password" name="password_confirmation">   <!-- имя важно для правила confirmed -->
</form>
```

### Шаги на сервере

**1. Валидация** (`Validator::make`):

| Поле | Правило | Смысл |
|---|---|---|
| login | `required` | обязательно |
| | `string`, `min:3`, `max:40` | 3–40 символов |
| | `alpha_dash` | только буквы, цифры, `-`, `_`, без пробелов |
| | `unique:users,login` | логин ещё не занят |
| password | `required` | обязательно |
| | `confirmed` | совпадает с `password_confirmation` |
| | `Password::min(8)` | не короче 8 символов |

Если ошибка, срабатывает `redirect()->back()->withErrors($validator)->withInput()`: возврат на форму, ошибки показываются на русском (`lang/ru/validation.php`), логин остаётся в поле (`old('login')`).

**2. Создание пользователя:**

```php
User::create([
    'login' => ...,
    'password' => $data['password'],   // хэшируется АВТОМАТИЧЕСКИ (cast 'hashed' в модели User)
    'role_id' => Role::where('name', 'player')->firstOrFail()->id,   // всегда игрок, не админ
    'current_car_id' => <id красного Mercedes>,                       // стартовая машина
]);
```

**3. Вход:** `Auth::login($user)`, затем `session()->regenerate()` — новый id сессии (защита от *session fixation*).

**4. Журнал:** `auth.registered` с `{car_id, car_name}`.

**5. Редирект** на главную с flash-сообщением «Аккаунт создан…».

### Почему так

- **`unique` проверяется дважды**: правилом валидации (красивое сообщение) и `UNIQUE`-индексом в БД (железная гарантия, даже при двух одновременных запросах).
- **Роль `player` назначает сервер.** Поля роли в форме нет, а лишние поля отсекаются: в `create` идут только `validated()`-данные, и в модели задан `$fillable`.
- **HTML-атрибут `required`** — только удобство: его легко убрать в DevTools, поэтому главная проверка серверная.

---

## 7. Вход и выход — пошагово

### Вход: `POST /login` → `AuthController::login()`

1. Сначала срабатывает **`throttle:auth`**: не больше 10 попыток в минуту на пару «логин + IP», иначе **429**.
2. **Валидация:** `login` и `password` обязательны.
3. **`Auth::attempt(['login' => …, 'password' => …])`:**
   - находит пользователя по `login`;
   - сравнивает пароль с bcrypt-хэшем (`Hash::check`). Хэш **необратим**: пароль не расшифровывается, а хэшируется заново и сравнивается.
4. **Неудача:**
   - в журнал пишется `auth.login_failed` с `{login}`, `user_id = null`, **без пароля**;
   - возврат на форму с ошибкой «Проверьте логин и пароль.» и `onlyInput('login')`: логин вернётся в поле, пароль — нет;
   - сообщение специально **общее**: не говорим, что именно неверно, иначе перебором можно узнать существующие логины.
5. **Успех:** `session()->regenerate()`, затем журнал `auth.login`, затем редирект на `url.intended` (страницу, куда гость шёл до входа) или на `/`.

### Выход: `POST /logout` → `AuthController::logout()`

```php
UserActivityLog::record('auth.logout', $user);  // пишем ДО выхода, пока знаем, кто это
Auth::logout();                                 // забыть пользователя
$request->session()->invalidate();              // уничтожить сессию целиком
$request->session()->regenerateToken();         // новый CSRF-токен
```

### Конфигурация (`config/auth.php`)

- **guard `web`**, драйвер `session`: пользователь хранится в сессии;
- **provider `users`**, драйвер `eloquent`, модель `App\Models\User`.

---

## 8. Сессии, cookie и CSRF

### Как сайт «помнит», что вы вошли

1. После входа Laravel кладёт `user_id` в **сессию**.
2. Сессия хранится **в таблице `sessions`** (`SESSION_DRIVER=database`).
3. Браузер получает **cookie** только с **id сессии**. Cookie зашифрована, `HttpOnly` (недоступна из JS) и `SameSite=Lax`.
4. На каждом запросе `StartSession` по cookie находит сессию, Laravel берёт из неё `user_id`, и становятся доступны `$request->user()` и `@auth`.
5. Время жизни сессии — 120 минут неактивности (`SESSION_LIFETIME`).

### Что ещё хранится в сессии

- CSRF-токен;
- flash-сообщения (`->with('success', …)` живут один запрос);
- ошибки валидации и `old()`-значения;
- `url.intended`;
- **снимки начатых заездов** `race_runs.{token}` (§13).

### CSRF (Cross-Site Request Forgery)

**Атака:** злой сайт содержит скрытую форму `POST https://наш-сайт/logout` или `/admin/users/5/role`. Браузер жертвы сам приложит её cookie, и действие выполнится от её имени.

**Защита:**

- в каждой POST/PATCH-форме стоит `@csrf` (скрытое поле `_token`), JS-запросы игры шлют заголовок `X-CSRF-TOKEN` из `<meta name="csrf-token">`;
- middleware сверяет этот токен с токеном в сессии. Злой сайт его не знает, потому что не может прочитать наши страницы (same-origin policy);
- нет токена или он неверный — ответ **419 Page Expired** (своя страница `errors/419.blade.php`).

---

## 9. База данных: таблицы, связи, ключи, индексы

### ER-схема

```
roles 1───∞ users 1───∞ race_results ∞───1 tracks
              │  \            │
              │   \           ∞
              │    \──────1 cars          (users.current_car_id → cars.id)
              │               1
              │               └──∞ race_results.car_id
              │
              └──1───∞ user_activity_logs ∞───1 tracks   (обе ссылки nullable)

sessions.user_id → users.id (стандартная таблица Laravel)
```

### Таблицы

**`roles`** — справочник ролей. Заполняется прямо в миграции значениями `player` и `admin`.

| Колонка | Тип | Примечание |
|---|---|---|
| id | bigint PK | |
| name | string UNIQUE | `player` / `admin` |
| created_at, updated_at | timestamp | |

**`users`** — пользователи.

| Колонка | Тип | Примечание |
|---|---|---|
| id | bigint PK | |
| login | string **UNIQUE** | вход по логину (по заданию, без email) |
| password | string | **bcrypt-хэш**, не пароль |
| role_id | FK → roles.id, **restrictOnDelete** | нельзя удалить роль, пока у неё есть пользователи |
| current_car_id | FK → cars.id, nullable, **nullOnDelete** | машина из гаража; удалили машину — станет null, код подставит Mercedes |
| created_at, updated_at | | |

**`cars`** — машины (CarSeeder).

| Колонка | Тип | Примечание |
|---|---|---|
| id | bigint PK | |
| slug | string UNIQUE | `mercedes-red`, `lamborghini-yellow`, `bugatti-blue` |
| name, brand, color_name, description | string | |
| color_hex, accent_hex | string(7) | цвета для отрисовки |
| body_style | string | `sedan` / `supercar` / `hypercar` |
| top_speed | smallint | Mercedes 178, Lamborghini 198, Bugatti 215 |
| acceleration | smallint | 150 / 170 / 182 |
| handling | decimal(3,2) | 1.00 / 1.08 / 0.96 |

**`tracks`** — трассы (TrackSeeder).

| Колонка | Тип | Примечание |
|---|---|---|
| id, slug (UNIQUE), name, description, difficulty | | |
| grid | **json** | карта 16×12 символов: `#` стена, `.` дорога, `F` финиш, `S` старт, `B` канистра |
| tile_size | smallint | размер клетки (px) |
| start_direction | string | направление машины на старте |
| target_time | smallint | время «золотого» финиша (Кольцо 82 с, Змейка 105 с, Лабиринт 130 с) |
| max_time | smallint | лимит (155 / 190 / 230 с), после него тайм-аут |

**`race_results`** — каждый заезд.

| Колонка | Тип | Примечание |
|---|---|---|
| id | PK | |
| user_id | FK → users, **cascadeOnDelete** | удалили игрока — удалились его результаты |
| track_id | FK → tracks, **cascadeOnDelete** | |
| car_id | FK → cars, nullable, nullOnDelete | |
| finish_time | **decimal(8,2)** | точное десятичное, не float |
| score | unsigned int | очки |
| ending_type | string | `gold` / `normal` / `secret` / `crash` / `timeout` |
| bonus_count | smallint | собрано канистр |
| remaining_hp | tinyint | прочность на финише |
| is_personal_best | boolean | лучший заезд игрока на этой трассе и машине |
| completed_at, created_at, updated_at | timestamp | |

Индексы `race_results`:

| Индекс | Колонки | Для чего |
|---|---|---|
| `race_results_leaderboard_idx` | track_id, is_personal_best, finish_time | лидерборд по трассе |
| `race_results_personal_best_idx` | user_id, track_id, is_personal_best | поиск рекорда игрока |
| `race_results_car_lb_idx` | track_id, car_id, is_personal_best, finish_time | лидерборд с фильтром по машине |
| `race_results_car_best_idx` | user_id, track_id, car_id, is_personal_best | поиск рекорда при финише |

**`user_activity_logs`** — журнал (§11).

| Колонка | Тип | Примечание |
|---|---|---|
| id | PK | |
| user_id | FK nullable, **nullOnDelete** | null для гостя (неудачный вход); удалили пользователя — **журнал остаётся** |
| track_id | FK nullable, nullOnDelete | |
| event | string(60), **индекс** | код события |
| metadata | json nullable | подробности |
| ip_address | string(45) | 45 символов хватает для IPv6 |
| user_agent | text | браузер |
| created_at | timestamp | updated_at нет: журнал не редактируется |

Дополнительный индекс: (user_id, created_at).

**Служебные таблицы Laravel:**

- `sessions` — сессии;
- `cache` и `cache_locks` — кэш и счётчики лимитера попыток;
- `jobs` и `failed_jobs` — очереди, не используются;
- `password_reset_tokens` — по логину, не используется.

### Почему каскады разные

| Связь | Правило | Логика |
|---|---|---|
| Результат → игрок/трасса | **CASCADE** | результат без игрока бессмысленен |
| Журнал → игрок | **SET NULL** | журнал аудита нельзя терять при удалении пользователя |
| Пользователь → роль | **RESTRICT** | нельзя удалить роль, оставив пользователей «без роли» |
| Пользователь → машина | **SET NULL** | пользователь не должен пропасть из-за удаления машины |

### Почему роль в отдельной таблице, а не строка

Это нормализация. Внешний ключ не даст записать несуществующую роль, а новую роль можно добавить строкой в таблице без изменения структуры. Миграция `2026_10_14_000004` **переносит данные** из старой колонки `users.role` в `role_id` и только потом удаляет колонку, поэтому данные не теряются. У неё есть `down()` для отката.

### Миграции по порядку

1. `0001_01_01_000000` — users, password_reset_tokens, sessions
2. `0001_01_01_000001` и `000002` — cache, jobs (стандартные)
3. `2026_10_14_000003` — roles и заполнение player/admin
4. `2026_10_14_000004` — users.role (строка) → users.role_id (FK)
5. `2026_11_17_000001` — tracks
6. `2026_11_17_000002` — race_results и 2 индекса
7. `2026_11_17_000003` — user_activity_logs
8. `2026_11_17_000004` — cars
9. `2026_11_17_000005` — users.current_car_id
10. `2026_11_17_000006` — race_results.car_id и 2 индекса

### Сидеры

`DatabaseSeeder` заполняет данные в порядке роли → `CarSeeder` → пользователи pilot/admin → `TrackSeeder`. Везде `updateOrCreate` / `firstOrCreate`, поэтому сидер можно запускать повторно без дублей.

Трассы **не рисуются вручную**: функция `$makeLoop` строит замкнутую петлю из точек поворота. Поэтому трасса гарантированно замкнута, без развилок, F и S стоят рядом.

---

## 10. Модели Eloquent

| Модель | Связи | Важное |
|---|---|---|
| `User` (extends `Authenticatable`) | `role()` belongsTo, `currentCar()` belongsTo, `raceResults()` hasMany, `activityLogs()` hasMany | `$fillable`, `$hidden = [password, remember_token]`, cast `password => hashed` |
| `Role` | `users()` hasMany | |
| `Car` | `drivers()` hasMany (по current_car_id), `raceResults()` hasMany | casts чисел |
| `Track` | `raceResults()` hasMany | cast `grid => array`, `bonusCount()`, `lapsRequired() = 2`, `circuitCells()`, `previewPath()` |
| `RaceResult` | `user()`, `track()`, `car()` belongsTo | casts: decimal:2, boolean, datetime |
| `UserActivityLog` | `user()`, `track()` belongsTo | `$timestamps = false`, cast `metadata => array`, статический `record()` |

Термины, о которых могут спросить:

- **`$fillable`** — защита от *mass assignment*. В `create()`/`update()` попадут только перечисленные поля, даже если в запрос подсунуть `role_id`.
- **cast `hashed`** — пароль хэшируется при присваивании автоматически, поэтому в контроллере нет `Hash::make`.
- **Жадная загрузка `with()`** — `User::with('role')` загружает роли **одним** запросом вместо N отдельных (проблема N+1). Используется в лидерборде и админке.

---

## 11. Журнал действий: что логируется

**Модель:** `UserActivityLog`. **Таблица:** `user_activity_logs`. Запись делается одной строкой из любого места:

```php
UserActivityLog::record('race.finished', $user, $metadata, $track);
```

Метод `record()` сам добавляет **IP-адрес**, **user-agent** (браузер) и **время**.

| Событие | Где | user_id | metadata |
|---|---|---|---|
| `auth.registered` | AuthController::register | новый игрок | car_id, car_name (стартовая машина) |
| `auth.login` | AuthController::login | игрок | — |
| `auth.login_failed` | AuthController::login | **null** | login (какой логин пробовали) — **пароль никогда** |
| `auth.logout` | AuthController::logout | игрок | — |
| `garage.car_selected` | GarageController::selectCar | игрок | car_id, car_name, car_slug |
| `game.enter` | GameController::show | игрок | track, car_id, car_name; + track_id |
| `race.started` | GameController::start | игрок | race_token, car_id, car_name, car_slug; + track_id |
| `race.finished` | GameController::finish | игрок | result_id, машина, finish_time, score, ending_type, bonus_count, remaining_hp, laps_completed, is_personal_best |
| `personal_record.updated` | GameController::finish | игрок | то же, что race.finished (только при новом рекорде) |
| `admin.role_changed` | AdminController::updateUserRole | **админ** | target_user_id, target_login, old_role, new_role |

**Где смотреть:** `/admin`, блок «Последние события» (12 последних, с переводом кодов на русский). Через консоль:

```
php artisan tinker
>>> App\Models\UserActivityLog::latest('created_at')->take(10)->get(['event','user_id','metadata','ip_address'])
```

**Почему таблица в БД, а не `storage/logs/laravel.log`?**

- События связаны внешними ключами с пользователем и трассой;
- их можно фильтровать SQL-запросами (по индексам `event` и `(user_id, created_at)`);
- их удобно показывать в админке.

Файл `laravel.log` при этом остаётся для технических ошибок приложения.

**Зачем логировать неудачные входы?** Чтобы администратор видел попытки подбора пароля. Пароль не пишется, иначе журнал сам стал бы утечкой.

---

## 12. Игра: как устроен заезд

**Файл:** `resources/views/game/show.blade.php` — разметка и весь JS игры, с комментариями по блокам.

### Данные из PHP в JS

Используется `Js::from($track->grid)`, `Js::from([...машина...])` — безопасная сериализация в JSON, которая экранирует кавычки и `</script>`.

### Игровой цикл

`requestAnimationFrame(frame)` вызывается браузером примерно 60 раз в секунду. На каждом кадре:

1. **`dt`** — секунды с прошлого кадра (не больше 0.05). Скорость умножается на `dt`, поэтому игра одинакова на 60 Гц и 144 Гц мониторах.
2. **Газ:** `speed += acceleration·dt` (до `top_speed`). **Тормоз и задний ход:** до −70. **Без педалей:** плавное замедление `speed·e^(−1.15·dt)`.
3. **Поворот:** зависит от скорости и `handling` машины.
4. **Движение:** `x += cos(angle)·speed·dt`, `y += sin(angle)·speed·dt`.
5. **`handleSurfaces`:**
   - **стена** — откат, отскок, −11 % прочности (не чаще раза в 650 мс);
   - **канистра** — +750 очков и +24 % прочности;
   - **финиш** — засчитать круг.
6. **HUD:** таймер, **скорость** (число в км/ч и шкала), прочность, очки, круги. Затем **отрисовка** на Canvas.

### Подсчёт кругов (защита от «срезания»)

- `buildRoute()` строит упорядоченный маршрут S → … → F. Это тот же алгоритм, что `Track::circuitCells()` в PHP.
- На каждом кадре ищется ближайшая точка маршрута рядом с текущей. Движение вперёд увеличивает `lapProgress`, назад — уменьшает.
- Круг засчитывается при пересечении F, **только если пройден почти весь маршрут по порядку** (`lapReady`).
- Поэтому нельзя «намотать» круг, катаясь туда-сюда через финишную линию.

### Концовки

| Концовка | Условие |
|---|---|
| `crash` | прочность 0 |
| `timeout` | вышло `max_time` |
| `secret` | собраны все канистры |
| `gold` | время ≤ `target_time` |
| `normal` | просто доехал |

### Очки

`10000 − время·55 + 750·канистры + прочность·12`

### Связь с сервером

Два `fetch`-запроса с заголовками `X-CSRF-TOKEN` и `Accept: application/json`:

- **`POST /game/{id}/start`** перед стартом: сервер выдаёт `race_token`;
- **`POST /game/{id}/finish`** после финиша: сервер проверяет данные и сохраняет. В окне результата показываются **данные, которые вернул сервер**.

---

## 13. Сохранение результата и античит

**Проблема:** игра в браузере, значит любой может открыть DevTools и отправить `POST /finish` с `finish_time: 1`.

**Решение:** сервер ведёт свой учёт времени (`GameController`).

### `start()`

```php
$token = Str::uuid();
session()->put("race_runs.$token", [
    'track_id' => …, 'car_id' => …, 'user_id' => …,
    'started_at' => microtime(true),          // время старта по часам СЕРВЕРА
]);
UserActivityLog::record('race.started', …);
return ['race_token' => $token];
```

Снимок хранится **в сессии на сервере**, браузер его не видит и не может изменить.

### `finish()` — проверки по порядку

1. **Валидация каждого поля** в границах конкретной трассы:
   - `finish_time` ≤ max_time + 10;
   - `bonus_count` ≤ числа канистр на трассе;
   - `remaining_hp` от 0 до 100;
   - `ending_type` только из списка;
   - `laps_completed` ≤ 2.
2. **Правило двух кругов:** успешный финиш при `laps_completed < 2` даёт 422.
3. **Токен:** снимок должен существовать и относиться к **этой** трассе. Иначе 422 «Заезд не найден или уже завершён».
4. **Время по серверным часам:** `serverElapsed = now − started_at`.
   - Заявлено **больше**, чем прошло (+5 с на сеть) — 422.
   - Заявлено **меньше**: записывается `max(заявлено, serverElapsed − 0.75)`. Прислать «10 секунд», если прошло 40, бесполезно — запишется около 40.
5. **Концовку определяет сервер** (`endingType()`), а не клиент.
6. **Машина берётся из снимка старта**, а не из запроса и не из текущего гаража. Если сменить машину во время заезда, результат запишется на ту, на которой стартовал.
7. **Транзакция и `lockForUpdate()`** (подробнее в §14).
8. **Токен одноразовый:** после записи снимок удаляется из сессии. Повторная отправка того же заезда даёт 422.

**Если спросят «можно ли всё равно смухлевать?»** Можно ехать идеально с помощью бота: это общая проблема всех браузерных игр. Но **нельзя** записать время быстрее реального, засчитать финиш без старта, записать один заезд дважды, указать больше канистр, чем есть на трассе, или подменить машину.

---

## 14. Личный рекорд и лидерборд

### Личный рекорд

Рекорд считается для тройки **игрок + трасса + машина**. В БД сохраняются **все** заезды (история в гараже), а флаг `is_personal_best = true` стоит **ровно у одного** — лучшего успешного.

```php
DB::transaction(function () {
    $best = RaceResult::where(user, track, car)->where('is_personal_best', true)
                      ->lockForUpdate()->first();          // блокируем строку
    $isBest = $validFinish && (!$best || $finishTime < $best->finish_time);
    if ($isBest && $best) $best->update(['is_personal_best' => false]);   // снять старый флаг
    RaceResult::create([... 'is_personal_best' => $isBest]);
    UserActivityLog::record('race.finished', …);
    if ($isBest) UserActivityLog::record('personal_record.updated', …);
});
```

- **Транзакция:** результат, флаг рекорда и журнал записываются **вместе или не записываются вовсе**.
- **`lockForUpdate()`:** если два финиша придут одновременно, второй подождёт первого, и двух «рекордов» не будет.
- Авария и тайм-аут **сохраняются**, но **не могут быть рекордом** (`$validFinish`).

### Лидерборд (`LeaderboardController`)

```php
RaceResult::with(['user:id,login', 'track:id,name', 'car:id,name,color_name'])  // без N+1
    ->where('is_personal_best', true)                  // только личные рекорды
    ->when($trackId, fn ($q) => $q->where('track_id', $trackId))
    ->when($carId,   fn ($q) => $q->where('car_id', $carId))
    ->orderBy('finish_time')      // быстрее — выше
    ->orderByDesc('score')        // при равном времени — больше очков
    ->orderBy('id')               // при полном равенстве — кто раньше
    ->limit(10)->get();
```

- **Почему только личные рекорды?** Иначе один игрок занял бы весь топ своими попытками.
- **Фильтры** передаются через GET (`?track_id=2&car_id=3`), поэтому ссылкой можно поделиться. Мусорные значения вроде `?track_id=abc` не дают ошибку, а означают «Все» (`filterId()`).
- **Запрос покрыт индексом** `race_results_car_lb_idx` / `leaderboard_idx`.

---

## 15. Гараж и админ-панель

### Гараж (`/garage`, GarageController)

Всё считается на лету из `race_results` текущего игрока, отдельных таблиц для статистики нет:

- **сводка:** всего заездов, золотых финишей, рекордов на активной машине, сумма очков;
- **выбор машины:** `POST /garage/car` с проверкой `exists:cars,id`, журнал `garage.car_selected`;
- **рекорды** на активной машине по каждой трассе и **место** игрока среди всех (сортировка как в лидерборде);
- **активность за 7 дней** (мини-график) и **история** 8 последних заездов;
- **6 достижений:** «Первый финиш», «Золотая каска», «Чистая линия», «Охотник за бонусами», «Мастер маршрутов», «Не сдавайся».

### Админ-панель (`/admin`, AdminController, доступ `auth` + `role:admin`)

- **Статистика:** аккаунты, заезды, трассы, рекорды.
- **Таблица игроков и смена роли.**
  - `PATCH` с `@csrf`, проверка `exists:roles,id`.
  - **Админ не может снять роль сам с себя** (422), иначе в системе может не остаться администраторов.
  - Каждая смена роли пишется в журнал `admin.role_changed`.
- **Лента 12 последних событий журнала.**

---

## 16. Безопасность — сводная таблица

| Угроза | Защита | Где |
|---|---|---|
| Кража паролей из БД | bcrypt-хэш (12 раундов), пароль не хранится и не логируется | cast `hashed` в User |
| Подбор пароля | ≤ 10 попыток в минуту на «логин + IP», затем 429; неудачи в журнале | `throttle:auth`, AppServiceProvider |
| Перебор логинов | общее сообщение «Проверьте логин и пароль» | AuthController |
| CSRF | `@csrf` / `X-CSRF-TOKEN`, иначе 419 | PreviewCsrf (наследник Laravel) |
| Session fixation | `session()->regenerate()` после входа и регистрации | AuthController |
| Кража cookie через JS | cookie `HttpOnly`, зашифрована | config/session.php, EncryptCookies |
| XSS | `{{ }}` экранирует вывод; `{!! !!}` для данных пользователя не используется; `Js::from` для JS | Blade |
| SQL-инъекции | Eloquent и Query Builder (подготовленные запросы с параметрами) | везде |
| Mass assignment (подсунуть `role_id`) | `$fillable` + `validated()` | модели, контроллеры |
| Доступ к чужим разделам | `auth`, `role:admin` → редирект / 403 | routes/web.php, RoleMiddleware |
| Повышение прав при регистрации | роль `player` назначает сервер | AuthController |
| Подделка результата | серверное время, одноразовый токен, валидация, концовку решает сервер | GameController |
| Open redirect после входа | `safeDestination()` — только пути своего сайта | PreviewAuthToken |
| Гонка двух запросов | транзакция и `lockForUpdate` | GameController::finish |
| Утечка деталей ошибок | `APP_DEBUG=false` в production, свои страницы 403/404/419/429/500 | resources/views/errors |

---

## 17. Preview-мост (зачем PreviewAuth*)

Проект проверялся во **встроенном окне предпросмотра** (iframe на другом домене). Современные браузеры там **блокируют cookie**, поэтому сессия не сохраняется и пользователя «выкидывает» после каждого клика.

Для этого есть запасной механизм. Он **выключен по умолчанию** и работает только при **`PREVIEW_AUTH_BRIDGE=true` И `APP_ENV=local`**:

- **`PreviewAuthToken`** выдаёт после входа случайный 64-символьный токен. В кэше хранится только его **sha256-хэш**, срок жизни 12 часов, при выходе токен отзывается.
- **`PreviewAuthBridge`** (middleware) узнаёт пользователя по токену в адресе и добавляет токен во внутренние ссылки и формы.
- **`PreviewCsrf`** в этом режиме принимает секретный токен вместо cookie-сессии.
- **`PartitionSessionCookies`** помечает cookie как *Partitioned* (CHIPS), чтобы браузеры разрешили их во встроенном окне.

**Что сказать преподавателю:** «Это техническая поддержка среды разработки. На реальном сервере (`APP_ENV=production`) мост автоматически отключён, и вход работает стандартной сессией Laravel». Это проверяется в коде: `PreviewAuthToken::enabled()`.

---

## 18. Тесты

Запуск: `php artisan test`. Результат: **42 теста, 325 проверок, все проходят.** Тесты используют БД SQLite в памяти и не трогают рабочую БД (`phpunit.xml`).

| Файл | Что проверяет |
|---|---|
| `tests/Feature/ExampleTest.php` (22) | страницы и ошибки; трассы замкнуты и уникальны; регистрация пишет в журнал и даёт Mercedes; выбор машины; машина берётся из старта; финиш без 2 кругов отклоняется; авария не рекорд; повторная отправка заезда отклоняется; админ-доступ |
| `tests/Feature/FinalCheckTest.php` (9) | фильтр лидерборда не разлогинивает; мусорные фильтры игнорируются; фильтр по трассе и машине; скорость видна в панели и на canvas; подсчёт кругов по маршруту; время быстрее серверного отклоняется, гость не может финишировать; медленный заезд не заменяет рекорд; админ не меняет свою роль; выход отзывает preview-токен |
| `tests/Feature/ExplanationCheckTest.php` (11) | **утверждения этого документа**: русские ошибки валидации; занятый логин; пароль хранится как bcrypt-хэш, роль player; неудачный вход логируется без пароля; вход/выход в журнале; **CSRF → 419**; гость → /login, игрок на /admin → 403; вошедший не видит /login; смена роли логируется, себя разжаловать нельзя; журнал сохраняется после удаления пользователя (SET NULL); **лимит попыток → 429** |

`RefreshDatabase` пересоздаёт БД перед каждым тестом, поэтому тесты независимы.

---

## 19. Запуск проекта

```bash
composer install
npm install && npm run build          # собрать CSS/JS в public/build
cp .env.example .env                  # Windows: copy .env.example .env
php artisan key:generate              # ключ шифрования cookie и сессий
# SQLite: создать пустой файл database/database.sqlite и указать DB_CONNECTION=sqlite
php artisan migrate:fresh --seed      # таблицы + роли, машины, трассы, демо-аккаунты
php artisan serve                     # http://127.0.0.1:8000
php artisan test                      # автотесты
```

Подробная инструкция (PostgreSQL, Windows, частые ошибки) — в `GUIDE_RU.txt`.

---

## 20. Вопросы преподавателя и ответы

### Авторизация и регистрация

**— Где хранится пароль?**
В `users.password` лежит только bcrypt-хэш вида `$2y$12$…`. Хэширует cast `'password' => 'hashed'` в модели User. Расшифровать хэш нельзя: при входе `Auth::attempt` хэширует введённый пароль и сравнивает.

**— Почему не `md5`/`sha1`?**
Они быстрые, поэтому их легко перебрать. bcrypt специально медленный (cost 12) и использует соль: одинаковые пароли дают разные хэши.

**— Как Laravel понимает, что пользователь вошёл?**
Через сессию. `user_id` хранится в таблице `sessions`, у браузера в cookie только id сессии. Middleware `StartSession` восстанавливает сессию на каждом запросе.

**— Что будет, если зарегистрироваться с логином, который уже есть?**
Правило `unique:users,login` вернёт ошибку «Такой логин уже занят.» Даже в обход валидации БД не даст это сделать из-за UNIQUE-индекса.

**— Можно ли зарегистрироваться сразу админом, добавив `role_id` в форму?**
Нет. Роль назначает сервер (`Role::where('name','player')`), в `create()` идут только `validated()`-поля. Тест это подтверждает.

**— Зачем `session()->regenerate()`?**
Защита от *session fixation*: злоумышленник мог заранее подсунуть жертве известный ему id сессии. После входа id меняется, и старый становится бесполезным.

**— Зачем `invalidate()` и `regenerateToken()` при выходе?**
`invalidate` полностью уничтожает сессию со всеми данными. `regenerateToken` выдаёт новый CSRF-токен, чтобы старые открытые формы стали недействительными.

**— Что такое `url.intended`?**
Middleware `auth` запоминает адрес, куда гость пытался попасть. После входа `AuthController` возвращает пользователя туда.

**— Есть ли защита от подбора пароля?**
Да. `throttle:auth` пропускает не больше 10 попыток в минуту на пару «логин + IP», потом ответ 429. Все неудачи пишутся в журнал как `auth.login_failed`.

### Middleware

**— Что такое middleware и зачем свой?**
Это фильтр перед контроллером. Свой `RoleMiddleware` проверяет роль из БД и отвечает 403. Он зарегистрирован алиасом `role` в `bootstrap/app.php`, поэтому в маршрутах можно писать `role:admin`.

**— Чем `auth` отличается от `role:admin`?**
`auth` проверяет, что пользователь вошёл (иначе редирект на `/login`). `role:admin` проверяет права вошедшего (иначе 403). Поэтому на `/admin` стоят оба, по порядку.

**— Почему кнопку «Админ» скрыли, но всё равно нужен middleware?**
Скрытая кнопка — это интерфейс, URL можно набрать руками. Безопасность обеспечивает только сервер.

**— Где регистрируются middleware, если нет Kernel.php?**
В `bootstrap/app.php`, метод `withMiddleware()` (Laravel 11+).

### CSRF и XSS

**— Что такое CSRF и как защищено?**
Подделка запроса с чужого сайта от имени жертвы. В каждой форме стоит `@csrf`, у JS заголовок `X-CSRF-TOKEN`. Middleware сверяет токен с сессией, без токена ответ 419. Есть тест.

**— Как защищено от XSS?**
`{{ $x }}` в Blade экранирует HTML (`<script>` выведется текстом). В JS данные передаются через `Js::from()`.

**— А SQL-инъекции?**
Все запросы идут через Eloquent и Query Builder, значения передаются параметрами (prepared statements). Склейки SQL-строк с вводом пользователя нет. Единственный «сырой» фрагмент — `selectRaw('COUNT(*) as races, COALESCE(SUM(score), 0) as points')` в гараже, это константа без пользовательских данных.

### База данных

**— Почему роли в отдельной таблице?**
Это нормализация и ссылочная целостность: FK не даст несуществующую роль, новую роль можно добавить без изменения схемы.

**— Что такое `cascadeOnDelete`, `nullOnDelete`, `restrictOnDelete` и почему они разные?**
Это поведение при удалении родительской записи.

- Результаты без игрока не нужны → **CASCADE**.
- Журнал аудита терять нельзя → **SET NULL**.
- Роль, у которой есть пользователи, удалять нельзя → **RESTRICT**.

**— Зачем индексы и почему составные?**
Чтобы лидерборд и поиск рекорда не перебирали всю таблицу. Порядок колонок в индексе совпадает с WHERE и ORDER BY: `(track_id, car_id, is_personal_best, finish_time)`.

**— Почему `finish_time` decimal, а не float?**
float хранит числа приближённо (38.45 может стать 38.4499999). decimal хранит их точно, а это важно для сравнения рекордов.

**— Почему `grid` — JSON?**
Карта — это массив строк, который читается целиком. Отдельная таблица клеток (16×12 = 192 строки на трассу) ничего бы не дала.

**— Зачем сидеры, если есть миграции?**
Миграции описывают **структуру**, сидеры — **данные** (машины, трассы, демо-аккаунты). Исключение — роли: без них регистрация не работает, поэтому они вставляются прямо в миграции.

**— Что делает миграция с ролями при откате?**
`down()` возвращает строковую колонку `role` и переносит в неё данные обратно.

### Журнал

**— Что логируется?**
10 событий: регистрация, вход, неудачный вход, выход, выбор машины, вход на трассу, старт, финиш, новый рекорд, смена роли. У каждого есть IP, браузер и время. Полный список — в §11.

**— Почему пароль не пишется даже при неудачном входе?**
Часто человек ошибается на одну букву, и такой «неверный» пароль почти совпадает с настоящим. Журнал стал бы утечкой.

**— Что будет с журналом при удалении пользователя?**
`user_id` станет NULL (`nullOnDelete`), а записи останутся. Есть тест.

### Игра и античит

**— Где считается время?**
Время для HUD считает браузер, но **решающее** время — серверное: сервер запомнил `started_at` в `start()` и сравнивает при `finish()`.

**— Можно ли отправить рекорд через Postman?**
Нет.

- Без `start()` нет токена, ответ 422.
- Время быстрее реального сервер заменит на реальное.
- Повторно тот же токен использовать нельзя.
- Нужна авторизация и CSRF.

**— Зачем транзакция при финише?**
Результат, снятие старого рекорда и запись в журнал должны произойти вместе. `lockForUpdate` защищает от двух одновременных финишей.

**— Почему рекорды раздельные по машинам?**
Машины разные по скорости. Сравнивать Bugatti с Mercedes нечестно, поэтому в лидерборде есть фильтр по машине.

**— Как засчитывается круг?**
Машина должна пройти маршрут трассы по порядку (`lapProgress`) и пересечь финиш. Ездить туда-сюда через финишную линию бесполезно.

**— Почему игра одинаковая на любом мониторе?**
Всё движение умножается на `dt` — время кадра в секундах.

### Общие

**— Почему Laravel, а не чистый PHP?**
Готовые и проверенные механизмы: сессии, хэширование, CSRF, валидация, ORM, миграции, тесты. Самописные версии — частый источник уязвимостей.

**— Чем GET отличается от POST в формах проекта?**
- GET используется для **чтения** (фильтр лидерборда): параметры видны в адресе, ссылкой можно поделиться.
- POST/PATCH используются для **изменения** данных и паролей: параметры не попадают в адрес и историю браузера, требуется CSRF.

**— Как проверить, что всё работает?**
`php artisan test` (42 теста). Вручную: войти как pilot, проехать трассу, увидеть результат в гараже и лидерборде, затем войти как admin и увидеть события в журнале.

---

## 21. Шпаргалка по Laravel-терминам

| Термин | Простыми словами |
|---|---|
| Route | Правило «URL + метод → метод контроллера» |
| Controller | Класс, обрабатывающий запрос |
| Middleware | Фильтр до контроллера (auth, guest, role, csrf) |
| Eloquent / Model | Класс-обёртка над таблицей; строка = объект |
| Migration | Структура таблицы в виде кода, с откатом `down()` |
| Seeder | Заполнение БД начальными данными |
| Blade | Шаблонизатор: `{{ }}`, `@if`, `@foreach`, `@csrf`, `@extends` |
| Validation | Правила проверки входных данных (`required`, `unique`, `confirmed`) |
| Guard / Provider | Как хранить вход (сессия) / откуда брать пользователей (Eloquent User) |
| Session | Серверное хранилище данных пользователя между запросами |
| Flash | Сообщение в сессии на один следующий запрос |
| CSRF-токен | Секрет в форме, доказывающий, что форма с нашего сайта |
| Route Model Binding | `{track}` в URL превращается в объект `Track` (или 404) |
| Mass assignment / `$fillable` | Какие поля можно заполнить массивом |
| Cast | Автоматическое преобразование поля (json → array, hashed, boolean) |
| Eager loading (`with`) | Загрузка связей заранее одним запросом (против N+1) |
| Transaction | Группа запросов «всё или ничего» |
| `abort(403)` | Прервать запрос с HTTP-ошибкой |
| Vite | Сборщик CSS/JS в `public/build` |
| Artisan | Консоль Laravel: `migrate`, `serve`, `test`, `route:list`, `tinker` |
