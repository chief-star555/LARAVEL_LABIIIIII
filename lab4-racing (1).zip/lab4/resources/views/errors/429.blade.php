{{--
    Своя страница ошибки 429: слишком много попыток входа/регистрации (лимитер 'auth' в AppServiceProvider).
--}}
@extends('layouts.site')
@section('title','Слишком много попыток — Пит-стоп')
@section('content')
<section class="error-page error-403"><div class="error-art"><span class="error-code">429</span><div class="error-road"><i></i><i></i><i></i></div><div class="error-barrier"><span></span><span></span><span></span></div></div><p class="eyebrow">PIT STOP · 429</p><h1>Слишком много<br>попыток.</h1><p>Подожди минуту и попробуй войти ещё раз. Это защита от подбора пароля.</p><div class="error-actions"><a class="button" href="{{route('home', [], false)}}">Вернуться на трассу <span>→</span></a></div></section>
@endsection
