{{--
    Своя страница ошибки 419: истёк CSRF-токен (форма открыта слишком давно). Laravel сам выбирает шаблон errors/КОД.blade.php.
--}}
@extends('layouts.site')
@section('title','Сессия заезда истекла — Пит-стоп')
@section('content')
<section class="error-page error-419"><div class="error-art"><span class="error-code">419</span><div class="error-clock">↻</div><div class="error-car">P</div></div><p class="eyebrow">RACE SESSION · 419</p><h1>Пауза затянулась.</h1><p>Сессия заезда истекла. Обнови страницу, чтобы снова выйти на старт.</p><div class="error-actions"><a class="button" href="{{url()->previous()}}">Обновить страницу <span>↻</span></a><a class="button button-muted" href="{{route('home', [], false)}}">На главную</a></div></section>
@endsection
