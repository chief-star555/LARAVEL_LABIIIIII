{{--
    Своя страница ошибки 403: нет прав (RoleMiddleware для не-админа). Laravel сам выбирает шаблон errors/КОД.blade.php.
--}}
@extends('layouts.site')
@section('title','Пит-лейн закрыт — Пит-стоп')
@section('content')
<section class="error-page error-403"><div class="error-art"><span class="error-code">403</span><div class="error-road"><i></i><i></i><i></i></div><div class="error-barrier"><span></span><span></span><span></span></div></div><p class="eyebrow">PIT LANE · 403</p><h1>Пит-лейн<br>пока закрыт.</h1><p>У этого аккаунта нет доступа к запрошенному разделу. Проверь, что ты вошёл под нужной ролью.</p><div class="error-actions"><a class="button" href="{{route('home', [], false)}}">Вернуться на трассу <span>→</span></a>@guest<a class="button button-muted" href="{{route('login', [], false)}}">Войти</a>@endguest</div></section>
@endsection
