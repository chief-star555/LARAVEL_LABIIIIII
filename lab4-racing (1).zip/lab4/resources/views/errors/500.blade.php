{{--
    Своя страница ошибки 500: внутренняя ошибка сервера. Laravel сам выбирает шаблон errors/КОД.blade.php.
--}}
@extends('layouts.site')
@section('title','Пит-стоп — Пит-стоп')
@section('content')
<section class="error-page error-500"><div class="error-art"><span class="error-code">500</span><div class="error-tools">✦</div><div class="error-car">P</div></div><p class="eyebrow">MECHANICS AT WORK · 500</p><h1>Машина на<br>пит-стопе.</h1><p>На трассе возникла техническая ошибка. Попробуй ещё раз чуть позже.</p><div class="error-actions"><a class="button" href="{{route('home', [], false)}}">Вернуться на трассу <span>→</span></a><a class="button button-muted" href="{{route('leaderboard', [], false)}}">Лидерборд</a></div></section>
@endsection
