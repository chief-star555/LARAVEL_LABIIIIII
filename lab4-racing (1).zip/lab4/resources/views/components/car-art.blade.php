{{--
    SVG-рисунок машины (компонент <x-car-art :car="$car"/>): цвета и форма кузова
    берутся из полей таблицы cars (color_hex, accent_hex, body_style).
--}}
@props(['car', 'size' => 'normal'])
<div class="car-artwork car-artwork-{{$size}}" role="img" aria-label="{{$car->color_name}} {{$car->name}}" style="--car-paint:{{$car->color_hex}};--car-accent:{{$car->accent_hex}}">
<svg viewBox="0 0 180 110" aria-hidden="true" focusable="false">
 <defs>
  <linearGradient id="paint-{{$car->slug}}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="var(--car-paint)"/><stop offset=".48" stop-color="var(--car-accent)"/><stop offset=".72" stop-color="var(--car-paint)"/><stop offset="1" stop-color="#11191d"/></linearGradient>
  <linearGradient id="glass-{{$car->slug}}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#9fc2cb"/><stop offset=".28" stop-color="#294550"/><stop offset="1" stop-color="#111b22"/></linearGradient>
  <linearGradient id="metal-{{$car->slug}}" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#ffffff" stop-opacity=".68"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>
 </defs>
 <ellipse cx="90" cy="58" rx="43" ry="48" fill="#071012" opacity=".62"/>
 <g fill="#101519" stroke="#657176" stroke-width="1.1">
  <rect x="49" y="26" width="13" height="22" rx="5"/><rect x="118" y="26" width="13" height="22" rx="5"/>
  <rect x="49" y="65" width="13" height="22" rx="5"/><rect x="118" y="65" width="13" height="22" rx="5"/>
 </g>
 <g fill="#849096" opacity=".45"><path d="M52 30h3v14h-3zm73 0h3v14h-3zm-73 39h3v14h-3zm73 0h3v14h-3z"/></g>
 @if($car->body_style==='supercar')
  <path d="M90 6 105 13 118 25 124 45 126 70 116 88 101 101 90 105 79 101 64 88 54 70 56 45 62 25 75 13Z" fill="url(#paint-{{$car->slug}})" stroke="var(--car-accent)" stroke-width="1.8"/>
  <path d="m66 24 24-6 24 6-5 7H71z" fill="url(#metal-{{$car->slug}})" opacity=".48"/>
 @elseif($car->body_style==='hypercar')
  <path d="M90 5c17 0 27 8 31 23l5 43q-3 20-18 29l-18 5-18-5Q57 91 54 71l5-43C63 13 73 5 90 5Z" fill="url(#paint-{{$car->slug}})" stroke="var(--car-accent)" stroke-width="1.8"/>
  <path d="M64 27q26-12 52 0l-5 7H69z" fill="url(#metal-{{$car->slug}})" opacity=".48"/>
 @else
  <path d="M90 7c15 0 26 8 29 23l3 45q-3 20-18 27-6 3-14 3t-14-3Q61 95 58 75l3-45C64 15 75 7 90 7Z" fill="url(#paint-{{$car->slug}})" stroke="var(--car-accent)" stroke-width="1.8"/>
  <path d="M65 29q25-11 50 0l-3 6H68z" fill="url(#metal-{{$car->slug}})" opacity=".5"/>
 @endif
 <path d="M69 36q21-8 42 0l5 15q-26 7-52 0z" fill="url(#glass-{{$car->slug}})" stroke="#b8d4d7" stroke-opacity=".55" stroke-width="1.2"/>
 <path d="M69 59q21 7 42 0l-4 15q-17 7-34 0z" fill="url(#glass-{{$car->slug}})" stroke="#b8d4d7" stroke-opacity=".5" stroke-width="1.2"/>
 <path d="M90 36v38" stroke="#b5cbd0" stroke-opacity=".35" stroke-width="1"/>
 <path d="M74 39q8-3 13-3v12l-11 1zm32 0q-8-3-13-3v12l11 1z" fill="#d6e5e4" opacity=".13"/>
 @if($car->body_style==='hypercar')<path d="M88 18h4v13h-4zm0 52h4v19h-4z" fill="var(--car-accent)" opacity=".82"/>@elseif($car->body_style==='supercar')<path d="M67 54 81 57 76 61 66 59zm46 0-14 3 5 4 10-2z" fill="var(--car-accent)" opacity=".88"/>@else<path d="M70 53h40v2H70zm4 24h32" stroke="var(--car-accent)" stroke-width="1.4" opacity=".65"/>@endif
 <path d="M79 9h22" stroke="#fff6cf" stroke-width="3.5" stroke-linecap="round"/><path d="M78 100h24" stroke="#ff6455" stroke-width="3" stroke-linecap="round"/>
 <path d="M79 12h22" stroke="#fff" stroke-opacity=".7" stroke-width="1"/>
 <circle cx="90" cy="54" r="3" fill="var(--car-accent)" stroke="#fff" stroke-opacity=".7" stroke-width=".7"/>
</svg>
</div>
