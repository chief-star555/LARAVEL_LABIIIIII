{{--
    Подвал сайта (компонент <x-site-footer/>).
--}}
<footer class="site-footer"><div class="footer-inner"><span>Пит-стоп · аркадные гонки сверху</span><span>Учебный проект Laravel + Canvas</span></div></footer>
