{{--
    АДМИН-ПАНЕЛЬ (resources/views/admin.blade.php)
    Контроллер: AdminController@index. Доступ: middleware auth + role:admin (routes/web.php).
    Блоки: 1) сводная статистика; 2) таблица игроков с формой смены роли
    (PATCH /admin/users/{id}/role, @csrf + @method('PATCH')); 3) журнал последних событий
    из таблицы user_activity_logs ($eventLabels переводит коды событий на русский).
    {{ }} — вывод с экранированием (защита от XSS): логин "<script>" покажется как текст.
--}}
@extends('layouts.site')
@section('title','Панель управления — Пит-стоп')
@section('content')
<section class="admin-hero"><div><p class="eyebrow">RACE CONTROL · ADMIN</p><h1>Панель управления</h1><p>Игроки, результаты и свежая активность трассы — в одном месте.</p></div><div class="admin-live"><span></span> СИСТЕМА АКТИВНА</div></section>
<section class="admin-stats" aria-label="Сводка проекта">
    <article class="admin-stat"><span class="admin-stat-icon">◉</span><small>АККАУНТЫ</small><strong>{{$stats['users']}}</strong><span>всего игроков</span></article>
    <article class="admin-stat"><span class="admin-stat-icon admin-icon-races">↗</span><small>ЗАЕЗДЫ</small><strong>{{$stats['races']}}</strong><span>сохранённых финишей</span></article>
    <article class="admin-stat"><span class="admin-stat-icon admin-icon-tracks">⌁</span><small>ТРАССЫ</small><strong>{{$stats['tracks']}}</strong><span>доступно в игре</span></article>
    <article class="admin-stat admin-stat-highlight"><span class="admin-stat-icon admin-icon-records">✦</span><small>ЛИЧНЫЕ РЕКОРДЫ</small><strong>{{$stats['records']}}</strong><span>лучшие результаты</span></article>
</section>
<section class="admin-block admin-users-block"><div class="admin-section-head"><div><p class="eyebrow">АККАУНТЫ</p><h2>Игроки и роли</h2></div><span class="admin-count">{{count($users)}} {{$usersLabel}}</span></div>
<div class="table-wrap"><table class="admin-users-table"><thead><tr><th>Пилот</th><th>Роль</th><th>Назначить роль</th></tr></thead><tbody>
@foreach($users as $user)<tr><td><div class="admin-user-cell"><span class="admin-avatar">{{strtoupper(substr($user->login,0,1))}}</span><div><strong>{{$user->login}}</strong><small>ID #{{str_pad((string)$user->id,4,'0',STR_PAD_LEFT)}}</small></div></div></td><td><span class="role-chip role-{{$user->role->name}}"><i></i>{{$roleLabels[$user->role->name]??$user->role->name}}</span></td><td><form class="role-form-inline" method="POST" action="{{route('admin.users.update-role',$user, false)}}">@csrf @method('PATCH')<select name="role_id" aria-label="Роль {{$user->login}}">@foreach($roles as $role)<option value="{{$role->id}}" @selected($user->role_id===$role->id)>{{$roleLabels[$role->name]??$role->name}}</option>@endforeach</select><button class="button button-small" type="submit">Сохранить</button></form></td></tr>@endforeach
</tbody></table></div></section>
<section class="admin-block admin-activity-block"><div class="admin-section-head"><div><p class="eyebrow">LIVE FEED</p><h2>Последние события</h2></div><span class="activity-live"><i></i> ОБНОВЛЯЕТСЯ ПРИ ДЕЙСТВИЯХ</span></div>
@php($eventLabels=['auth.login'=>'Вход в аккаунт','auth.logout'=>'Выход из аккаунта','auth.registered'=>'Регистрация','auth.login_failed'=>'Неудачный вход','game.enter'=>'Открыта трасса','race.started'=>'Старт заезда','race.finished'=>'Заезд завершён','personal_record.updated'=>'Новый личный рекорд','garage.car_selected'=>'Выбрана машина','admin.role_changed'=>'Смена роли'])
<div class="activity-list">@forelse($activityLogs as $log)<article class="activity-row"><span class="activity-marker event-{{str_replace('.','-',$log->event)}}">{{str_starts_with($log->event,'race.')?'🏁':(str_starts_with($log->event,'personal_')?'✦':(str_starts_with($log->event,'auth.')?'◉':(str_starts_with($log->event,'admin.')?'⚙':'⌁')))}}</span><div class="activity-main"><strong>{{$eventLabels[$log->event]??$log->event}}</strong><span>{{$log->user?->login??data_get($log->metadata,'login','Гость')}}@if($log->track) · {{$log->track->name}}@endif @if(data_get($log->metadata,'car_name')) · {{data_get($log->metadata,'car_name')}}@endif</span></div><div class="activity-detail">@if(data_get($log->metadata,'ending_type'))<span class="ending-pill ending-{{data_get($log->metadata,'ending_type')}}">{{['gold'=>'Золотой финиш','normal'=>'Обычный финиш','crash'=>'Авария','timeout'=>'Тайм-аут','secret'=>'Секретная'][data_get($log->metadata,'ending_type')]??data_get($log->metadata,'ending_type')}}</span>@endif @if(data_get($log->metadata,'finish_time'))<span>{{number_format((float)data_get($log->metadata,'finish_time'),2)}} сек</span>@endif @if(data_get($log->metadata,'score'))<span>· {{number_format((int)data_get($log->metadata,'score'),0,',',' ')}} оч.</span>@endif @if(data_get($log->metadata,'target_login'))<span>{{data_get($log->metadata,'target_login')}} → {{$roleLabels[data_get($log->metadata,'new_role')]??data_get($log->metadata,'new_role')}}</span>@endif</div><time datetime="{{$log->created_at?->toIso8601String()}}">{{$log->created_at?->format('d.m H:i')}}</time></article>@empty<div class="activity-empty"><span>◌</span><strong>Пока тихо на трассе</strong><small>События появятся после входа игроков и первых заездов.</small></div>@endforelse</div>
</section>
@endsection
