{{--
    ЛИДЕРБОРД (LeaderboardController@index). Доступен всем, включая гостей.
    Фильтры — GET-форма (track_id, car_id попадают в адрес, ссылкой можно поделиться).
    JS внизу отправляет форму сразу при выборе в списке (без кнопки).
    Показываются только личные рекорды: is_personal_best = true, сортировка время → очки → id.
--}}
@extends('layouts.site')
@section('title','Лидерборд — Пит-стоп')
@section('content')
<section class="page-heading leaderboard-heading"><p class="eyebrow">ТАБЛИЦА РЕКОРДОВ</p><h1>Кто быстрее?</h1><p>Лучшее время отдельно для каждой машины и трассы. Фильтруй заезды как удобно.</p></section>
<section class="leaderboard-panel"><form class="filter-form" id="leaderboard-filter" method="GET" action="{{route('leaderboard', [], false)}}"><label for="track-filter">Трасса</label><select id="track-filter" name="track_id"><option value="">Все трассы</option>@foreach($tracks as $track)<option value="{{$track->id}}" @selected($selectedTrackId===$track->id)>{{$track->name}}</option>@endforeach</select><label for="car-filter">Машина</label><select id="car-filter" name="car_id"><option value="">Все машины</option>@foreach($cars as $car)<option value="{{$car->id}}" @selected($selectedCarId===$car->id)>{{$car->name}} · {{$car->color_name}}</option>@endforeach</select><noscript><button class="button button-small">Показать</button></noscript></form>
@if($results->isNotEmpty())<div class="leader-podium" aria-label="Тройка лидеров">@foreach($results->take(3) as $result)<article class="podium-card podium-{{$loop->iteration}}"><div class="podium-topline"><span>{{['🥇','🥈','🥉'][$loop->index]}}</span><small>RANK {{str_pad((string)$loop->iteration,2,'0',STR_PAD_LEFT)}}</small></div><div class="podium-player"><span class="podium-avatar">{{strtoupper(substr($result->user->login,0,1))}}</span><strong>{{$result->user->login}}</strong></div><div class="podium-time">{{number_format((float)$result->finish_time,2)}}<small>сек</small></div><div class="podium-bottom"><span>{{$result->track->name}} · {{$result->car?->name??'—'}}</span><b>{{number_format($result->score,0,',',' ')}} очков</b></div></article>@endforeach</div>@endif
<div class="table-wrap"><table class="leaderboard-table"><thead><tr><th>Место</th><th>Игрок</th><th>Трасса</th><th>Машина</th><th>Лучшее время</th><th>Очки</th><th>Концовка</th></tr></thead><tbody>
@forelse($results as $result)@php($endingLabels=['gold'=>'Золотой финиш','normal'=>'Обычный финиш','crash'=>'Авария','timeout'=>'Тайм-аут','secret'=>'Секретная'])
<tr><td><span class="rank rank-{{$loop->iteration}}">{{str_pad((string)$loop->iteration,2,'0',STR_PAD_LEFT)}}</span></td><td class="leader-user">{{$result->user->login}}</td><td>{{$result->track->name}}</td><td>{{$result->car?->name??'—'}}</td><td class="leader-time">{{number_format((float)$result->finish_time,2)}}<small>сек</small></td><td>{{number_format($result->score,0,',',' ')}}</td><td><span class="ending-pill ending-{{$result->ending_type}}">{{$endingLabels[$result->ending_type]??$result->ending_type}}</span></td></tr>
@empty<tr><td colspan="7" class="empty-leaderboard"><span>🏁</span><strong>Рекордов пока нет</strong><small>Стань первым, кто пройдёт трассу!</small></td></tr>@endforelse
</tbody></table></div><div class="leaderboard-foot"><span>Показано до 10 рекордов выбранных фильтров</span><a href="{{route('home', [], false)}}">К трассам →</a></div></section>
@endsection
@push('scripts')
<script>
(() => {
 const form=document.getElementById('leaderboard-filter');if(!form)return;
 // Skip empty filters for clean URLs; hidden fields (e.g. the preview session token) are always kept.
 form.querySelectorAll('select').forEach(select=>select.addEventListener('change',()=>{form.querySelectorAll('select').forEach(s=>{s.disabled=s.value==='';});form.classList.add('is-loading');form.submit();}));
 window.addEventListener('pageshow',()=>{form.querySelectorAll('select').forEach(s=>{s.disabled=false;});form.classList.remove('is-loading');});
})();
</script>
@endpush
