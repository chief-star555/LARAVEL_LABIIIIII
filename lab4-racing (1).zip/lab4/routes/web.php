<?php

/*
|--------------------------------------------------------------------------
| МАРШРУТЫ САЙТА (routes/web.php)
|--------------------------------------------------------------------------
| Здесь описано, какой URL обрабатывает какой метод контроллера и какие
| middleware (промежуточные проверки) стоят перед ним.
|
| Все маршруты этого файла автоматически входят в группу middleware "web":
|   - StartSession      — запускает сессию (в ней хранится, кто вошёл);
|   - PreviewCsrf       — проверка CSRF-токена для POST/PATCH (наследник
|                         стандартной защиты Laravel, см. app/Http/Middleware);
|   - ShareErrorsFromSession — передаёт ошибки валидации в шаблоны ($errors);
|   - EncryptCookies и др.
|
| Четыре уровня доступа:
|   1) публичные     — видят все (главная, лидерборд);
|   2) только гости  — middleware 'guest': вошедшего пользователя страница
|                      входа/регистрации просто перекинет на главную;
|   3) только вошедшие — middleware 'auth': гостя перекинет на /login;
|   4) только админ  — 'auth' + наш 'role:admin' (RoleMiddleware), иначе 403.
|
| ->name('...') — имя маршрута. В шаблонах пишем route('leaderboard'),
| а не "/leaderboard", поэтому URL можно поменять в одном месте.
*/

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\GameController;
use App\Http\Controllers\GarageController;
use App\Http\Controllers\LeaderboardController;
use Illuminate\Support\Facades\Route;

// ---------- 1. Публичные страницы (вход не нужен) ----------
Route::get('/', [GameController::class, 'tracks'])->name('home');                       // главная: витрина машин и трасс
Route::get('/leaderboard', [LeaderboardController::class, 'index'])->name('leaderboard'); // таблица рекордов + фильтры

// ---------- 2. Только для гостей ----------
// Вошедшему пользователю форма входа не нужна — middleware 'guest' вернёт его на главную.
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('login');            // показать форму входа
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:auth')->name('login.store');         // обработать форму входа (не больше 10 попыток/мин — AppServiceProvider)
    Route::get('/register', [AuthController::class, 'registerForm'])->name('register');   // показать форму регистрации
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:auth')->name('register.store'); // создать аккаунт (тот же лимит)
});

// Выход — только POST (а не GET-ссылка): так чужой сайт не сможет "разлогинить"
// пользователя картинкой/ссылкой, а форма выхода защищена CSRF-токеном.
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

// ---------- 3. Только для вошедших ----------
// Игра и гараж привязаны к конкретному игроку (результаты, выбранная машина),
// поэтому без входа их открывать бессмысленно.
Route::middleware('auth')->group(function () {
    Route::get('/garage', [GarageController::class, 'show'])->name('garage');                  // личный кабинет игрока
    Route::post('/garage/car', [GarageController::class, 'selectCar'])->name('garage.car.select'); // выбрать активную машину

    // {track} — Route Model Binding: Laravel сам найдёт Track по id из URL
    // и передаст объект в контроллер. Нет такой трассы — автоматически 404.
    Route::get('/game/{track}', [GameController::class, 'show'])->name('game.show');            // страница с Canvas-игрой
    Route::post('/game/{track}/start', [GameController::class, 'start'])->name('game.start');   // JS: "заезд начался" → выдаём race_token
    Route::post('/game/{track}/finish', [GameController::class, 'finish'])->name('game.finish'); // JS: "заезд закончен" → проверяем и сохраняем
});

// ---------- 4. Админ-панель ----------
// prefix('admin') — все URL начинаются с /admin; name('admin.') — имена admin.index и т.д.
// 'role:admin' — наш RoleMiddleware: пускает только пользователя с ролью admin, остальным 403.
Route::prefix('admin')->name('admin.')->middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('index');                                      // статистика, игроки, журнал
    Route::patch('/users/{user}/role', [AdminController::class, 'updateUserRole'])->name('users.update-role'); // сменить роль игрока (PATCH = частичное изменение)
});
