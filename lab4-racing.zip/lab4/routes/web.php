<?php
use App\Http\Controllers\AdminController;use App\Http\Controllers\AuthController;use App\Http\Controllers\GameController;use App\Http\Controllers\GarageController;use App\Http\Controllers\LeaderboardController;use Illuminate\Support\Facades\Route;
Route::get('/',[GameController::class,'tracks'])->name('home');
Route::get('/leaderboard',[LeaderboardController::class,'index'])->name('leaderboard');
Route::middleware('guest')->group(function(){Route::get('/login',[AuthController::class,'loginForm'])->name('login');Route::post('/login',[AuthController::class,'login'])->name('login.store');Route::get('/register',[AuthController::class,'registerForm'])->name('register');Route::post('/register',[AuthController::class,'register'])->name('register.store');});
Route::post('/logout',[AuthController::class,'logout'])->middleware('auth')->name('logout');
Route::middleware('auth')->group(function(){Route::get('/garage',[GarageController::class,'show'])->name('garage');Route::post('/garage/car',[GarageController::class,'selectCar'])->name('garage.car.select');Route::get('/game/{track}',[GameController::class,'show'])->name('game.show');Route::post('/game/{track}/start',[GameController::class,'start'])->name('game.start');Route::post('/game/{track}/finish',[GameController::class,'finish'])->name('game.finish');});
Route::prefix('admin')->name('admin.')->middleware(['auth','role:admin'])->group(function(){Route::get('/',[AdminController::class,'index'])->name('index');Route::patch('/users/{user}/role',[AdminController::class,'updateUserRole'])->name('users.update-role');});
