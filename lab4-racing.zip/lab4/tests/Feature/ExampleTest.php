<?php
namespace Tests\Feature;
use App\Models\Car;use App\Models\RaceResult;use App\Models\Role;use App\Models\Track;use App\Models\User;use App\Models\UserActivityLog;use Illuminate\Foundation\Testing\RefreshDatabase;use Tests\TestCase;
class ExampleTest extends TestCase {
 use RefreshDatabase;
 protected function setUp():void {parent::setUp();$this->withoutVite();$this->seed();}
 public function test_not_found_uses_the_branded_track_error_page():void {
  $this->get('/no-such-turn')->assertNotFound()->assertSee('Кажется, ты')->assertSee('К выбору трассы');
 }
 public function test_track_selection_page_shows_the_seeded_maps():void {
  $this->get('/')->assertOk()->assertSee('Кольцо')->assertSee('Змейка')->assertSee('Лабиринт')->assertSee('Три характера')->assertSee('track-route-surface')->assertSee('КРУГА ДО ФИНИША')->assertSee('2 круга ·')->assertSee('Чтобы выехать на трассу')->assertSee('Mercedes-AMG GT')->assertSee('Lamborghini Huracán')->assertSee('Bugatti Chiron')->assertSee('aria-current="page"',false)->assertSee('href="/login"',false)->assertSee('href="/register"',false)->assertSee('href="/game/1"',false)->assertSee('href="/build/assets/app-',false)->assertDontSee('127.0.0.1:8000/',false);
  $this->assertSame(3,Track::count());$this->assertSame(3,Car::count());
 }
 public function test_login_and_registration_navigation_stays_on_the_current_origin():void {
  $this->get('/login')->assertOk()->assertSee('action="/login"',false)->assertSee('href="/register"',false)->assertDontSee('127.0.0.1:8000',false);
  $this->get('/register')->assertOk()->assertSee('action="/register"',false)->assertSee('href="/login"',false)->assertDontSee('127.0.0.1:8000',false);
 }
 public function test_iframe_session_cookie_is_secure_and_partitioned_for_preview():void {
  config(['session.same_site'=>'none','session.secure'=>true,'session.partitioned'=>true]);$response=$this->get('/login');$cookie=collect($response->headers->getCookies())->first(fn($cookie)=>$cookie->getName()===config('session.cookie'));
  $this->assertNotNull($cookie);$this->assertTrue($cookie->isSecure());$this->assertSame('none',$cookie->getSameSite());$this->assertTrue($cookie->isPartitioned());
 }
 public function test_login_returns_to_the_relative_intended_game_path():void {
  $track=Track::where('slug','ring')->firstOrFail();$this->get(route('game.show',$track))->assertRedirect('/login');
  $this->post('/login',['login'=>'pilot','password'=>'racing12345'])->assertRedirect('/game/'.$track->id)->assertSessionHas('success','Вход выполнен. Трасса готова к заезду.');$this->assertAuthenticated();
 }
 public function test_every_track_is_a_unique_closed_two_lap_circuit():void {
  $shapes=[];foreach(Track::all() as $track){$shapes[]=implode('', $track->grid);$roadCount=collect($track->grid)->sum(fn(string $row)=>strlen($row)-substr_count($row,'#'));$this->assertSame(2,$track->lapsRequired());$this->assertCount($roadCount,$track->circuitCells(),$track->slug.' is one complete loop');$this->assertMatchesRegularExpression('/^M\\d+ \\d+(?: L\\d+ \\d+)+ Z$/',$track->previewPath(),$track->slug.' preview closes the loop');}
  $this->assertCount(3,array_unique($shapes),'All three circuits have different shapes.');
 }
 public function test_tracks_and_gameplay_have_no_oil_or_red_barrier_hazards():void {
  foreach(Track::all() as $track){$cells=implode('', $track->grid);$this->assertStringNotContainsString('O',$cells);$this->assertStringNotContainsString('X',$cells);}
  $this->get('/')->assertOk()->assertDontSee('масло')->assertDontSee('legend-oil');
  $player=User::where('login','pilot')->firstOrFail();$track=Track::where('slug','ring')->firstOrFail();
  $this->actingAs($player)->get(route('game.show',$track))->assertOk()->assertDontSee('масла')->assertDontSee('препятствий');
 }
 public function test_garage_mini_maps_use_the_matching_track_routes():void {
  $player=User::where('login','pilot')->firstOrFail();$response=$this->actingAs($player)->get(route('garage'))->assertOk();
  foreach(Track::orderBy('id')->get() as $track)$response->assertSee($track->previewPath(),false);
 }
 public function test_reverse_proxy_keeps_generated_navigation_on_the_preview_origin():void {
  $this->withHeaders(['X-Forwarded-Host'=>'pitstop-preview.example','X-Forwarded-Proto'=>'https'])->get('/')->assertOk()->assertSee('href="/leaderboard"',false)->assertDontSee('pitstop-preview.example/leaderboard',false)->assertSee('href="/build/assets/app-',false);
 }
 public function test_player_garage_shows_personal_best_and_recent_results():void {
  $player=User::where('login','pilot')->firstOrFail();$track=Track::where('slug','ring')->firstOrFail();$car=Car::where('slug','mercedes-red')->firstOrFail();
  RaceResult::create(['user_id'=>$player->id,'track_id'=>$track->id,'car_id'=>$car->id,'finish_time'=>42.35,'score'=>9200,'ending_type'=>'gold','bonus_count'=>1,'remaining_hp'=>88,'is_personal_best'=>true,'completed_at'=>now()]);
  $admin=User::where('login','admin')->firstOrFail();
  RaceResult::create(['user_id'=>$admin->id,'track_id'=>$track->id,'car_id'=>$car->id,'finish_time'=>37.10,'score'=>9500,'ending_type'=>'gold','bonus_count'=>1,'remaining_hp'=>92,'is_personal_best'=>true,'completed_at'=>now()->subDay()]);
  $this->actingAs($player)->get(route('garage'))->assertOk()->assertSee('class="garage-track-map"',false)->assertSee($track->previewPath(),false)->assertSee('pilot')->assertSee('Рекорды выбранной машины')->assertSee('Mercedes-AMG GT')->assertSee('Lamborghini Huracán')->assertSee('Bugatti Chiron')->assertSee('Красный кузов')->assertSee('Жёлтый кузов')->assertSee('Синий кузов')->assertSee('История заездов')->assertSee('Коллекция достижений')->assertSee('Ритм заездов')->assertSee('заезд за неделю')->assertSee('aria-label="За последние семь дней: 1 заезд"',false)->assertSee('МЕСТО #2')->assertSee('Цель быстрее на 39.65 сек')->assertSee('Первый финиш')->assertSee('Золотая каска')->assertSee('Чистая линия')->assertSee('42.35')->assertSee('Кольцо');
  $this->get(route('game.show',$track))->assertOk()->assertSee('Ваш рекорд')->assertSee('id="lap-value">0</span>',false)->assertSee('String(Math.min(lapsCompleted,lapsRequired))',false)->assertSee('laps_completed:lapsCompleted',false)->assertSee('Mercedes-AMG GT')->assertSee('Финишная черта после второго круга.')->assertSee('lap-value')->assertSee('42.35 сек');
 }
 public function test_registration_is_logged_and_gets_the_default_red_mercedes():void {
  $car=Car::where('slug','mercedes-red')->firstOrFail();
  $this->post(route('register.store'),['login'=>'newpilot','password'=>'racing12345','password_confirmation'=>'racing12345'])->assertRedirect('/');
  $user=User::where('login','newpilot')->firstOrFail();$this->assertAuthenticatedAs($user);$this->assertSame((int)$car->id,(int)$user->current_car_id);
  $this->get('/')->assertOk()->assertSee('Выйти')->assertSee('За руль')->assertSee('Аккаунт создан. Добро пожаловать на трассу!')->assertDontSee('Войти и играть');
  $this->assertDatabaseHas('user_activity_logs',['user_id'=>$user->id,'event'=>'auth.registered']);
  $registrationLog=UserActivityLog::where('user_id',$user->id)->where('event','auth.registered')->firstOrFail();$this->assertSame($car->name,$registrationLog->metadata['car_name']);
 }
 public function test_player_can_select_any_of_the_three_cars_in_garage():void {
  $player=User::where('login','pilot')->firstOrFail();$car=Car::where('slug','lamborghini-yellow')->firstOrFail();
  $this->actingAs($player)->post(route('garage.car.select'),['car_id'=>$car->id])->assertRedirect('/garage');
  $this->assertDatabaseHas('users',['id'=>$player->id,'current_car_id'=>$car->id]);
  $this->assertDatabaseHas('user_activity_logs',['user_id'=>$player->id,'event'=>'garage.car_selected']);
  $this->get(route('garage'))->assertOk()->assertSee('Lamborghini Huracán')->assertSee('PERSONAL BEST · Lamborghini Huracán')->assertSee('aria-pressed="true"',false);
 }
 public function test_race_record_and_activity_log_keep_the_car_from_the_race_start():void {
  $player=User::where('login','pilot')->firstOrFail();$track=Track::where('slug','ring')->firstOrFail();$car=Car::where('slug','lamborghini-yellow')->firstOrFail();$mercedes=Car::where('slug','mercedes-red')->firstOrFail();$this->actingAs($player);
  RaceResult::create(['user_id'=>$player->id,'track_id'=>$track->id,'car_id'=>$mercedes->id,'finish_time'=>40.0,'score'=>8000,'ending_type'=>'gold','bonus_count'=>0,'remaining_hp'=>90,'is_personal_best'=>true,'completed_at'=>now()->subMinute()]);
  $this->post(route('garage.car.select'),['car_id'=>$car->id])->assertRedirect('/garage');
  $token=$this->postJson(route('game.start',$track))->assertOk()->assertJson(['car_id'=>$car->id])->json('race_token');
  $otherCar=Car::where('slug','bugatti-blue')->firstOrFail();$this->post(route('garage.car.select'),['car_id'=>$otherCar->id])->assertRedirect('/garage');
  $this->postJson(route('game.finish',$track),['race_token'=>$token,'finish_time'=>0.1,'score'=>9100,'ending_type'=>'gold','bonus_count'=>0,'remaining_hp'=>96,'laps_completed'=>2])->assertOk()->assertJson(['car_id'=>$car->id,'car_name'=>$car->name,'is_personal_best'=>true]);
  $this->assertDatabaseHas('race_results',['user_id'=>$player->id,'track_id'=>$track->id,'car_id'=>$mercedes->id,'is_personal_best'=>true]);
  $this->assertDatabaseHas('race_results',['user_id'=>$player->id,'track_id'=>$track->id,'car_id'=>$car->id,'is_personal_best'=>true]);
  $this->assertSame(2,RaceResult::where('user_id',$player->id)->where('track_id',$track->id)->where('is_personal_best',true)->count());
  $log=UserActivityLog::where('user_id',$player->id)->where('event','personal_record.updated')->firstOrFail();
  $this->assertSame($car->id,$log->metadata['car_id']);$this->assertSame($car->name,$log->metadata['car_name']);$this->assertSame($track->id,$log->track_id);
  $this->get(route('leaderboard',['track_id'=>$track->id,'car_id'=>$car->id]))->assertOk()->assertSee($car->name)->assertSee('pilot')->assertDontSee('<td>'.$mercedes->name.'</td>',false);
 }
 public function test_empty_garage_shows_zero_weekly_activity_and_locked_goals():void {
  $player=User::where('login','pilot')->firstOrFail();
  $this->actingAs($player)->get(route('garage'))->assertOk()->assertSee('Ритм заездов')->assertSee('За последние семь дней: 0 заездов',false)->assertSee('0 / 6 открыто')->assertSee('Первый финиш');
 }
 public function test_secret_finish_unlocks_the_bonus_achievement():void {
  $player=User::where('login','pilot')->firstOrFail();$track=Track::where('slug','snake')->firstOrFail();$car=Car::where('slug','mercedes-red')->firstOrFail();
  RaceResult::create(['user_id'=>$player->id,'track_id'=>$track->id,'car_id'=>$car->id,'finish_time'=>61.2,'score'=>12000,'ending_type'=>'secret','bonus_count'=>2,'remaining_hp'=>68,'is_personal_best'=>true,'completed_at'=>now()]);
  $this->actingAs($player)->get(route('garage'))->assertOk()->assertSee('Охотник за бонусами')->assertSee('Секретная концовка');
 }
 public function test_game_requires_login_and_admin_role_is_preserved():void {
  $track=Track::where('slug','ring')->firstOrFail();$this->get(route('game.show',$track))->assertRedirect('/login');$this->get(route('garage'))->assertRedirect('/login');
  $player=User::where('login','pilot')->firstOrFail();$this->actingAs($player)->get('/admin')->assertForbidden();
  $admin=User::where('login','admin')->firstOrFail();$this->actingAs($admin)->get('/admin')->assertOk()->assertSee('Панель управления')->assertSee('Игроки и роли')->assertSee('Последние события');
 }
 public function test_admin_feed_renders_race_finishes_from_the_activity_log():void {
  $admin=User::where('login','admin')->firstOrFail();$player=User::where('login','pilot')->firstOrFail();$track=Track::where('slug','ring')->firstOrFail();$car=Car::where('slug','mercedes-red')->firstOrFail();
  UserActivityLog::create(['user_id'=>$player->id,'track_id'=>$track->id,'event'=>'race.finished','metadata'=>['ending_type'=>'gold','finish_time'=>37.42,'score'=>8500,'car_id'=>$car->id,'car_name'=>$car->name],'created_at'=>now()]);
  $this->actingAs($admin)->get('/admin')->assertOk()->assertSee('Заезд завершён')->assertSee('Золотой финиш')->assertSee('37.42')->assertSee('Mercedes-AMG GT');
 }
 public function test_started_race_is_saved_logged_and_appears_in_leaderboard():void {
  $track=Track::where('slug','ring')->firstOrFail();$player=User::where('login','pilot')->firstOrFail();$car=Car::where('slug','mercedes-red')->firstOrFail();$this->actingAs($player);
  $this->get(route('game.show',$track))->assertOk()->assertSee('race-canvas');
  $started=$this->postJson(route('game.start',$track))->assertOk()->json('race_token');
  $response=$this->postJson(route('game.finish',$track),['race_token'=>$started,'finish_time'=>0.1,'score'=>9000,'ending_type'=>'gold','bonus_count'=>0,'remaining_hp'=>94,'laps_completed'=>2])->assertOk();
  $response->assertJson(['ending_type'=>'gold','is_personal_best'=>true]);
  $this->assertDatabaseHas('race_results',['user_id'=>$player->id,'track_id'=>$track->id,'ending_type'=>'gold','is_personal_best'=>true]);
  $this->assertDatabaseHas('user_activity_logs',['user_id'=>$player->id,'event'=>'game.enter','track_id'=>$track->id]);
  $this->assertDatabaseHas('user_activity_logs',['user_id'=>$player->id,'event'=>'race.started','track_id'=>$track->id]);
  $this->assertDatabaseHas('user_activity_logs',['user_id'=>$player->id,'event'=>'race.finished','track_id'=>$track->id]);
  $this->assertDatabaseHas('user_activity_logs',['user_id'=>$player->id,'event'=>'personal_record.updated','track_id'=>$track->id]);
  $this->get(route('leaderboard',['track_id'=>$track->id]))->assertOk()->assertSee('pilot')->assertSee('Кольцо');
 }
 public function test_normal_finish_requires_two_completed_laps():void {
  $track=Track::where('slug','ring')->firstOrFail();$player=User::where('login','pilot')->firstOrFail();$this->actingAs($player);$token=$this->postJson(route('game.start',$track))->assertOk()->json('race_token');
  $payload=['race_token'=>$token,'finish_time'=>0.1,'score'=>9000,'ending_type'=>'gold','bonus_count'=>0,'remaining_hp'=>94,'laps_completed'=>1];
  $this->postJson(route('game.finish',$track),$payload)->assertStatus(422)->assertJsonPath('message','Для финиша нужно проехать два круга.');
  $payload['laps_completed']=2;$this->postJson(route('game.finish',$track),$payload)->assertOk()->assertJson(['ending_type'=>'gold']);
 }
 public function test_accident_is_recorded_but_is_not_a_personal_best():void {
  $track=Track::where('slug','snake')->firstOrFail();$player=User::where('login','pilot')->firstOrFail();$this->actingAs($player);
  $token=$this->postJson(route('game.start',$track))->assertOk()->json('race_token');
  $this->postJson(route('game.finish',$track),['race_token'=>$token,'finish_time'=>0.1,'score'=>0,'ending_type'=>'crash','bonus_count'=>0,'remaining_hp'=>0,'laps_completed'=>0])->assertOk()->assertJson(['ending_type'=>'crash','is_personal_best'=>false]);
  $this->assertDatabaseHas('race_results',['user_id'=>$player->id,'track_id'=>$track->id,'ending_type'=>'crash','is_personal_best'=>false]);
 }
 public function test_invalid_track_session_cannot_submit_a_result_twice():void {
  $track=Track::where('slug','ring')->firstOrFail();$other=Track::where('slug','snake')->firstOrFail();$player=User::where('login','pilot')->firstOrFail();$this->actingAs($player);
  $token=$this->postJson(route('game.start',$track))->assertOk()->json('race_token');
  $payload=['race_token'=>$token,'finish_time'=>0.1,'score'=>100,'ending_type'=>'gold','bonus_count'=>0,'remaining_hp'=>100,'laps_completed'=>2];
  $this->postJson(route('game.finish',$other),$payload)->assertStatus(422);
  $this->postJson(route('game.finish',$track),$payload)->assertOk();
  $this->postJson(route('game.finish',$track),$payload)->assertStatus(422);
 }
}
