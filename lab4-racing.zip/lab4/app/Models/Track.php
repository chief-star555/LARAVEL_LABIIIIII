<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Attributes\Fillable;use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Relations\HasMany;
#[Fillable(['slug','name','description','difficulty','grid','tile_size','start_direction','target_time','max_time'])]
class Track extends Model {
 protected function casts():array{return ['grid'=>'array'];}
 public function raceResults():HasMany{return $this->hasMany(RaceResult::class);}
 public function bonusCount():int{return collect($this->grid)->sum(fn(string $row)=>substr_count($row,'B'));}
 public function lapsRequired():int{return 2;}
 /** Ordered center-line for a single, unbranched loop, starting just after the finish gate. */
 public function circuitCells():array {
  $grid=$this->grid;$start=$finish=null;
  foreach($grid as $y=>$row)foreach(str_split($row) as $x=>$cell){if($cell==='S')$start=['x'=>$x,'y'=>$y];if($cell==='F')$finish=['x'=>$x,'y'=>$y];}
  if(!$start||!$finish)return[];
  $key=fn(array $p)=>$p['x'].':'.$p['y'];$previous=$finish;$current=$start;$path=[$start];$seen=[$key($start)=>true];$limit=count($grid)*strlen($grid[0]);
  for($steps=0;$steps<$limit;$steps++){
   if($current===$finish)return$path;
   $next=null;
   foreach([[1,0],[-1,0],[0,1],[0,-1]] as [$dx,$dy]){$x=$current['x']+$dx;$y=$current['y']+$dy;if($y<0||$y>=count($grid)||$x<0||$x>=strlen($grid[$y])||$grid[$y][$x]==='#')continue;$candidate=['x'=>$x,'y'=>$y];if($candidate===$previous)continue;if(isset($seen[$key($candidate)])&&$candidate!==$finish)continue;$next=$candidate;break;}
   if(!$next)return[];$previous=$current;$current=$next;$path[]=$current;$seen[$key($current)]=true;
  }
  return[];
 }
 public function previewPath():string {
  $path=$this->circuitCells();if(count($path)<4)return'';
  $coordinates=array_map(fn(array $point)=>(10+$point['x']*20).' '.(6+$point['y']*12),$path);
  return'M'.implode(' L',$coordinates).' Z';
 }
}
