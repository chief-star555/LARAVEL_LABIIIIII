<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
#[Fillable(['slug','name','brand','color_name','color_hex','accent_hex','body_style','description','top_speed','acceleration','handling'])]
class Car extends Model
{
    protected function casts(): array { return ['top_speed' => 'integer', 'acceleration' => 'integer', 'handling' => 'float']; }
    public function drivers(): HasMany { return $this->hasMany(User::class, 'current_car_id'); }
    public function raceResults(): HasMany { return $this->hasMany(RaceResult::class); }
}
