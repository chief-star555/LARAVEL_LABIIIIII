<?php
namespace App\Models;
use Database\Factories\UserFactory;use Illuminate\Database\Eloquent\Attributes\Fillable;use Illuminate\Database\Eloquent\Attributes\Hidden;use Illuminate\Database\Eloquent\Factories\HasFactory;use Illuminate\Database\Eloquent\Relations\BelongsTo;use Illuminate\Database\Eloquent\Relations\HasMany;use Illuminate\Foundation\Auth\User as Authenticatable;use Illuminate\Notifications\Notifiable;
#[Fillable(['login','password','role_id','current_car_id'])] #[Hidden(['password','remember_token'])]
class User extends Authenticatable {
 /** @use HasFactory<UserFactory> */ use HasFactory,Notifiable;
 public function role():BelongsTo{return $this->belongsTo(Role::class);}
 public function raceResults():HasMany{return $this->hasMany(RaceResult::class);}
 public function currentCar():BelongsTo{return $this->belongsTo(Car::class,'current_car_id');}
 public function activityLogs():HasMany{return $this->hasMany(UserActivityLog::class);}
 protected function casts():array{return ['password'=>'hashed'];}
}
