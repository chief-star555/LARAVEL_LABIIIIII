<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Attributes\Fillable;use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Relations\BelongsTo;use Illuminate\Http\Request;
#[Fillable(['user_id','track_id','event','metadata','ip_address','user_agent','created_at'])]
class UserActivityLog extends Model {
 public $timestamps=false;
 protected function casts():array{return ['metadata'=>'array','created_at'=>'datetime'];}
 public function user():BelongsTo{return $this->belongsTo(User::class);}
 public function track():BelongsTo{return $this->belongsTo(Track::class);}
 public static function record(string $event,?User $user=null,array $metadata=[],?Track $track=null):self {
  /** @var Request|null $request */ $request=app()->bound('request')?request():null;
  return static::create(['user_id'=>$user?->getKey(),'track_id'=>$track?->getKey(),'event'=>$event,'metadata'=>$metadata?:null,'ip_address'=>$request?->ip(),'user_agent'=>$request?->userAgent(),'created_at'=>now()]);
 }
}
