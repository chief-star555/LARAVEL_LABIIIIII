<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Attributes\Fillable;use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Relations\BelongsTo;
#[Fillable(['user_id','track_id','car_id','finish_time','score','ending_type','bonus_count','remaining_hp','is_personal_best','completed_at'])]
class RaceResult extends Model {
 protected function casts():array{return ['finish_time'=>'decimal:2','score'=>'integer','bonus_count'=>'integer','remaining_hp'=>'integer','is_personal_best'=>'boolean','completed_at'=>'datetime'];}
 public function user():BelongsTo{return $this->belongsTo(User::class);}
 public function track():BelongsTo{return $this->belongsTo(Track::class);}
 public function car():BelongsTo{return $this->belongsTo(Car::class);}
}
