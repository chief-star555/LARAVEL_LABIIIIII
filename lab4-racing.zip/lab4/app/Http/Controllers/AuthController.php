<?php
namespace App\Http\Controllers;
use App\Models\Car;use App\Models\Role;use App\Models\User;use App\Models\UserActivityLog;use App\Support\PreviewAuthToken;use Illuminate\Http\RedirectResponse;use Illuminate\Http\Request;use Illuminate\Support\Facades\Auth;use Illuminate\Support\Facades\Validator;use Illuminate\Validation\Rules\Password;use Illuminate\View\View;
class AuthController extends Controller {
 public function loginForm():View{return view('auth.login');}
 public function registerForm():View{return view('auth.register');}
 public function register(Request $request):RedirectResponse {
  $validator=Validator::make($request->all(),['login'=>['required','string','min:3','max:40','alpha_dash','unique:users,login'],'password'=>['required','confirmed',Password::min(8)]]);
  if($validator->fails()){
   if(PreviewAuthToken::enabled())return$this->previewAuthError($request,'/register','registration');
   return redirect()->back()->withErrors($validator)->withInput();
  }
  $data=$validator->validated();
  $defaultCar=Car::where('slug','mercedes-red')->firstOrFail();
  $user=User::create(['login'=>$data['login'],'password'=>$data['password'],'role_id'=>Role::where('name','player')->firstOrFail()->id,'current_car_id'=>$defaultCar->id]);
  Auth::login($user);$request->session()->regenerate();UserActivityLog::record('auth.registered',$user,['car_id'=>$defaultCar->id,'car_name'=>$defaultCar->name]);
  $destination=PreviewAuthToken::safeDestination((string)$request->input('preview_intended','/'));if($token=PreviewAuthToken::issue($user))$destination=PreviewAuthToken::withToken($destination,$token);
  return redirect($destination)->with('success','Аккаунт создан. Добро пожаловать на трассу!');
 }
 public function login(Request $request):RedirectResponse {
  $validator=Validator::make($request->all(),['login'=>['required','string'],'password'=>['required','string']]);
  if($validator->fails()){
   if(PreviewAuthToken::enabled())return$this->previewAuthError($request,'/login','credentials');
   return redirect()->back()->withErrors($validator)->withInput();
  }
  $credentials=$validator->validated();
  if(!Auth::attempt($credentials)){
   UserActivityLog::record('auth.login_failed',null,['login'=>$credentials['login']]);
   if(PreviewAuthToken::enabled())return$this->previewAuthError($request,'/login','credentials');
   return back()->withErrors(['login'=>'Проверьте логин и пароль.'])->onlyInput('login');
  }
  $request->session()->regenerate();UserActivityLog::record('auth.login',$request->user());
  $intended=(string)$request->session()->pull('url.intended',(string)$request->input('preview_intended','/'));
  $destination=PreviewAuthToken::safeDestination($intended);if($token=PreviewAuthToken::issue($request->user()))$destination=PreviewAuthToken::withToken($destination,$token);
  return redirect()->to($destination)->with('success','Вход выполнен. Трасса готова к заезду.');
 }
 public function logout(Request $request):RedirectResponse {
  UserActivityLog::record('auth.logout',$request->user());$bridgeToken=$request->attributes->get('preview_auth_token');Auth::logout();$request->session()->invalidate();$request->session()->regenerateToken();PreviewAuthToken::revoke($bridgeToken);
  return redirect('/')->with('success','Вы вышли из аккаунта.');
 }
 private function previewAuthError(Request $request,string $path,string $error):RedirectResponse {
  $query=['preview_error'=>$error];$intended=(string)$request->input('preview_intended','');
  if($intended!=='')$query['preview_intended']=PreviewAuthToken::safeDestination($intended);
  return redirect()->to($path.'?'.http_build_query($query));
 }
}
