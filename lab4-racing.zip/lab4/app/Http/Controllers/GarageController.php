<?php
namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\RaceResult;
use App\Models\Track;
use App\Models\UserActivityLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class GarageController extends Controller
{
    public function show(Request $request): View
    {
        $user = $request->user();
        $cars = Car::orderBy('id')->get();
        $activeCar = $cars->firstWhere('id', $user->current_car_id) ?? $cars->firstOrFail();
        $tracks = Track::orderBy('id')->get();
        $personalBests = $user->raceResults()
            ->where('car_id', $activeCar->id)
            ->where('is_personal_best', true)
            ->with('track:id,name,slug,target_time')
            ->get()
            ->keyBy('track_id');

        // Only fetch the seven-day slice for the activity chart; aggregate the lifetime totals in SQL.
        $lifetime = $user->raceResults()->selectRaw('COUNT(*) as races, COALESCE(SUM(score), 0) as points')->first();
        $successful = fn () => $user->raceResults()->whereIn('ending_type', ['gold', 'normal', 'secret']);
        $gold = fn () => $user->raceResults()->whereIn('ending_type', ['gold', 'secret']);
        $weekStart = today()->subDays(6);
        $weekResults = $user->raceResults()->where('completed_at', '>=', $weekStart)->get(['completed_at']);
        $activityCounts = $weekResults->groupBy(fn (RaceResult $result) => $result->completed_at?->toDateString())->map->count();
        $activityDays = collect(range(6, 0))->map(function (int $offset) use ($activityCounts) {
            $date = today()->subDays($offset);
            $runs = (int) $activityCounts->get($date->toDateString(), 0);
            return ['date' => $date, 'runs' => $runs, 'label' => $this->pluralForm($runs, 'заезд', 'заезда', 'заездов')];
        });
        $activityMax = max(1, (int) $activityDays->max('runs'));

        // Track-specific standing among every driver's current personal best.
        $rankedRecords = RaceResult::whereIn('track_id', $tracks->modelKeys())
            ->where('car_id', $activeCar->id)
            ->where('is_personal_best', true)
            ->get(['user_id', 'track_id', 'finish_time', 'score'])
            ->groupBy('track_id');
        $personalBestRanks = [];
        foreach ($rankedRecords as $trackId => $records) {
            $sorted = $records->sort(function (RaceResult $a, RaceResult $b) {
                return ((float) $a->finish_time <=> (float) $b->finish_time)
                    ?: ((int) $b->score <=> (int) $a->score)
                    ?: ((int) $a->user_id <=> (int) $b->user_id);
            })->values();
            foreach ($sorted as $index => $record) {
                if ((int) $record->user_id === (int) $user->id) {
                    $personalBestRanks[$trackId] = $index + 1;
                    break;
                }
            }
        }

        $recentResults = $user->raceResults()
            ->with(['track:id,name', 'car:id,name,color_name'])
            ->latest('completed_at')
            ->limit(8)
            ->get();

        $trackCount = $tracks->count();
        $recordedTrackCount = $user->raceResults()->where('is_personal_best', true)->distinct()->count('track_id');
        $achievements = [
            ['icon' => '🏁', 'title' => 'Первый финиш', 'description' => 'Заверши свой первый заезд.', 'progress' => $successful()->exists() ? 1 : 0, 'goal' => 1],
            ['icon' => '🥇', 'title' => 'Золотая каска', 'description' => 'Получи золотой или секретный финал.', 'progress' => $gold()->exists() ? 1 : 0, 'goal' => 1],
            ['icon' => '✦', 'title' => 'Чистая линия', 'description' => 'Финишируй, сохранив не менее 80% HP.', 'progress' => $successful()->where('remaining_hp', '>=', 80)->exists() ? 1 : 0, 'goal' => 1],
            ['icon' => '⛽', 'title' => 'Охотник за бонусами', 'description' => 'Собери все канистры на одной трассе.', 'progress' => $user->raceResults()->where('ending_type', 'secret')->exists() ? 1 : 0, 'goal' => 1],
            ['icon' => '⌁', 'title' => 'Мастер маршрутов', 'description' => 'Установи рекорд на каждой трассе.', 'progress' => min($trackCount, $recordedTrackCount), 'goal' => max(1, $trackCount)],
            ['icon' => '↗', 'title' => 'Не сдавайся', 'description' => 'Финишируй после обычного, не золотого заезда.', 'progress' => $user->raceResults()->where('ending_type', 'normal')->exists() ? 1 : 0, 'goal' => 1],
        ];
        $unlockedAchievements = collect($achievements)->filter(fn (array $achievement) => $achievement['progress'] >= $achievement['goal'])->count();

        return view('garage.show', [
            'user' => $user,
            'tracks' => $tracks,
            'cars' => $cars,
            'activeCar' => $activeCar,
            'personalBests' => $personalBests,
            'personalBestRanks' => $personalBestRanks,
            'recentResults' => $recentResults,
            'activityDays' => $activityDays,
            'activityMax' => $activityMax,
            'weekRunCount' => $weekResults->count(),
            'weekRunLabel' => $this->pluralForm($weekResults->count(), 'заезд', 'заезда', 'заездов'),
            'stats' => [
                'races' => (int) $lifetime->races,
                'wins' => $gold()->count(),
                'records' => $personalBests->count(),
                'points' => (int) $lifetime->points,
            ],
            'achievements' => $achievements,
            'unlockedAchievements' => $unlockedAchievements,
        ]);
    }

    public function selectCar(Request $request): RedirectResponse
    {
        $data = $request->validate(['car_id' => ['required', 'integer', 'exists:cars,id']]);
        $car = Car::findOrFail($data['car_id']);
        $request->user()->update(['current_car_id' => $car->id]);
        UserActivityLog::record('garage.car_selected', $request->user(), [
            'car_id' => $car->id,
            'car_name' => $car->name,
            'car_slug' => $car->slug,
        ]);

        return redirect('/garage')->with('success', 'В гараже выбрана машина: '.$car->name.'.');
    }

    private function pluralForm(int $count, string $one, string $few, string $many): string
    {
        $lastTwo = $count % 100;
        if ($lastTwo >= 11 && $lastTwo <= 14) return $many;
        return match ($count % 10) {
            1 => $one,
            2, 3, 4 => $few,
            default => $many,
        };
    }
}
