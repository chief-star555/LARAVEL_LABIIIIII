<?php
namespace App\Http\Controllers;

use App\Models\RaceResult;
use App\Models\Role;
use App\Models\Track;
use App\Models\User;
use App\Models\UserActivityLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminController extends Controller
{
    public function index(): View
    {
        return view('admin', [
            'users' => User::with('role')->orderBy('login')->get(),
            'roles' => Role::orderBy('id')->get(),
            'roleLabels' => ['player' => 'Игрок', 'admin' => 'Администратор'],
            'stats' => [
                'users' => User::count(),
                'races' => RaceResult::count(),
                'tracks' => Track::count(),
                'records' => RaceResult::where('is_personal_best', true)->count(),
            ],
            'activityLogs' => UserActivityLog::with(['user:id,login', 'track:id,name'])
                ->latest('created_at')
                ->limit(12)
                ->get(),
        ]);
    }

    public function updateUserRole(Request $request, User $user): RedirectResponse
    {
        $data = $request->validate(['role_id' => ['required', 'integer', 'exists:roles,id']]);
        abort_if($request->user()->is($user) && (int) $data['role_id'] !== (int) $user->role_id, 422, 'Нельзя изменить собственную роль.');
        $user->update($data);

        return redirect('/admin')->with('success', 'Роль игрока изменена.');
    }
}
