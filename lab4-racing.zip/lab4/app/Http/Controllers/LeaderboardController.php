<?php
namespace App\Http\Controllers;
use App\Models\Car;
use App\Models\RaceResult;
use App\Models\Track;
use Illuminate\Http\Request;
use Illuminate\View\View;
class LeaderboardController extends Controller {
 public function index(Request $request):View {
  $validated=$request->validate(['track_id'=>['nullable','integer','exists:tracks,id'],'car_id'=>['nullable','integer','exists:cars,id']]);
  $trackId=$validated['track_id']??null;$carId=$validated['car_id']??null;
  $results=RaceResult::with(['user:id,login','track:id,name','car:id,name,color_name'])
   ->where('is_personal_best',true)
   ->when($trackId,fn($q)=>$q->where('track_id',$trackId))
   ->when($carId,fn($q)=>$q->where('car_id',$carId))
   ->orderBy('finish_time')->orderByDesc('score')->orderBy('id')->limit(10)->get();
  return view('leaderboard.index',['tracks'=>Track::orderBy('name')->get(),'cars'=>Car::orderBy('id')->get(),'results'=>$results,'selectedTrackId'=>$trackId?(int)$trackId:null,'selectedCarId'=>$carId?(int)$carId:null]);
 }
}
