<?php
namespace App\Http\Controllers;
use App\Models\Car;
use App\Models\RaceResult;
use App\Models\Track;
use App\Models\UserActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;
class GameController extends Controller {
 public function tracks():View{return view('home',['tracks'=>Track::orderBy('id')->get(),'cars'=>Car::orderBy('id')->get()]);}
 public function show(Request $request,Track $track):View {
  $user=$request->user();
  $car=$user->currentCar??Car::where('slug','mercedes-red')->firstOrFail();
  UserActivityLog::record('game.enter',$user,['track'=>$track->name,'car_id'=>$car->id,'car_name'=>$car->name],$track);
  $personalBest=$user->raceResults()->where('track_id',$track->id)->where('car_id',$car->id)->where('is_personal_best',true)->first();
  return view('game.show',['track'=>$track,'car'=>$car,'personalBest'=>$personalBest]);
 }
 public function start(Request $request,Track $track):JsonResponse {
  $user=$request->user();$car=$user->currentCar??Car::where('slug','mercedes-red')->firstOrFail();
  $token=(string)Str::uuid();$run=['track_id'=>$track->id,'car_id'=>$car->id,'started_at'=>microtime(true),'user_id'=>$user->id];
  if($request->attributes->get('preview_auth_user'))Cache::store(config('preview_auth.cache_store','file'))->put($this->previewRaceKey($token),$run,now()->addMinutes(90));
  else $request->session()->put("race_runs.{$token}",$run);
  UserActivityLog::record('race.started',$user,['race_token'=>$token,'car_id'=>$car->id,'car_name'=>$car->name,'car_slug'=>$car->slug],$track);
  return response()->json(['race_token'=>$token,'car_id'=>$car->id]);
 }
 public function finish(Request $request,Track $track):JsonResponse {
  $totalBonuses=$track->bonusCount();
  $data=$request->validate(['race_token'=>['required','uuid'],'finish_time'=>['required','numeric','min:0.1','max:'.($track->max_time+10)],'score'=>['required','integer','min:0','max:200000'],'ending_type'=>['required','in:gold,normal,crash,timeout,secret'],'bonus_count'=>['required','integer','min:0','max:'.$totalBonuses],'remaining_hp'=>['required','integer','min:0','max:100'],'laps_completed'=>['required','integer','min:0','max:'.$track->lapsRequired()]]);
  if($data['laps_completed']<$track->lapsRequired()&&!in_array($data['ending_type'],['crash','timeout'],true))abort(422,'Для финиша нужно проехать два круга.');
  $sessionKey='race_runs.'.$data['race_token'];$bridgeRunKey=$request->attributes->get('preview_auth_user')?$this->previewRaceKey($data['race_token']):null;
  $run=$bridgeRunKey?Cache::store(config('preview_auth.cache_store','file'))->get($bridgeRunKey):$request->session()->get($sessionKey);
  abort_unless($run&&(int)$run['track_id']===(int)$track->id&&(!$bridgeRunKey||(int)($run['user_id']??0)===(int)$request->user()->id),422,'Заезд не найден или уже завершён.');
  $serverElapsed=max(0,microtime(true)-(float)$run['started_at']);
  abort_if((float)$data['finish_time']>$serverElapsed+5,422,'Время заезда не совпадает с серверным.');
  $finishTime=min((float)$track->max_time,max((float)$data['finish_time'],$serverElapsed-.75));
  $ending=$this->endingType($data,$track,$finishTime,$serverElapsed,$totalBonuses);$validFinish=in_array($ending,['gold','normal','secret'],true);$user=$request->user();
  // Car is read from the server-side run snapshot (session or preview cache), never from client input.
  $car=Car::findOrFail((int)($run['car_id']??$user->current_car_id));
  $result=DB::transaction(function()use($user,$track,$car,$data,$finishTime,$ending,$validFinish,$request,$sessionKey,$bridgeRunKey){
   $best=RaceResult::where('user_id',$user->id)->where('track_id',$track->id)->where('car_id',$car->id)->where('is_personal_best',true)->lockForUpdate()->first();
   $isBest=$validFinish&&(!$best||$finishTime<(float)$best->finish_time);if($isBest&&$best)$best->update(['is_personal_best'=>false]);
   $result=RaceResult::create(['user_id'=>$user->id,'track_id'=>$track->id,'car_id'=>$car->id,'finish_time'=>round($finishTime,2),'score'=>$data['score'],'ending_type'=>$ending,'bonus_count'=>$data['bonus_count'],'remaining_hp'=>$data['remaining_hp'],'is_personal_best'=>$isBest,'completed_at'=>now()]);
   $metadata=['result_id'=>$result->id,'car_id'=>$car->id,'car_name'=>$car->name,'car_slug'=>$car->slug,'finish_time'=>round($finishTime,2),'score'=>(int)$data['score'],'ending_type'=>$ending,'bonus_count'=>(int)$data['bonus_count'],'remaining_hp'=>(int)$data['remaining_hp'],'laps_completed'=>(int)$data['laps_completed'],'is_personal_best'=>$isBest];
   UserActivityLog::record('race.finished',$user,$metadata,$track);
   if($isBest)UserActivityLog::record('personal_record.updated',$user,$metadata,$track);
   if($bridgeRunKey)Cache::store(config('preview_auth.cache_store','file'))->forget($bridgeRunKey);else $request->session()->forget($sessionKey);return $result;
  });
  return response()->json(['result_id'=>$result->id,'finish_time'=>(float)$result->finish_time,'score'=>$result->score,'ending_type'=>$result->ending_type,'is_personal_best'=>$result->is_personal_best,'car_id'=>$car->id,'car_name'=>$car->name]);
 }
 private function previewRaceKey(string $raceToken):string{return'preview-auth-race:'.hash('sha256',$raceToken);}
 private function endingType(array $data,Track $track,float $finishTime,float $serverElapsed,int $totalBonuses):string {
  if((int)$data['remaining_hp']<=0)return 'crash';
  if($serverElapsed >= $track->max_time||$finishTime >= $track->max_time)return 'timeout';
  if($totalBonuses>0&&(int)$data['bonus_count'] >= $totalBonuses)return 'secret';
  return $finishTime<=$track->target_time?'gold':'normal';
 }
}
