<?php
namespace App\Http\Middleware;
use App\Support\PreviewAuthToken;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;
class PreviewAuthBridge {
 public function handle(Request $request,Closure $next):Response {
  if(!PreviewAuthToken::enabled())return$next($request);
  $token=(string)($request->query('preview_auth')??$request->header('X-Preview-Auth',''));
  $user=PreviewAuthToken::resolve($token);
  if($user){Auth::setUser($user);$request->attributes->set('preview_auth_user',$user);$request->attributes->set('preview_auth_token',$token);}
  if($request->isMethod('GET')&&in_array($request->path(),['login','register'],true))$request->attributes->set('preview_guest_csrf',PreviewAuthToken::issueGuestCsrf());
  $response=$next($request);
  if($response->headers->has('Location')){
   $location=$response->headers->get('Location');$parts=parse_url($location);
   if($parts!==false&&(!isset($parts['host'])||strcasecmp($parts['host'],$request->getHost())===0)){
    $relative=($parts['path']??'/').(isset($parts['query'])?'?'.$parts['query']:'').(isset($parts['fragment'])?'#'.$parts['fragment']:'');
    if(!str_starts_with($relative,'/')||str_starts_with($relative,'//'))$relative='/';
    if(!$user&&($parts['path']??'')==='/login'&&!in_array($request->path(),['login','register'],true)){
     $target=$request->getPathInfo();$targetQuery=$request->query();unset($targetQuery['preview_auth']);if($targetQuery)$target.='?'.http_build_query($targetQuery);
     $query=[];parse_str($parts['query']??'',$query);$query['preview_intended']=PreviewAuthToken::safeDestination($target);
     $relative='/login?'.http_build_query($query);
    }
    if($user&&PreviewAuthToken::resolve($token))$relative=PreviewAuthToken::withToken($relative,$token);
    $response->headers->set('Location',$relative);
   }
  }
  if($user){
   if(str_starts_with(strtolower($response->headers->get('Content-Type','')),'text/html')&&is_string($response->getContent()))$response->setContent($this->carryToken($response->getContent(),$token));
   $response->headers->set('Cache-Control','no-store, private');$response->headers->set('Referrer-Policy','no-referrer');
  }
  return$response;
 }
 private function carryToken(string $html,string $token):string {
  $html=preg_replace_callback('/<(a|form)\b[^>]*>/i',function($match)use($token){
   $tag=$match[0];$attr=strtolower($match[1])==='a'?'href':'action';
   return preg_replace_callback('/\b('.preg_quote($attr,'/').')=("|\')([^"\']*)\2/i',function($a)use($token){$value=html_entity_decode($a[3],ENT_QUOTES|ENT_HTML5,'UTF-8');if(!str_starts_with($value,'/')||str_starts_with($value,'//')||str_contains($value,'preview_auth='))return$a[0];$url=htmlspecialchars(PreviewAuthToken::withToken($value,$token),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');return$a[1].'='.$a[2].$url.$a[2];},$tag);
  },$html)??$html;
  return preg_replace_callback('/\b(data-[a-z0-9_-]*url)=("|\')([^"\']*)\2/i',function($a)use($token){$value=html_entity_decode($a[3],ENT_QUOTES|ENT_HTML5,'UTF-8');if(!str_starts_with($value,'/')||str_contains($value,'preview_auth='))return$a[0];return$a[1].'='.$a[2].htmlspecialchars(PreviewAuthToken::withToken($value,$token),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').$a[2];},$html)??$html;
 }
}
