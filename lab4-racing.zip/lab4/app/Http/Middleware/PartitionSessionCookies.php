<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class PartitionSessionCookies {
 public function handle(Request $request,Closure $next):Response {
  $response=$next($request);
  if(!config('session.partitioned')||config('session.same_site')!=='none'||(!config('session.secure')&&!$request->isSecure()))return$response;
  foreach($response->headers->getCookies() as $cookie){
   if(in_array($cookie->getName(),[config('session.cookie'),'XSRF-TOKEN'],true))$response->headers->setCookie($cookie->withPartitioned());
  }
  return$response;
 }
}
