<?php
namespace App\Http\Middleware;
use App\Support\PreviewAuthToken;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
class PreviewCsrf extends PreventRequestForgery {
 protected function tokensMatch($request) {
  if(PreviewAuthToken::enabled()){
   if($request->attributes->get('preview_auth_user'))return true;
   if(in_array($request->path(),['login','register'],true)&&$request->isMethod('POST')&&PreviewAuthToken::validGuestCsrf($request->input('preview_guest_csrf')))return true;
  }
  return parent::tokensMatch($request);
 }
}
