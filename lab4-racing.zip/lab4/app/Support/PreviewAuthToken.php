<?php
namespace App\Support;
use App\Models\User;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
class PreviewAuthToken {
 public static function enabled():bool{return (bool)config('preview_auth.enabled')&&app()->environment('local');}
 private static function store(){return Cache::store(config('preview_auth.cache_store','file'));}
 private static function key(string $token):string{return 'preview-auth:'.hash('sha256',$token);}
 public static function issue(User $user):?string {
  if(!self::enabled())return null;$token=Str::random(64);self::store()->put(self::key($token),(int)$user->id,now()->addMinutes((int)config('preview_auth.lifetime_minutes',720)));return$token;
 }
 public static function resolve(?string $token):?User {
  if(!self::enabled()||!$token||strlen($token)<40)return null;$id=self::store()->get(self::key($token));return$id?User::find((int)$id):null;
 }
 public static function revoke(?string $token):void {if(self::enabled()&&$token)self::store()->forget(self::key($token));}
 public static function issueGuestCsrf():string {$token=Str::random(64);self::store()->put('preview-guest-csrf:'.hash('sha256',$token),true,now()->addMinutes(45));return$token;}
 public static function validGuestCsrf(?string $token):bool {
  if(!self::enabled()||!$token||strlen($token)<40)return false;$key='preview-guest-csrf:'.hash('sha256',$token);$valid=(bool)self::store()->get($key);if($valid)self::store()->forget($key);return$valid;
 }
 public static function withToken(string $url,string $token):string {
  $parts=parse_url($url);if($parts===false)return$url;$query=[];parse_str($parts['query']??'',$query);$query['preview_auth']=$token;
  $result=isset($parts['scheme'])?$parts['scheme'].'://'.($parts['user']??'').(isset($parts['pass'])?':'.$parts['pass']:'').(isset($parts['user'])?'@':'').($parts['host']??'').(isset($parts['port'])?':'.$parts['port']:''):'';
  $result.=($parts['path']??'/').'?'.http_build_query($query);if(isset($parts['fragment']))$result.='#'.$parts['fragment'];return$result;
 }
 public static function safeDestination(string $url):string {
  $parts=parse_url($url);if($parts===false)return'/';$path=$parts['path']??'/';if(!str_starts_with($path,'/')||str_starts_with($path,'//'))$path='/';$query=[];parse_str($parts['query']??'',$query);unset($query['preview_auth']);return$path.($query?'?'.http_build_query($query):'');
 }
}
