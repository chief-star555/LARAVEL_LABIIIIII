<?php
return [
    // Temporary token bridge for embedded local previews whose browser blocks session cookies.
    // Keep disabled on any publicly deployed application.
    'enabled' => env('PREVIEW_AUTH_BRIDGE', false),
    'cache_store' => env('PREVIEW_AUTH_CACHE_STORE', 'file'),
    'lifetime_minutes' => (int) env('PREVIEW_AUTH_LIFETIME', 720),
];
