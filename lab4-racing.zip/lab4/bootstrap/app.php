<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use App\Http\Middleware\RoleMiddleware;
use App\Http\Middleware\PartitionSessionCookies;
use App\Http\Middleware\PreviewAuthBridge;
use App\Http\Middleware\PreviewCsrf;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // The site runs behind the Arena preview reverse proxy; trust forwarded
        // host/scheme so links and secure redirects stay on the preview origin.
        $middleware->trustProxies(at: env('TRUSTED_PROXIES', '*'));
        // Relative redirect paths keep navigation on the active preview/deployment host.
        $middleware->redirectGuestsTo('/login');
        // CHIPS keeps the auth session available in browsers that partition or block third-party cookies.
        $middleware->append(PartitionSessionCookies::class);
        $middleware->append(PreviewAuthBridge::class);
        $middleware->replaceInGroup('web', PreventRequestForgery::class, PreviewCsrf::class);
        $middleware->alias([
            'role' => RoleMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
