<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::create('user_activity_logs',function(Blueprint $table){
  $table->id();$table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();$table->foreignId('track_id')->nullable()->constrained()->nullOnDelete();
  $table->string('event',60)->index();$table->json('metadata')->nullable();$table->string('ip_address',45)->nullable();$table->text('user_agent')->nullable();
  $table->timestamp('created_at')->useCurrent();$table->index(['user_id','created_at']);
 }); }
 public function down(): void {Schema::dropIfExists('user_activity_logs');}
};
