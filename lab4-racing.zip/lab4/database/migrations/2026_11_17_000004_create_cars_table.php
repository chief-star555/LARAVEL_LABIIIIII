<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::create('cars', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('name');
            $table->string('brand');
            $table->string('color_name');
            $table->string('color_hex', 7);
            $table->string('accent_hex', 7);
            $table->string('body_style', 20);
            $table->string('description', 255);
            $table->unsignedSmallInteger('top_speed');
            $table->unsignedSmallInteger('acceleration');
            $table->decimal('handling', 3, 2)->default(1);
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('cars'); }
};
