<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::create('race_results', function(Blueprint $table){
  $table->id();$table->foreignId('user_id')->constrained()->cascadeOnDelete();$table->foreignId('track_id')->constrained()->cascadeOnDelete();
  $table->decimal('finish_time',8,2);$table->unsignedInteger('score')->default(0);$table->string('ending_type',24);
  $table->unsignedSmallInteger('bonus_count')->default(0);$table->unsignedTinyInteger('remaining_hp')->default(0);
  $table->boolean('is_personal_best')->default(false);$table->timestamp('completed_at');$table->timestamps();
  $table->index(['track_id','is_personal_best','finish_time'],'race_results_leaderboard_idx');
  $table->index(['user_id','track_id','is_personal_best'],'race_results_personal_best_idx');
 }); }
 public function down(): void {Schema::dropIfExists('race_results');}
};
