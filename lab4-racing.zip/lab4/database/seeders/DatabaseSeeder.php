<?php
namespace Database\Seeders;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
class DatabaseSeeder extends Seeder {
 public function run():void {
  $player=Role::firstOrCreate(['name'=>'player']);$admin=Role::firstOrCreate(['name'=>'admin']);
  $this->call(CarSeeder::class);
  // Local demo accounts only. Change these credentials before deployment.
  User::updateOrCreate(['login'=>'pilot'],['password'=>'racing12345','role_id'=>$player->id]);
  User::updateOrCreate(['login'=>'admin'],['password'=>'racing12345','role_id'=>$admin->id]);
  $defaultCarId=\App\Models\Car::where('slug','mercedes-red')->value('id');
  User::whereNull('current_car_id')->update(['current_car_id'=>$defaultCarId]);
  $this->call(TrackSeeder::class);
 }
}
