@extends('layouts.site')
@section('title','Регистрация — Пит-стоп')
@section('content')
<section class="auth-page">
    <aside class="auth-promo auth-promo-register">
        <div class="auth-promo-brand"><span class="brand-mark">P</span><span>ПИТ-СТОП <small>ARCADE RACING</small></span></div>
        <div class="auth-promo-art" aria-hidden="true"><div class="auth-orbit auth-orbit-one"></div><div class="auth-orbit auth-orbit-two"></div><div class="auth-race-car"><span></span></div><span class="auth-art-number">GO</span></div>
        <div class="auth-promo-copy"><p class="eyebrow">НОВЫЙ ПИЛОТ НА ТРАССЕ</p><h2>Здесь начинается<br>твоя <em>легенда.</em></h2><p>Создай аккаунт, чтобы сохранять результаты и бороться за рекорды.</p></div>
        <div class="auth-promo-stats"><span><b>03</b> трассы</span><i></i><span><b>02</b> круга</span><i></i><span><b>∞</b> попыток</span></div>
    </aside>
    <div class="auth-form-side"><a class="auth-back" href="{{route('home', [], false)}}">← На главную</a><div class="auth-form-content"><p class="eyebrow">ПОЛУЧИ СВОЙ НОМЕР</p><h1>Создать аккаунт</h1><p class="auth-subtitle">Пара минут — и ты на стартовой линии.</p>
        @if(request()->query('preview_error')==='registration')<div class="message message-error" role="alert">Не удалось создать аккаунт. Проверь логин, пароль и подтверждение, затем попробуй ещё раз.</div>@endif
        <form class="form-panel auth-panel" method="POST" action="{{route('register.store', [], false)}}">@csrf @if(config('preview_auth.enabled')&&request()->attributes->get('preview_guest_csrf'))<input type="hidden" name="preview_guest_csrf" value="{{request()->attributes->get('preview_guest_csrf')}}">@endif @if(request()->query('preview_intended'))<input type="hidden" name="preview_intended" value="{{request()->query('preview_intended')}}">@endif
            <label class="form-field"><span>Логин</span><input type="text" name="login" value="{{old('login')}}" autocomplete="username" placeholder="3–40 символов" required autofocus>@error('login')<span class="field-error">{{$message}}</span>@enderror</label>
            <label class="form-field"><span>Пароль</span><input type="password" name="password" autocomplete="new-password" placeholder="Не менее 8 символов" required>@error('password')<span class="field-error">{{$message}}</span>@enderror</label>
            <label class="form-field"><span>Повтори пароль</span><input type="password" name="password_confirmation" autocomplete="new-password" placeholder="Ещё раз пароль" required></label>
            <button class="button auth-submit" type="submit">Создать пилота <span>→</span></button>
            <p class="form-note">Уже есть аккаунт? <a class="text-link" href="{{route('login', request()->filled('preview_intended')?['preview_intended'=>request()->query('preview_intended')]:[], false)}}">Войти</a></p>
        </form>
        <div class="auth-security"><span>◈</span> Логин и пароль защищены</div>
    </div></div>
</section>
@endsection
