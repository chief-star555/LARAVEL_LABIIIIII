@extends('layouts.site')
@section('title','Вход — Пит-стоп')
@section('content')
<section class="auth-page">
    <aside class="auth-promo">
        <div class="auth-promo-brand"><span class="brand-mark">P</span><span>ПИТ-СТОП <small>ARCADE RACING</small></span></div>
        <div class="auth-promo-art" aria-hidden="true"><div class="auth-orbit auth-orbit-one"></div><div class="auth-orbit auth-orbit-two"></div><div class="auth-race-car"><span></span></div><span class="auth-art-number">01</span></div>
        <div class="auth-promo-copy"><p class="eyebrow">ТВОЙ ЗАЕЗД ПРОДОЛЖАЕТСЯ</p><h2>Рекорд уже<br>за <em>поворотом.</em></h2><p>Войди в аккаунт, выбери трассу и покажи лучшее время.</p></div>
        <div class="auth-promo-stats"><span><b>03</b> трассы</span><i></i><span><b>02</b> круга</span><i></i><span><b>∞</b> попыток</span></div>
    </aside>
    <div class="auth-form-side"><a class="auth-back" href="{{route('home', [], false)}}">← На главную</a><div class="auth-form-content"><p class="eyebrow">СНОВА ЗА РУЛЬ</p><h1>Войти в игру</h1><p class="auth-subtitle">Введи свои данные, чтобы продолжить гонку.</p>
        @if(request()->query('preview_error')==='credentials')<div class="message message-error" role="alert">Проверьте логин и пароль, затем попробуйте ещё раз.</div>@endif
        <form class="form-panel auth-panel" method="POST" action="{{route('login.store', [], false)}}">@csrf @if(config('preview_auth.enabled')&&request()->attributes->get('preview_guest_csrf'))<input type="hidden" name="preview_guest_csrf" value="{{request()->attributes->get('preview_guest_csrf')}}">@endif @if(request()->query('preview_intended'))<input type="hidden" name="preview_intended" value="{{request()->query('preview_intended')}}">@endif
            <label class="form-field"><span>Логин</span><input type="text" name="login" value="{{old('login')}}" autocomplete="username" placeholder="Например, pilot" required autofocus>@error('login')<span class="field-error">{{$message}}</span>@enderror</label>
            <label class="form-field"><span>Пароль</span><input type="password" name="password" autocomplete="current-password" placeholder="Твой пароль" required>@error('password')<span class="field-error">{{$message}}</span>@enderror</label>
            <button class="button auth-submit" type="submit">На старт <span>→</span></button>
            <p class="form-note">Ещё нет аккаунта? <a class="text-link" href="{{route('register', request()->filled('preview_intended')?['preview_intended'=>request()->query('preview_intended')]:[], false)}}">Зарегистрироваться</a></p>
        </form>
        <div class="auth-security"><span>◈</span> Твои результаты сохраняются в профиле</div>
    </div></div>
</section>
@endsection
