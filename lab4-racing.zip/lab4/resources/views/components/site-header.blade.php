<header class="site-header">
    <div class="header-inner">
        <a class="brand" href="{{route('home', [], false)}}"><span class="brand-mark">P</span><span>Пит-стоп</span></a>
        <nav class="main-nav" aria-label="Основная навигация">
            <a href="{{route('home', [], false)}}" @class(['is-active'=>request()->routeIs('home','game.*')]) @if(request()->routeIs('home','game.*')) aria-current="page" @endif>Трассы</a>
            <a href="{{route('leaderboard', [], false)}}" @class(['is-active'=>request()->routeIs('leaderboard')]) @if(request()->routeIs('leaderboard')) aria-current="page" @endif>Лидерборд</a>
            @auth
                <a href="{{route('garage', [], false)}}" @class(['is-active'=>request()->routeIs('garage')]) @if(request()->routeIs('garage')) aria-current="page" @endif>Мой гараж</a>
                @if(auth()->user()->role?->name==='admin')
                    <a href="{{route('admin.index', [], false)}}" @class(['is-active'=>request()->routeIs('admin.*')]) @if(request()->routeIs('admin.*')) aria-current="page" @endif>Админ</a>
                @endif
                <span class="user-badge">{{auth()->user()->login}}</span>
                <form class="logout-form" method="POST" action="{{route('logout', [], false)}}">@csrf<button class="nav-button" type="submit">Выйти</button></form>
            @else
                <a href="{{route('login', request()->filled('preview_intended')?['preview_intended'=>request()->query('preview_intended')]:[], false)}}" @class(['is-active'=>request()->routeIs('login')]) @if(request()->routeIs('login')) aria-current="page" @endif>Войти</a>
                <a class="nav-register" href="{{route('register', request()->filled('preview_intended')?['preview_intended'=>request()->query('preview_intended')]:[], false)}}" @class(['is-active'=>request()->routeIs('register')]) @if(request()->routeIs('register')) aria-current="page" @endif>Регистрация</a>
            @endauth
        </nav>
    </div>
</header>
