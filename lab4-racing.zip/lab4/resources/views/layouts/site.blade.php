<!DOCTYPE html>
<html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="{{ csrf_token() }}"><meta name="theme-color" content="#f6f5f1">
<title>@yield('title', 'Пит-стоп — гонки сверху')</title>
@php
    $viteManifestPath = public_path('build/manifest.json');
    $viteManifest = is_file($viteManifestPath) ? (json_decode(file_get_contents($viteManifestPath), true) ?: []) : [];
    $appStylesheet = $viteManifest['resources/css/app.css']['file'] ?? null;
    $appScript = $viteManifest['resources/js/app.js']['file'] ?? null;
@endphp
{{-- Use origin-relative Vite URLs so assets load through the Arena proxy and on any deployment host. --}}
@if($appStylesheet)<link rel="stylesheet" href="/build/{{$appStylesheet}}">@endif
@if($appScript)<script type="module" src="/build/{{$appScript}}"></script>@endif
@stack('head')
</head><body><x-site-header/><main class="page-shell">
@if(session('success'))<div class="message message-success" role="status">{{session('success')}}</div>@endif
@if($errors->any())<div class="message message-error" role="alert"><strong>Проверьте введённые данные:</strong><ul>@foreach($errors->all() as $error)<li>{{$error}}</li>@endforeach</ul></div>@endif
@yield('content')</main><x-site-footer/>@stack('scripts')</body></html>
