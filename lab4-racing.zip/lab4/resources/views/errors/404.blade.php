@extends('layouts.site')
@section('title','Не тот поворот — Пит-стоп')
@section('content')
<section class="error-page error-404"><div class="error-art"><span class="error-code">404</span><div class="error-road"><i></i><i></i><i></i></div><div class="error-car">P</div><span class="error-cone">▲</span></div><p class="eyebrow">OFF TRACK · 404</p><h1>Кажется, ты<br>свернул не туда.</h1><p>Такой страницы на трассе нет. Вернись к выбору маршрута и продолжай гонку.</p><div class="error-actions"><a class="button" href="{{route('home', [], false)}}">К выбору трассы <span>→</span></a><a class="button button-muted" href="{{route('leaderboard', [], false)}}">Лидерборд</a></div></section>
@endsection
