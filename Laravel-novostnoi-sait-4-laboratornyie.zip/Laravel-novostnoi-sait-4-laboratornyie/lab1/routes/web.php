<?php

use Illuminate\Support\Facades\Route;

$articles = [
    [
        'title' => 'Новый спутник поможет изучать климат',
        'category' => 'Космос',
        'author' => 'Редакция',
        'date' => '14 октября 2026',
        'excerpt' => 'Аппарат будет собирать данные об облаках и температуре поверхности Земли.',
    ],
    [
        'title' => 'В школах тестируют цифровые лаборатории',
        'category' => 'Технологии',
        'author' => 'Редакция',
        'date' => '12 октября 2026',
        'excerpt' => 'Ученики смогут проводить простые опыты и сразу видеть результаты измерений.',
    ],
    [
        'title' => 'Учёные создали новый материал для батарей',
        'category' => 'Наука',
        'author' => 'Редакция',
        'date' => '10 октября 2026',
        'excerpt' => 'Новый материал может увеличить срок службы аккумуляторов.',
    ],
];

Route::get('/', function () use ($articles) {
    return view('home', ['articles' => $articles]);
})->name('home');

Route::get('/category', function () use ($articles) {
    return view('category', [
        'categoryName' => 'Технологии',
        'articles' => array_values(array_filter(
            $articles,
            fn (array $article) => $article['category'] === 'Технологии'
        )),
    ]);
})->name('category');

Route::get('/journalist', function () {
    return view('journalist');
})->name('journalist');

Route::get('/admin', function () {
    return view('admin');
})->name('admin');
