@extends('layouts.site')

@section('title', 'Админка — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Раздел администратора</p>
        <h1>Управление сайтом</h1>
        <p>Здесь администратор сможет управлять статьями и ролями пользователей.</p>
    </section>

    <section class="admin-block">
        <div class="section-heading">
            <h2>Статьи</h2>
            <span class="muted-label">Демонстрационный список</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Заголовок</th>
                        <th>Категория</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Новый спутник поможет изучать климат</td>
                        <td>Космос</td>
                        <td><button class="button button-small" type="button">Редактировать</button></td>
                    </tr>
                    <tr>
                        <td>В школах тестируют цифровые лаборатории</td>
                        <td>Технологии</td>
                        <td><button class="button button-small button-muted" type="button">Заблокировать</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

    <section class="admin-block">
        <div class="section-heading">
            <h2>Роль пользователя</h2>
        </div>
        <form class="role-form">
            <label class="form-field">
                <span>Логин</span>
                <input type="text" name="login" placeholder="Введите логин">
            </label>
            <label class="form-field">
                <span>Новая роль</span>
                <select name="role">
                    <option>Пользователь</option>
                    <option>Журналист</option>
                    <option>Администратор</option>
                </select>
            </label>
            <button class="button" type="button">Изменить роль</button>
        </form>
        <p class="form-note">В первой лабораторной это только макет страницы.</p>
    </section>
@endsection
