@extends('layouts.site')

@section('title', 'Новая статья — ПростоНовости')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Раздел журналиста</p>
        <h1>Написать новость</h1>
        <p>Заполните три поля, чтобы подготовить статью.</p>
    </section>

    <form class="form-panel">
        <label class="form-field">
            <span>Заголовок</span>
            <input type="text" name="heading" placeholder="Например: Учёные открыли новую планету">
        </label>

        <label class="form-field">
            <span>Категория</span>
            <select name="category">
                <option>Технологии</option>
                <option>Наука</option>
                <option>Космос</option>
            </select>
        </label>

        <label class="form-field">
            <span>Текст статьи</span>
            <textarea name="text" rows="8" placeholder="Расскажите, что произошло..."></textarea>
        </label>

        <button class="button" type="button">Сохранить статью</button>
        <p class="form-note">В первой лабораторной это только макет формы.</p>
    </form>
@endsection
