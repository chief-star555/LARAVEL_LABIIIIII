<header class="site-header">
    <div class="header-inner">
        <a class="brand" href="{{ route('home') }}">
            <span class="brand-mark">П</span>
            <span>ПростоНовости</span>
        </a>

        <nav class="main-nav" aria-label="Основная навигация">
            <a href="{{ route('home') }}">Главная</a>
            <a href="{{ route('category') }}">Технологии</a>
            <a href="{{ route('journalist') }}">Журналист</a>
            <a href="{{ route('admin') }}">Админ</a>
        </nav>
    </div>
</header>
