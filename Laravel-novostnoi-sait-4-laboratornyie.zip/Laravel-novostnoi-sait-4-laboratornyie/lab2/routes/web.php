<?php

use App\Http\Controllers\ArticleController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ArticleController::class, 'home'])->name('home');
Route::get('/category', [ArticleController::class, 'category'])->name('category');
Route::get('/admin', function () {
    return view('admin');
})->name('admin');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.store');
    Route::get('/register', [AuthController::class, 'registerForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.store');
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/journalist', [ArticleController::class, 'create'])->name('journalist');
    Route::post('/journalist', [ArticleController::class, 'store'])->name('journalist.store');
    Route::get('/journalist/{article}/edit', [ArticleController::class, 'edit'])->name('journalist.edit');
    Route::put('/journalist/{article}', [ArticleController::class, 'update'])->name('journalist.update');
});
