<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'ПростоНовости')</title>
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>
    <x-site-header />

    <main class="page-shell">
        @if (session('success'))
            <div class="message message-success" role="status">{{ session('success') }}</div>
        @endif

        @yield('content')
    </main>

    <x-site-footer />
</body>
</html>
