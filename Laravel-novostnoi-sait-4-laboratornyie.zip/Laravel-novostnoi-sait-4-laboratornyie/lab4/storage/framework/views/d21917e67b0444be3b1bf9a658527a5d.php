<?php $__env->startSection('title', $categoryName . ' — ПростоНовости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-heading">
        <p class="eyebrow">Раздел новостного сайта</p>
        <h1><?php echo e($categoryName); ?></h1>
        <p>Здесь собраны новости выбранной категории.</p>
    </section>

    <section class="news-list">
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="news-card">
                <div class="news-card-top">
                    <span class="category-pill"><?php echo e($article['category']); ?></span>
                    <time><?php echo e($article['date']); ?></time>
                </div>
                <h2><?php echo e($article['title']); ?></h2>
                <p><?php echo e($article['excerpt']); ?></p>
                <div class="news-byline">Автор: <?php echo e($article['author']); ?></div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state">В этой категории пока нет новостей.</div>
        <?php endif; ?>
    </section>

    <div class="pagination"><?php echo e($articles->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/laravel-news-site/resources/views/category.blade.php ENDPATH**/ ?>