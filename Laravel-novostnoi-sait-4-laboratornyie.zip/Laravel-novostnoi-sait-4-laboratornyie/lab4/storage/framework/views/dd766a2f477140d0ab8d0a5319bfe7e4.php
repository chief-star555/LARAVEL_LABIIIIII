<?php $__env->startSection('title', 'Главная — ПростоНовости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="welcome-panel">
        <p class="eyebrow">Новости науки и технологий</p>
        <h1>Главное — простыми словами</h1>
        <p class="welcome-copy">Коротко рассказываем об открытиях, технологиях и событиях.</p>
    </section>

    <section class="news-section">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Свежие публикации</p>
                <h2>Последние новости</h2>
            </div>
            <a class="text-link" href="<?php echo e(route('category')); ?>">Все новости о технологиях →</a>
        </div>

        <div class="news-list">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="news-card">
                    <div class="news-card-top">
                        <span class="category-pill"><?php echo e($article['category']); ?></span>
                        <time><?php echo e($article['date']); ?></time>
                    </div>
                    <h3><?php echo e($article['title']); ?></h3>
                    <p><?php echo e($article['excerpt']); ?></p>
                    <div class="news-byline">Автор: <?php echo e($article['author']); ?></div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="pagination"><?php echo e($articles->links()); ?></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/laravel-news-site/resources/views/home.blade.php ENDPATH**/ ?>