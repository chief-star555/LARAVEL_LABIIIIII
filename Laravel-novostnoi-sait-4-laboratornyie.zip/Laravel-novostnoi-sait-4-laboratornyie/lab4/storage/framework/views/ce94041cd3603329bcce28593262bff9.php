<?php $__env->startSection('title', 'Вход — ПростоНовости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-heading">
        <p class="eyebrow">Личный кабинет</p>
        <h1>Войти</h1>
        <p>Введите логин и пароль, чтобы продолжить.</p>
    </section>

    <form class="form-panel auth-panel" method="POST" action="<?php echo e(route('login.store')); ?>">
        <?php echo csrf_field(); ?>

        <label class="form-field">
            <span>Логин</span>
            <input type="text" name="login" value="<?php echo e(old('login')); ?>" autocomplete="username" required autofocus>
            <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="form-field">
            <span>Пароль</span>
            <input type="password" name="password" autocomplete="current-password" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <button class="button" type="submit">Войти</button>
        <p class="form-note">Нет аккаунта? <a class="text-link" href="<?php echo e(route('register')); ?>">Зарегистрироваться</a></p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/laravel-news-site/resources/views/auth/login.blade.php ENDPATH**/ ?>