<?php $__env->startSection('title', 'Редактирование статьи — ПростоНовости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-heading">
        <p class="eyebrow">Администрирование</p>
        <h1>Редактировать статью</h1>
        <p>Изменения сразу сохраняются в базе данных.</p>
    </section>

    <form class="form-panel" method="POST" action="<?php echo e(route('admin.articles.update', $article)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label class="form-field">
            <span>Заголовок</span>
            <input type="text" name="heading" value="<?php echo e(old('heading', $article->heading)); ?>" required>
            <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="form-field">
            <span>Категория</span>
            <select name="category_id" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $article->category_id) == $category->id): echo 'selected'; endif; ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="form-field">
            <span>Текст статьи</span>
            <textarea name="text" rows="10" required><?php echo e(old('text', $article->text)); ?></textarea>
            <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <button class="button" type="submit">Сохранить изменения</button>
        <a class="text-link cancel-link" href="<?php echo e(route('admin.index')); ?>">Вернуться в админку</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/laravel-news-site/resources/views/admin/articles-edit.blade.php ENDPATH**/ ?>