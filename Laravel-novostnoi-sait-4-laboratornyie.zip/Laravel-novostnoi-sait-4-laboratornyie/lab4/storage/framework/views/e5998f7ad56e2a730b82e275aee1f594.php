<header class="site-header">
    <div class="header-inner">
        <a class="brand" href="<?php echo e(route('home')); ?>">
            <span class="brand-mark">П</span>
            <span>ПростоНовости</span>
        </a>

        <nav class="main-nav" aria-label="Основная навигация">
            <a href="<?php echo e(route('home')); ?>">Главная</a>
            <a href="<?php echo e(route('category')); ?>">Технологии</a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(in_array(auth()->user()->role?->name, ['journalist', 'admin'], true)): ?>
                    <a href="<?php echo e(route('journalist')); ?>">Журналист</a>
                <?php endif; ?>
                <?php if(auth()->user()->role?->name === 'admin'): ?>
                    <a href="<?php echo e(route('admin.index')); ?>">Админ</a>
                <?php endif; ?>
                <span class="user-badge"><?php echo e(auth()->user()->login); ?></span>
                <form class="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="nav-button" type="submit">Выйти</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Войти</a>
                <a href="<?php echo e(route('register')); ?>">Регистрация</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<?php /**PATH /home/runner/workspace/lab4/resources/views/components/site-header.blade.php ENDPATH**/ ?>