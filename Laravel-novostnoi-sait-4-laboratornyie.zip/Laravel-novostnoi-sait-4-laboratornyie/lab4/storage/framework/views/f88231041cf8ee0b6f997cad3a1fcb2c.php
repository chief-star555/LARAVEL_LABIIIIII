<?php $__env->startSection('title', 'Регистрация — ПростоНовости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-heading">
        <p class="eyebrow">Новый аккаунт</p>
        <h1>Регистрация</h1>
        <p>Для регистрации нужны только логин и пароль.</p>
    </section>

    <form class="form-panel auth-panel" method="POST" action="<?php echo e(route('register.store')); ?>">
        <?php echo csrf_field(); ?>

        <label class="form-field">
            <span>Логин</span>
            <input type="text" name="login" value="<?php echo e(old('login')); ?>" autocomplete="username" required autofocus>
            <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="form-field">
            <span>Пароль</span>
            <input type="password" name="password" autocomplete="new-password" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="form-field">
            <span>Повторите пароль</span>
            <input type="password" name="password_confirmation" autocomplete="new-password" required>
        </label>

        <button class="button" type="submit">Создать аккаунт</button>
        <p class="form-note">Уже зарегистрированы? <a class="text-link" href="<?php echo e(route('login')); ?>">Войти</a></p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/laravel-news-site/resources/views/auth/register.blade.php ENDPATH**/ ?>