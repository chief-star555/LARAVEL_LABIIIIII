<?php $__env->startSection('title', 'Новая статья — ПростоНовости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-heading">
        <p class="eyebrow">Раздел журналиста</p>
        <h1>Написать новость</h1>
        <p>Заполните три поля, чтобы подготовить статью.</p>
    </section>

    <form class="form-panel" method="POST" action="<?php echo e($article ? route('journalist.update', $article) : route('journalist.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($article): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <label class="form-field">
            <span>Заголовок</span>
            <input type="text" name="heading" value="<?php echo e(old('heading', $article?->heading)); ?>" placeholder="Например: Учёные открыли новую планету" required>
            <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="form-field">
            <span>Категория</span>
            <select name="category_id" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $article?->category_id) == $category->id): echo 'selected'; endif; ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="form-field">
            <span>Текст статьи</span>
            <textarea name="text" rows="8" placeholder="Расскажите, что произошло..." required><?php echo e(old('text', $article?->text)); ?></textarea>
            <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <button class="button" type="submit"><?php echo e($article ? 'Сохранить изменения' : 'Опубликовать статью'); ?></button>
        <?php if($article): ?>
            <a class="text-link cancel-link" href="<?php echo e(route('journalist')); ?>">Отменить редактирование</a>
        <?php endif; ?>
    </form>

    <section class="news-section">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Ваши публикации</p>
                <h2>Мои статьи</h2>
            </div>
        </div>

        <div class="news-list">
            <?php $__empty_1 = true; $__currentLoopData = $myArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="news-card">
                    <div class="news-card-top">
                        <span class="category-pill">Статья</span>
                        <a class="text-link" href="<?php echo e(route('journalist.edit', $myArticle)); ?>">Редактировать</a>
                    </div>
                    <h3><?php echo e($myArticle->heading); ?></h3>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state">Вы ещё не написали статей.</div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/laravel-news-site/resources/views/journalist.blade.php ENDPATH**/ ?>