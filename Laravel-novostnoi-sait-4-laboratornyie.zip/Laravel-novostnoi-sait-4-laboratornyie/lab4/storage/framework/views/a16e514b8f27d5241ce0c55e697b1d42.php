<?php $__env->startSection('title', 'Админка — ПростоНовости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-heading">
        <p class="eyebrow">Раздел администратора</p>
        <h1>Управление сайтом</h1>
        <p>Здесь можно редактировать и блокировать статьи, а также менять роли пользователей.</p>
    </section>

    <section class="admin-block">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Публикации</p>
                <h2>Статьи</h2>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Заголовок и автор</th>
                        <th>Категория</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <strong><?php echo e($article->heading); ?></strong>
                                <small>Автор: <?php echo e($article->author->login); ?></small>
                            </td>
                            <td><?php echo e($article->category->name); ?></td>
                            <td>
                                <?php if($article->is_published): ?>
                                    <span class="status status-live">Опубликована</span>
                                <?php else: ?>
                                    <span class="status status-blocked">Заблокирована</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="table-actions">
                                    <a class="text-link" href="<?php echo e(route('admin.articles.edit', $article)); ?>">Изменить</a>
                                    <form method="POST" action="<?php echo e(route('admin.articles.toggle-block', $article)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button class="button button-small button-muted" type="submit">
                                            <?php echo e($article->is_published ? 'Заблокировать' : 'Опубликовать'); ?>

                                        </button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.articles.destroy', $article)); ?>" onsubmit="return confirm('Удалить эту статью?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="button button-small button-danger" type="submit">Удалить</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">Статей пока нет.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pagination"><?php echo e($articles->links()); ?></div>
    </section>

    <section class="admin-block">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Аккаунты</p>
                <h2>Роли пользователей</h2>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Логин</th>
                        <th>Текущая роль</th>
                        <th>Изменить роль</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->login); ?></td>
                            <td><?php echo e($roleLabels[$user->role->name] ?? $user->role->name); ?></td>
                            <td>
                                <form class="role-form-inline" method="POST" action="<?php echo e(route('admin.users.update-role', $user)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <select name="role_id" aria-label="Новая роль для <?php echo e($user->login); ?>">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>" <?php if($user->role_id === $role->id): echo 'selected'; endif; ?>>
                                                <?php echo e($roleLabels[$role->name] ?? $role->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button class="button button-small" type="submit">Сохранить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/runner/workspace/laravel-news-site/resources/views/admin.blade.php ENDPATH**/ ?>