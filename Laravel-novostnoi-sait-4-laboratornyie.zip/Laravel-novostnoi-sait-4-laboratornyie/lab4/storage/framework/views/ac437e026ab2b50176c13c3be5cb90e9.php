<footer class="site-footer">
    <div class="footer-inner">
        <span>ПростоНовости — учебный новостной сайт</span>
        <span>Лабораторная работа по Laravel</span>
    </div>
</footer>
<?php /**PATH /home/runner/workspace/lab4/resources/views/components/site-footer.blade.php ENDPATH**/ ?>